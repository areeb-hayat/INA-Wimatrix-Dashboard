// src/app/api/trends/route.ts
// Trends are now computed in /api/kpis as dailyTrend — this endpoint is kept for
// backward compatibility but redirects to empty (trends are fetched via /api/kpis).
import { NextResponse } from 'next/server'

export const dynamic   = 'force-dynamic'
export const revalidate = 0

export async function GET() {
  // Trend data is now included in /api/kpis response as charts.dailyTrend
  return NextResponse.json({ trend: [] })
}
