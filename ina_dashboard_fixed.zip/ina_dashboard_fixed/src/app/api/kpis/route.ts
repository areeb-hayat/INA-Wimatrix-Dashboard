// src/app/api/kpis/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { connectDB } from '@/lib/db'
import { Prod6rModel, QcRework6rModel, ProdInfoModel, QcReworkModel, WageByBundleModel, WageSummaryModel } from '@/lib/models'
import { startOfDay, endOfDay, startOfMonth, format, parseISO } from 'date-fns'

export const dynamic   = 'force-dynamic'
export const revalidate = 0

export async function GET(req: NextRequest) {
  try {
    await connectDB()
    const { searchParams } = new URL(req.url)
    const preset    = searchParams.get('preset')
    const fromParam = searchParams.get('from')
    const toParam   = searchParams.get('to')

    let dayStart: Date | null = null
    let dayEnd:   Date | null = null

    if (preset !== 'all' && fromParam && toParam) {
      dayStart = startOfDay(parseISO(fromParam))
      dayEnd   = endOfDay(parseISO(toParam))
    } else if (preset !== 'all' && searchParams.get('date')) {
      const d  = parseISO(searchParams.get('date')!)
      dayStart = startOfDay(d)
      dayEnd   = endOfDay(d)
    }

    const data = await buildDashboard(dayStart, dayEnd)
    return NextResponse.json(data)
  } catch (err) {
    console.error('KPI error:', err)
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}

// ─── IMPORTANT: All date fields in MongoDB are stored as ISO strings ───────────
// Oracle ORDS returns dates as strings like "2026-04-13T04:00:00Z" or "2026-05-25T16:45:59"
// The Python sync script stores them as-is (strings, NOT Date objects).
// ISO 8601 strings sort lexicographically correctly, so $gte/$lte string comparisons work.
// NEVER compare a JS Date object against these fields — it will always return 0 results.

function toIsoStr(d: Date): string {
  return d.toISOString()
}

/** String-based date range filter — works for all Oracle string date fields */
function sf(field: string, start: Date | null, end: Date | null): Record<string, unknown> {
  if (!start || !end) return {}
  return { [field]: { $gte: toIsoStr(start), $lte: toIsoStr(end) } }
}

/** String date filter for SQL Server date fields stored as 'YYYY-MM-DD' strings */
function sfDate(field: string, start: Date | null, end: Date | null): Record<string, unknown> {
  if (!start || !end) return {}
  return { [field]: { $gte: format(start, 'yyyy-MM-dd'), $lte: format(end, 'yyyy-MM-dd') } }
}

// ─────────────────────────────────────────────────────────────────────────────
// 6R: production_info_6r + qc_rework_info_6r
// Lines: numeric (e.g. 15, 17) from odpi_line_number / QCRI_LineNumber
// ─────────────────────────────────────────────────────────────────────────────

async function get6rLines(start: Date | null, end: Date | null): Promise<number[]> {
  const Prod6r = Prod6rModel()
  const filter: Record<string, unknown> = {
    odpi_line_number: { $ne: null },
    ...sf('odpi_date', start, end),
  }
  const lines = await Prod6r.distinct('odpi_line_number', filter)
  return (lines as number[]).filter(n => typeof n === 'number' && n > 0).sort((a, b) => a - b)
}

async function build6rLineKpis(start: Date | null, end: Date | null, lineNumber: number | null) {
  const Prod6r     = Prod6rModel()
  const QcRework6r = QcRework6rModel()

  const prodBase: Record<string, unknown> = {
    odpi_odpd_is_overtime: 0,
    odpi_quantity:         { $gt: 0 },
    odpi_line_number:      { $ne: null },
    ...sf('odpi_date', start, end),
  }
  if (lineNumber !== null) prodBase.odpi_line_number = lineNumber

  const qcBase: Record<string, unknown> = {
    ...sf('QCRI_QC_DateTime', start, end),
  }
  if (lineNumber !== null) qcBase.QCRI_LineNumber = lineNumber

  // MTD filter: from start of month to end of range
  const mtdBase: Record<string, unknown> = {
    odpi_odpd_is_overtime: 0,
    odpi_quantity:         { $gt: 0 },
    pc_key:                9999,
    ...(start ? sf('odpi_date', startOfMonth(start), end ?? new Date()) : {}),
  }
  if (lineNumber !== null) mtdBase.odpi_line_number = lineNumber

  const [outputAgg, minutesAgg, defectAgg, tatAgg, mtdAgg, loadAgg, planRec,
         totalRework, pendingRework] = await Promise.all([

    // Finished pieces: pc_key = 9999 (unloading checkpoint = end of line)
    Prod6r.aggregate([
      { $match: { ...prodBase, pc_key: 9999 } },
      { $group: { _id: null, total: { $sum: '$odpi_quantity' } } },
    ]),

    // Efficiency: earned minutes vs workers × 480
    Prod6r.aggregate([
      { $match: prodBase },
      { $group: {
        _id: null,
        earnedMins: { $sum: { $multiply: ['$odpi_quantity', { $divide: ['$odpi_oc_standard_time', 60] }] } },
        workers:    { $addToSet: '$odpi_em_key' },
      }},
    ]),

    // DHU defects
    QcRework6r.aggregate([
      { $match: { ...qcBase, QCRI_QCSC_Is_Rework: 1 } },
      { $group: { _id: null, total: { $sum: '$QCRI_Defect_Quantity' } } },
    ]),

    // Repair TAT
    QcRework6r.aggregate([
      { $match: { ...qcBase, QCRI_Repair_Quantity: { $gt: 0 }, QCRI_Repair_EM_Key: { $gt: 0 } } },
      { $addFields: {
        tatMins: { $divide: [
          { $subtract: [{ $toDate: '$QCRI_Repair_DateTime' }, { $toDate: '$QCRI_QC_DateTime' }] },
          60000,
        ]},
      }},
      { $match: { tatMins: { $gt: 0, $lt: 480 } } },
      { $group: { _id: null, avg: { $avg: '$tatMins' } } },
    ]),

    // MTD output
    Prod6r.aggregate([
      { $match: mtdBase },
      { $group: { _id: null, total: { $sum: '$odpi_quantity' } } },
    ]),

    // WIP = loaded (stop_order=1) - unloaded
    Prod6r.aggregate([
      { $match: { ...prodBase, odpi_stop_order: 1 } },
      { $group: { _id: null, total: { $sum: '$odpi_quantity' } } },
    ]),

    // Planned qty for this line/date (from stpo_plannedquantity field)
    Prod6r.findOne({ ...prodBase, stpo_plannedquantity: { $gt: 0 } }, { stpo_plannedquantity: 1 }).lean(),

    // Rework counts
    QcRework6r.countDocuments({ ...qcBase, QCRI_QCSC_Is_Rework: 1 }),
    QcRework6r.countDocuments({ ...qcBase, QCRI_Repair_Quantity: 0, QCRI_QCSC_Is_Rework: 1 }),
  ])

  const output       = (outputAgg[0]?.total    as number) || 0
  const earnedMins   = Math.round((minutesAgg[0]?.earnedMins as number) || 0)
  const workerCount  = ((minutesAgg[0]?.workers as unknown[]) || []).length
  const planMins     = workerCount * 480
  const efficiency   = planMins > 0 ? (earnedMins / planMins) * 100 : 0
  const totalDefects = (defectAgg[0]?.total    as number) || 0
  const dhu          = output > 0 ? (totalDefects / output) * 100 : 0
  const avgTat       = Math.round((tatAgg[0]?.avg as number) || 0)
  const mtdOutput    = (mtdAgg[0]?.total        as number) || 0
  const loaded       = (loadAgg[0]?.total       as number) || output
  const wip          = Math.max(0, loaded - output)
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const plannedQty   = ((planRec as any)?.stpo_plannedquantity as number) || 0

  return {
    output, plannedQty, mtdOutput,
    efficiency:    Math.round(efficiency * 10) / 10,
    earnedMinutes: earnedMins,
    planMinutes:   planMins,
    dhu:           Math.round(dhu * 100) / 100,
    totalDefects,
    rework:        totalRework,
    pendingRework,
    wip,
    avgRepairTat:  avgTat,
    workerCount,
    targetAchievedPct: plannedQty > 0 ? Math.round((output / plannedQty) * 100) : 0,
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// 7R: production_info + quality_rework_info
// Lines: strings like "Line10", "Line11", "FIN01", "FIN02", "LINE-01"
// ─────────────────────────────────────────────────────────────────────────────

async function get7rLines(start: Date | null, end: Date | null): Promise<string[]> {
  const ProdInfo = ProdInfoModel()
  const filter: Record<string, unknown> = {
    ppd_line_number: { $ne: null },
    ...sf('ppd_date', start, end),
  }
  const lines = await ProdInfo.distinct('ppd_line_number', filter)
  return (lines as string[]).filter(l => l && typeof l === 'string').sort()
}

async function build7rLineKpis(start: Date | null, end: Date | null, lineStr: string | null) {
  const ProdInfo  = ProdInfoModel()
  const QcRework  = QcReworkModel()

  const prodBase: Record<string, unknown> = {
    ppd_line_number: { $ne: null },
    ...sf('ppd_date', start, end),
  }
  if (lineStr) prodBase.ppd_line_number = lineStr

  const qcBase: Record<string, unknown> = {
    ...sf('date_back', start, end),
  }
  if (lineStr) qcBase.ppd_line_number = lineStr

  const [outputAgg, minutesAgg, defectAgg] = await Promise.all([
    // Total output: sum of ppd_quantity per line
    ProdInfo.aggregate([
      { $match: prodBase },
      { $group: {
        _id: null,
        total:   { $sum: '$ppd_quantity' },
        workers: { $addToSet: '$ppd_hei_code' },
        earnedMins: { $sum: { $multiply: ['$ppd_quantity', { $divide: ['$ppd_standard_time', 60] }] } },
      }},
    ]),

    // Distinct workers
    ProdInfo.aggregate([
      { $match: prodBase },
      { $group: { _id: '$ppd_hei_code' } },
      { $count: 'total' },
    ]),

    // Defects from quality_rework_info
    QcRework.aggregate([
      { $match: qcBase },
      { $group: { _id: null, total: { $sum: '$bindquantity' }, rework: { $sum: 1 } } },
    ]),
  ])

  const output       = (outputAgg[0]?.total    as number) || 0
  const earnedMins   = Math.round((outputAgg[0]?.earnedMins as number) || 0)
  const workerCount  = (minutesAgg[0]?.total   as number) || 0
  const planMins     = workerCount * 480
  const efficiency   = planMins > 0 ? Math.round((earnedMins / planMins) * 1000) / 10 : 0
  const totalDefects = (defectAgg[0]?.total    as number) || 0
  const rework       = (defectAgg[0]?.rework   as number) || 0
  const dhu          = output > 0 ? Math.round((totalDefects / output) * 10000) / 100 : 0

  return { output, earnedMinutes: earnedMins, planMinutes: planMins, efficiency, totalDefects, rework, dhu, workerCount }
}

// ─────────────────────────────────────────────────────────────────────────────
// SQL: worker_wage_by_bundle + worker_wage_summary
// Lines: strings like "8" (LineCode), names like "Stitching Line 08"
// ─────────────────────────────────────────────────────────────────────────────

async function getSqlLines(start: Date | null, end: Date | null): Promise<{ code: string; name: string }[]> {
  const WageBundle = WageByBundleModel()
  const filter: Record<string, unknown> = {
    LineCode: { $ne: null },
    ...sfDate('ScanDate', start, end),
  }
  const lines = await WageBundle.aggregate([
    { $match: filter },
    { $group: { _id: '$LineCode', name: { $first: '$LineName' } } },
    { $sort: { _id: 1 } },
  ])
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return (lines as any[]).map((l: any) => ({ code: String(l._id), name: (l.name as string) || `Line ${l._id}` }))
}

async function buildSqlLineKpis(start: Date | null, end: Date | null, lineCode: string | null) {
  const WageBundle  = WageByBundleModel()
  const WageSummary = WageSummaryModel()

  const bundleFilter: Record<string, unknown> = {
    ...sfDate('ScanDate', start, end),
  }
  if (lineCode) bundleFilter.LineCode = lineCode

  const summaryFilter: Record<string, unknown> = {
    ...sfDate('CreatedAtDate', start, end),
  }
  // Note: WorkerWageSummary does not have LineCode — join is via WorkerCode/WorkerID

  const [bundleAgg, summaryAgg, workerCountAgg] = await Promise.all([
    WageBundle.aggregate([
      { $match: bundleFilter },
      { $group: {
        _id: null,
        output:      { $sum: '$ScannedQuantity' },
        totalWage:   { $sum: '$Wage' },
        prodMins:    { $sum: '$ProductiveMinutes' },
        lineCode:    { $first: '$LineCode' },
        lineName:    { $first: '$LineName' },
      }},
    ]),
    WageSummary.aggregate([
      { $match: summaryFilter },
      { $group: {
        _id: null,
        avgEfficiency: { $avg: { $toDouble: '$Efficiency' } },
        prodMins:      { $sum: '$ProductiveMinutes' },
        shiftMins:     { $sum: '$ShiftMins' },
      }},
    ]),
    WageBundle.aggregate([
      { $match: bundleFilter },
      { $group: { _id: '$WorkerCode' } },
      { $count: 'total' },
    ]),
  ])

  const output      = (bundleAgg[0]?.output     as number) || 0
  const totalWage   = (bundleAgg[0]?.totalWage  as number) || 0
  const prodMins    = (bundleAgg[0]?.prodMins   as number) || 0
  const workerCount = (workerCountAgg[0]?.total  as number) || 0
  const efficiency  = (summaryAgg[0]?.avgEfficiency as number) || 0

  return { output, totalWage, productiveMinutes: Math.round(prodMins), workerCount, efficiency: Math.round(efficiency * 10) / 10 }
}

// ─────────────────────────────────────────────────────────────────────────────
// Main dashboard builder
// ─────────────────────────────────────────────────────────────────────────────

async function buildDashboard(start: Date | null, end: Date | null) {
  const Prod6r     = Prod6rModel()
  const QcRework6r = QcRework6rModel()

  // Get available lines from all 3 sources concurrently
  const [lines6r, lines7r, linesSqlMeta] = await Promise.all([
    get6rLines(start, end),
    get7rLines(start, end),
    getSqlLines(start, end),
  ])

  // Build per-line KPIs for each source concurrently
  const [all6rKpis, all7rKpis, allSqlKpis, summary6rRaw] = await Promise.all([
    Promise.all(
      lines6r.map(async (ln) => {
        const k = await build6rLineKpis(start, end, ln)
        return { source: '6r' as const, line: ln, lineName: `6R Line ${ln}`, ...k }
      })
    ),
    Promise.all(
      lines7r.map(async (ln) => {
        const k = await build7rLineKpis(start, end, ln)
        return { source: '7r' as const, line: ln, lineName: `7R ${ln}`, ...k, plannedQty: 0, pendingRework: 0, wip: 0, avgRepairTat: 0, targetAchievedPct: 0 }
      })
    ),
    Promise.all(
      linesSqlMeta.map(async ({ code, name }) => {
        const k = await buildSqlLineKpis(start, end, code)
        return { source: 'sql' as const, line: code, lineName: name, ...k, plannedQty: 0, dhu: 0, totalDefects: 0, rework: 0, pendingRework: 0, wip: 0, avgRepairTat: 0, targetAchievedPct: 0, earnedMinutes: k.productiveMinutes, planMinutes: 0 }
      })
    ),
    build6rLineKpis(start, end, null),
  ])

  // Charts — 6R based
  const prodChartFilter: Record<string, unknown> = {
    odpi_odpd_is_overtime: 0,
    pc_key: 9999,
    ...sf('odpi_date', start, end),
  }
  const qcChartFilter: Record<string, unknown> = {
    QCRI_QCSC_Is_Rework: 1,
    ...sf('QCRI_QC_DateTime', start, end),
  }
  const workerFilter: Record<string, unknown> = {
    odpi_odpd_is_overtime: 0,
    odpi_quantity:         { $gt: 0 },
    ...sf('odpi_date', start, end),
  }

  const [defectBreakdown, topWorkers] = await Promise.all([
    QcRework6r.aggregate([
      { $match: qcChartFilter },
      { $group: { _id: '$QCRI_QCSC_Description', count: { $sum: '$QCRI_Defect_Quantity' } } },
      { $sort: { count: -1 } },
      { $limit: 10 },
    ]),
    Prod6r.aggregate([
      { $match: workerFilter },
      { $group: {
        _id:        '$odpi_em_key',
        name:       { $first: { $ifNull: ['$odpi_em_lcd_name', '$odpi_em_firstname'] } },
        qty:        { $sum: '$odpi_quantity' },
        earnedMins: { $sum: { $multiply: ['$odpi_quantity', { $divide: ['$odpi_oc_standard_time', 60] }] } },
      }},
      { $addFields: {
        efficiency: { $multiply: [{ $divide: ['$earnedMins', 480] }, 100] },
      }},
      { $sort: { efficiency: -1 } },
      { $limit: 10 },
    ]),
  ])

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const topWorkerIds = (topWorkers as any[]).map((w) => w._id).filter(Boolean)
  const workerDefects = topWorkerIds.length ? await QcRework6r.aggregate([
    { $match: { QCRI_Defect_EM_Key: { $in: topWorkerIds }, ...sf('QCRI_QC_DateTime', start, end) } },
    { $group: { _id: '$QCRI_Defect_EM_Key', defects: { $sum: '$QCRI_Defect_Quantity' } } },
  ]) : []
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const defectMap = new Map((workerDefects as any[]).map((d: any) => [d._id, d.defects as number]))

  // Daily trend (6R)
  const dailyTrend = await Prod6r.aggregate([
    { $match: { ...prodChartFilter } },
    { $group: {
      _id:   { $dateToString: { format: '%Y-%m-%d', date: { $toDate: '$odpi_date' } } },
      output: { $sum: '$odpi_quantity' },
      earnedMins: { $sum: { $multiply: ['$odpi_quantity', { $divide: ['$odpi_oc_standard_time', 60] }] } },
      workers: { $addToSet: '$odpi_em_key' },
    }},
    { $sort: { _id: 1 } },
    { $limit: 30 },
  ])

  // Defects per day for trend
  const defectsByDay = await QcRework6r.aggregate([
    { $match: { ...qcChartFilter } },
    { $group: {
      _id:   { $dateToString: { format: '%Y-%m-%d', date: { $toDate: '$QCRI_QC_DateTime' } } },
      defects: { $sum: '$QCRI_Defect_Quantity' },
    }},
  ])
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const defectDayMap = new Map((defectsByDay as any[]).map((d: any) => [d._id as string, d.defects as number]))

  return {
    date: start && end
      ? `${format(start, 'yyyy-MM-dd')} → ${format(end, 'yyyy-MM-dd')}`
      : 'All time',

    summary6r: {
      output:            summary6rRaw.output,
      plannedQty:        summary6rRaw.plannedQty,
      efficiency:        summary6rRaw.efficiency,
      earnedMinutes:     summary6rRaw.earnedMinutes,
      planMinutes:       summary6rRaw.planMinutes,
      dhu:               summary6rRaw.dhu,
      totalDefects:      summary6rRaw.totalDefects,
      rework:            summary6rRaw.rework,
      pendingRework:     summary6rRaw.pendingRework,
      wip:               summary6rRaw.wip,
      avgRepairTat:      summary6rRaw.avgRepairTat,
      workerCount:       summary6rRaw.workerCount,
      targetAchievedPct: summary6rRaw.targetAchievedPct,
      mtdOutput:         summary6rRaw.mtdOutput,
    },

    lines6r:  all6rKpis,
    lines7r:  all7rKpis,
    linesSql: allSqlKpis,

    charts: {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      defectBreakdown: (defectBreakdown as any[]).map((d: any) => ({
        name: (d._id as string) || 'Unknown', count: d.count as number,
      })),
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      topWorkers: (topWorkers as any[]).map((w: any) => ({
        id:         w._id as number,
        name:       (w.name as string) || `Worker ${w._id}`,
        qty:        Math.round(w.qty as number),
        efficiency: Math.round((w.efficiency as number) * 10) / 10,
        dhu:        (w.qty as number) > 0
          ? Math.round(((defectMap.get(w._id) || 0) / (w.qty as number)) * 10000) / 100 : 0,
      })),
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      dailyTrend: (dailyTrend as any[]).map((d: any) => {
        const dateStr = d._id as string
        const output  = d.output as number
        const eMins   = d.earnedMins as number
        const wCount  = ((d.workers as unknown[]) || []).length
        const pMins   = wCount * 480
        const eff     = pMins > 0 ? Math.round((eMins / pMins) * 1000) / 10 : 0
        const defects = defectDayMap.get(dateStr) || 0
        const dhu     = output > 0 ? Math.round((defects / output) * 10000) / 100 : 0
        return { date: dateStr, label: dateStr.slice(5), output, efficiency: eff, defects, dhu }
      }),
    },

    availableLines6r:  lines6r,
    availableLines7r:  lines7r,
    availableLinesSql: linesSqlMeta.map(l => l.code),
  }
}
