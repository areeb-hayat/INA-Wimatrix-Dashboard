// src/app/api/workers/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { connectDB } from '@/lib/db'
import { Prod6rModel, QcRework6rModel, WageByBundleModel, WageSummaryModel } from '@/lib/models'
import { startOfDay, endOfDay, parseISO } from 'date-fns'

export const dynamic   = 'force-dynamic'
export const revalidate = 0

function sf(field: string, start: Date | null, end: Date | null): Record<string, unknown> {
  if (!start || !end) return {}
  return { [field]: { $gte: start.toISOString(), $lte: end.toISOString() } }
}

export async function GET(req: NextRequest) {
  try {
    await connectDB()
    const { searchParams } = new URL(req.url)
    const page   = Math.max(1, parseInt(searchParams.get('page')  || '1'))
    const limit  = Math.min(100, parseInt(searchParams.get('limit') || '25'))
    const preset = searchParams.get('preset')
    const fromP  = searchParams.get('from')
    const toP    = searchParams.get('to')

    let start: Date | null = null
    let end:   Date | null = null
    if (preset !== 'all' && fromP && toP) {
      start = startOfDay(parseISO(fromP))
      end   = endOfDay(parseISO(toP))
    }

    const Prod6r     = Prod6rModel()
    const QcRework6r = QcRework6rModel()
    const WageBundle = WageByBundleModel()
    const WageSummary = WageSummaryModel()

    const prodFilter: Record<string, unknown> = {
      odpi_odpd_is_overtime: 0,
      odpi_quantity:         { $gt: 0 },
      ...sf('odpi_date', start, end),
    }

    // Aggregate 6R workers
    const skip  = (page - 1) * limit
    const [workers6r, total6r] = await Promise.all([
      Prod6r.aggregate([
        { $match: prodFilter },
        { $group: {
          _id:        '$odpi_em_key',
          name:       { $first: { $ifNull: ['$odpi_em_lcd_name', '$odpi_em_firstname'] } },
          line:       { $first: '$odpi_line_number' },
          qty:        { $sum: '$odpi_quantity' },
          earnedMins: { $sum: { $multiply: ['$odpi_quantity', { $divide: ['$odpi_oc_standard_time', 60] }] } },
          opCount:    { $sum: 1 },
          clockIn:    { $min: '$odpi_odp_actual_clock_in' },
          clockOut:   { $max: '$odpi_odp_actual_clock_out' },
        }},
        { $addFields: {
          efficiency: { $multiply: [{ $divide: ['$earnedMins', 480] }, 100] },
        }},
        { $sort: { efficiency: -1 } },
        { $skip: skip },
        { $limit: limit },
      ]),
      Prod6r.aggregate([
        { $match: prodFilter },
        { $group: { _id: '$odpi_em_key' } },
        { $count: 'total' },
      ]),
    ])

    // Get defect counts for these workers
    const workerIds = (workers6r as any[]).map((w: any) => w._id).filter(Boolean)
    const defects   = workerIds.length ? await QcRework6r.aggregate([
      { $match: { QCRI_Defect_EM_Key: { $in: workerIds }, ...sf('QCRI_QC_DateTime', start, end) } },
      { $group: { _id: '$QCRI_Defect_EM_Key', defects: { $sum: '$QCRI_Defect_Quantity' } } },
    ]) : []
    const defectMap = new Map((defects as any[]).map((d: any) => [d._id, d.defects as number]))

    // Get wages for these workers from SQL (match by WorkerCode if available)
    const wageMap = new Map<number, number>()
    if (workerIds.length > 0) {
      try {
        const wages = await WageSummary.aggregate([
          { $match: { WorkerID: { $in: workerIds } } },
          { $group: { _id: '$WorkerID', wage: { $sum: '$TotalWage' } } },
        ])
        ;(wages as any[]).forEach((w: any) => wageMap.set(w._id as number, w.wage as number))
      } catch { /* SQL may not be synced */ }
    }

    const totalCount = (total6r[0] as any)?.total || 0
    const pages      = Math.ceil(totalCount / limit)

    return NextResponse.json({
      workers: (workers6r as any[]).map((w: any) => ({
        id:         w._id as number,
        name:       (w.name as string) || `Worker ${w._id}`,
        line:       w.line,
        source:     '6r',
        qty:        Math.round(w.qty as number),
        earnedMins: Math.round(w.earnedMins as number),
        efficiency: Math.round((w.efficiency as number) * 10) / 10,
        wage:       wageMap.get(w._id) || 0,
        defects:    defectMap.get(w._id) || 0,
        dhu:        (w.qty as number) > 0
          ? Math.round(((defectMap.get(w._id) || 0) / (w.qty as number)) * 10000) / 100 : 0,
        opCount:    w.opCount,
        clockIn:    w.clockIn,
        clockOut:   w.clockOut,
      })),
      pagination: { total: totalCount, page, pages },
    })
  } catch (err) {
    console.error('Workers error:', err)
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}
