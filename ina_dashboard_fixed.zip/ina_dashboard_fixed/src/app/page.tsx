'use client'
// src/app/page.tsx
import { useCallback, useEffect, useState, useMemo } from 'react'
import { format } from 'date-fns'
import { DashboardHeader, makeTimeFilter } from '@/components/dashboard/DashboardHeader'
import { AllLinesTable }     from '@/components/dashboard/AllLinesTable'
import { WorkerTable }       from '@/components/dashboard/WorkerTable'
import { ChartsSection }     from '@/components/dashboard/ChartsSection'
import { EfficiencyGauge }   from '@/components/ui/EfficiencyGauge'
import { MtdRing }           from '@/components/ui/MtdRing'
import { KpiCard, SectionLabel } from '@/components/ui/KpiCard'
import { LoadingSkeleton }   from '@/components/ui/LoadingSkeleton'
import { ProgressBar }       from '@/components/ui/ProgressBar'
import type { DashboardData, WorkerRow, SyncSource, TimeFilter } from '@/types'

const EMPTY_SUMMARY = {
  output: 0, plannedQty: 0, efficiency: 0, earnedMinutes: 0, planMinutes: 0,
  dhu: 0, totalDefects: 0, rework: 0, pendingRework: 0, wip: 0,
  avgRepairTat: 0, workerCount: 0, targetAchievedPct: 0, mtdOutput: 0,
}

const EMPTY_DATA: DashboardData = {
  date: '', selectedLine: 'all',
  summary6r: EMPTY_SUMMARY,
  lines6r: [], lines7r: [], linesSql: [],
  charts: { defectBreakdown: [], topWorkers: [], dailyTrend: [] },
  availableLines6r: [], availableLines7r: [], availableLinesSql: [],
}

export default function Page() {
  const [timeFilter,   setTimeFilter]   = useState<TimeFilter>(() => makeTimeFilter('all'))
  const [activeTab,    setActiveTab]    = useState('overview')

  const [data,          setData]          = useState<DashboardData>(EMPTY_DATA)
  const [workers,       setWorkers]       = useState<WorkerRow[]>([])
  const [workerMeta,    setWorkerMeta]    = useState({ total: 0, page: 1, pages: 1 })
  const [syncSources,   setSyncSources]   = useState<SyncSource[]>([])
  const [loading,       setLoading]       = useState(false)
  const [workerLoading, setWorkerLoading] = useState(false)
  const [workerPage,    setWorkerPage]    = useState(1)
  const [error,         setError]         = useState('')

  // ── Build query params ──────────────────────────────────────────────────────
  const dateParams = useMemo(() => {
    const p = new URLSearchParams()
    if (timeFilter.preset === 'all' || (!timeFilter.from && !timeFilter.to)) {
      p.set('preset', 'all')
    } else if (timeFilter.from && timeFilter.to) {
      p.set('from', format(timeFilter.from, 'yyyy-MM-dd'))
      p.set('to',   format(timeFilter.to,   'yyyy-MM-dd'))
    }
    return p
  }, [timeFilter])

  // ── Fetch KPIs ──────────────────────────────────────────────────────────────
  const fetchKpis = useCallback(async () => {
    setLoading(true)
    setError('')
    try {
      const res = await fetch(`/api/kpis?${dateParams}`)
      if (!res.ok) throw new Error(`HTTP ${res.status}: ${await res.text()}`)
      const json = await res.json()
      if (json.error) throw new Error(json.error)
      setData(json)
    } catch (e) {
      console.error('KPI fetch:', e)
      setError(String(e))
    } finally {
      setLoading(false)
    }
  }, [dateParams])

  // ── Fetch workers ───────────────────────────────────────────────────────────
  const fetchWorkers = useCallback(async () => {
    setWorkerLoading(true)
    try {
      const p = new URLSearchParams(dateParams)
      p.set('page',  String(workerPage))
      p.set('limit', '25')
      const res = await fetch(`/api/workers?${p}`)
      if (!res.ok) return
      const d = await res.json()
      setWorkers(d.workers || [])
      setWorkerMeta(d.pagination || { total: 0, page: 1, pages: 1 })
    } catch (e) {
      console.error('Workers fetch:', e)
    } finally {
      setWorkerLoading(false)
    }
  }, [dateParams, workerPage])

  // ── Fetch sync meta ─────────────────────────────────────────────────────────
  const fetchSync = useCallback(async () => {
    try {
      const res = await fetch('/api/sync')
      if (!res.ok) return
      const d = await res.json()
      setSyncSources(d.sources || [])
    } catch { /* silent */ }
  }, [])

  // ── Effects ─────────────────────────────────────────────────────────────────
  useEffect(() => { void fetchKpis(); void fetchSync() }, [fetchKpis, fetchSync])
  useEffect(() => { if (activeTab === 'workers') void fetchWorkers() }, [activeTab, fetchWorkers])
  useEffect(() => { setWorkerPage(1) }, [dateParams])

  // Auto-refresh every 5 minutes
  useEffect(() => {
    const id = setInterval(() => { void fetchKpis() }, 300_000)
    return () => clearInterval(id)
  }, [fetchKpis])

  const s      = data.summary6r
  const hasAny = data.availableLines6r.length > 0
    || data.availableLines7r.length > 0
    || data.availableLinesSql.length > 0

  return (
    <div className="min-h-screen flex flex-col" style={{ background: 'var(--bg)' }}>
      <DashboardHeader
        timeFilter={timeFilter}
        onTimeFilterChange={(f) => { setTimeFilter(f); setWorkerPage(1) }}
        loading={loading}
        onRefresh={() => void fetchKpis()}
        syncSources={syncSources}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        // summary counts for header badges
        total6rLines={data.availableLines6r.length}
        total7rLines={data.availableLines7r.length}
        totalSqlLines={data.availableLinesSql.length}
      />

      <main className="flex-1 max-w-screen-2xl mx-auto w-full px-4 sm:px-6 py-4 space-y-4">

        {/* Error banner */}
        {error && (
          <div className="px-5 py-4 rounded-xl text-sm"
            style={{ background: 'var(--danger-bg)', border: '1px solid var(--danger-border)', color: 'var(--danger)' }}>
            <span className="font-semibold">Error: </span>{error}
            <button onClick={() => void fetchKpis()} className="ml-3 underline underline-offset-2">Retry</button>
          </div>
        )}

        {loading && !hasAny ? (
          <LoadingSkeleton />
        ) : (
          <>
            {/* ── OVERVIEW tab ──────────────────────────────────────────────── */}
            {activeTab === 'overview' && (
              <>
                {/* Source summary row */}
                <div className="grid grid-cols-3 gap-3">
                  <div className="card p-3 flex items-center gap-3">
                    <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: 'var(--accent)' }} />
                    <div>
                      <p className="text-[10px] font-black uppercase tracking-widest" style={{ color: 'var(--text4)' }}>INA 6R</p>
                      <p className="text-xl font-black tabular-nums" style={{ color: 'var(--accent)' }}>{data.availableLines6r.length} lines</p>
                      <p className="text-[10px]" style={{ color: 'var(--text4)' }}>Lines: {data.availableLines6r.join(', ') || '—'}</p>
                    </div>
                  </div>
                  <div className="card p-3 flex items-center gap-3">
                    <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: 'var(--kpi-purple, #A855F7)' }} />
                    <div>
                      <p className="text-[10px] font-black uppercase tracking-widest" style={{ color: 'var(--text4)' }}>INA 7R</p>
                      <p className="text-xl font-black tabular-nums" style={{ color: 'var(--kpi-purple, #A855F7)' }}>{data.availableLines7r.length} lines</p>
                      <p className="text-[10px]" style={{ color: 'var(--text4)' }}>Lines: {data.availableLines7r.join(', ') || '—'}</p>
                    </div>
                  </div>
                  <div className="card p-3 flex items-center gap-3">
                    <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: 'var(--kpi-orange)' }} />
                    <div>
                      <p className="text-[10px] font-black uppercase tracking-widest" style={{ color: 'var(--text4)' }}>SQL</p>
                      <p className="text-xl font-black tabular-nums" style={{ color: 'var(--kpi-orange)' }}>{data.availableLinesSql.length} lines</p>
                      <p className="text-[10px]" style={{ color: 'var(--text4)' }}>Lines: {data.availableLinesSql.join(', ') || '—'}</p>
                    </div>
                  </div>
                </div>

                {/* 6R Hero row — only shown when 6R data exists */}
                {data.availableLines6r.length > 0 && (
                  <>
                    <p className="text-[11px] font-black uppercase tracking-widest pt-1" style={{ color: 'var(--text4)' }}>
                      INA 6R — Primary KPIs (production_info_6r + qc_rework_info_6r)
                    </p>

                    {/* Hero row */}
                    <div className="grid grid-cols-12 gap-4">
                      {/* Output vs Target — sourced from stpo_plannedquantity */}
                      <div className="col-span-12 md:col-span-3 card p-4 flex flex-col gap-3">
                        <p className="text-[10px] font-black uppercase tracking-widest" style={{ color: 'var(--text4)' }}>
                          6R Output vs Target
                        </p>
                        <div>
                          <div className="flex items-end gap-1.5">
                            <span className="text-4xl font-black tabular-nums leading-none"
                              style={{ color: s.targetAchievedPct >= 80 ? 'var(--kpi-green)' : s.targetAchievedPct >= 60 ? 'var(--kpi-yellow)' : 'var(--kpi-red)' }}>
                              {s.output.toLocaleString()}
                            </span>
                            {s.plannedQty > 0 && (
                              <span className="text-sm font-bold mb-0.5" style={{ color: 'var(--text3)' }}>
                                / {s.plannedQty.toLocaleString()} pcs
                              </span>
                            )}
                          </div>
                          {s.plannedQty > 0 && (
                            <>
                              <p className="text-xs mt-1" style={{ color: 'var(--text4)' }}>
                                {s.targetAchievedPct}% of target
                              </p>
                              <ProgressBar value={s.targetAchievedPct} showValue height={8} />
                            </>
                          )}
                        </div>
                        <div className="grid grid-cols-2 gap-2 pt-1">
                          <div className="rounded-lg p-2.5" style={{ background: 'var(--bg2)', border: '1px solid var(--border)' }}>
                            <p className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: 'var(--text4)' }}>MTD Total</p>
                            <p className="text-lg font-black tabular-nums" style={{ color: 'var(--kpi-cyan)' }}>{s.mtdOutput.toLocaleString()}</p>
                          </div>
                          <div className="rounded-lg p-2.5" style={{ background: 'var(--bg2)', border: '1px solid var(--border)' }}>
                            <p className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: 'var(--text4)' }}>WIP</p>
                            <p className="text-lg font-black tabular-nums" style={{ color: 'var(--kpi-yellow)' }}>{s.wip.toLocaleString()}</p>
                          </div>
                        </div>
                      </div>

                      <div className="col-span-12 md:col-span-3 card flex items-center justify-center p-2">
                        <EfficiencyGauge value={s.efficiency} size={210} />
                      </div>

                      <div className="col-span-12 md:col-span-3 flex flex-col gap-3">
                        <div className="card p-4 flex-1">
                          <p className="text-[10px] font-black uppercase tracking-widest mb-1" style={{ color: 'var(--text4)' }}>
                            Plan / Earn Minutes
                          </p>
                          <p className="text-2xl font-black tabular-nums" style={{ color: 'var(--kpi-cyan)' }}>
                            {s.planMinutes.toLocaleString()} / {s.earnedMinutes.toLocaleString()}
                          </p>
                          <p className="text-xs mt-1" style={{ color: 'var(--text3)' }}>minutes</p>
                        </div>
                        <KpiCard
                          label="DHU %"
                          value={`${s.dhu.toFixed(2)}%`}
                          sub={`${s.totalDefects} defects · ${s.workerCount} workers`}
                          palKey={s.dhu <= 2 ? 'efficiency' : s.dhu <= 5 ? 'plan' : 'dhu'}
                        />
                      </div>

                      <div className="col-span-12 md:col-span-3 card flex items-center justify-center p-2">
                        <MtdRing achieved={s.mtdOutput} target={Math.max(s.plannedQty * 25, s.mtdOutput + 1)} />
                      </div>
                    </div>

                    {/* KPI strip */}
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
                      <KpiCard label="Total Output (6R)"  value={s.output}        animateNum={s.output}       palKey="output"    sub="pcs produced" />
                      <KpiCard label="Workers"            value={s.workerCount}   animateNum={s.workerCount}  palKey="workers"   sub="on floor" />
                      <KpiCard label="Rework"             value={s.rework}        animateNum={s.rework}       palKey="rework"    sub="pieces flagged" />
                      <KpiCard label="Pending Repair"     value={s.pendingRework} animateNum={s.pendingRework}
                        palKey={s.pendingRework > 10 ? 'dhu' : 'tat'}
                        badge={s.pendingRework > 10 ? { text: 'action needed', type: 'bad' } : undefined}
                      />
                      <KpiCard label="Avg Repair TAT"     value={`${s.avgRepairTat}m`}
                        palKey={s.avgRepairTat <= 30 ? 'tat' : s.avgRepairTat <= 60 ? 'plan' : 'dhu'}
                        sub="mins to close defect"
                      />
                    </div>
                  </>
                )}

                {/* 7R summary — when 7R data exists */}
                {data.lines7r.length > 0 && (
                  <div className="card p-4 animate-fade-up">
                    <SectionLabel>INA 7R — Production Info Summary</SectionLabel>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-2">
                      <KpiCard
                        label="7R Total Output"
                        value={data.lines7r.reduce((a, l) => a + l.output, 0).toLocaleString()}
                        palKey="output"
                        sub="sum across 7R lines"
                      />
                      <KpiCard
                        label="7R Workers"
                        value={data.lines7r.reduce((a, l) => a + l.workerCount, 0)}
                        palKey="workers"
                        sub="distinct employees"
                      />
                      <KpiCard
                        label="7R Defects"
                        value={data.lines7r.reduce((a, l) => a + l.totalDefects, 0)}
                        palKey="dhu"
                        sub="from quality_rework_info"
                      />
                      <KpiCard
                        label="7R Lines"
                        value={data.availableLines7r.length}
                        palKey="plan"
                        sub={data.availableLines7r.join(', ')}
                      />
                    </div>
                  </div>
                )}

                {/* SQL summary — when SQL data exists */}
                {data.linesSql.length > 0 && (
                  <div className="card p-4 animate-fade-up">
                    <SectionLabel>SQL Server — Wage & Bundle Summary</SectionLabel>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-2">
                      <KpiCard
                        label="SQL Output"
                        value={data.linesSql.reduce((a, l) => a + l.output, 0).toLocaleString()}
                        palKey="output"
                        sub="scanned pieces"
                      />
                      <KpiCard
                        label="SQL Workers"
                        value={data.linesSql.reduce((a, l) => a + l.workerCount, 0)}
                        palKey="workers"
                        sub="distinct workers"
                      />
                      <KpiCard
                        label="Total Wage (PKR)"
                        value={data.linesSql.reduce((a, l) => a + l.totalWage, 0).toLocaleString('en-PK', { maximumFractionDigits: 0 })}
                        palKey="tat"
                        sub="worker wages"
                      />
                      <KpiCard
                        label="Productive Mins"
                        value={data.linesSql.reduce((a, l) => a + l.productiveMinutes, 0).toLocaleString()}
                        palKey="plan"
                        sub="from wage bundles"
                      />
                    </div>
                  </div>
                )}

                {/* Charts — defect breakdown + daily trend */}
                <ChartsSection
                  defects={data.charts.defectBreakdown}
                  dailyTrend={data.charts.dailyTrend}
                />

                {/* Top workers */}
                {data.charts.topWorkers.length > 0 && (
                  <div className="card p-4 animate-fade-up">
                    <SectionLabel>Top 10 Workers by Efficiency (6R)</SectionLabel>
                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                      {data.charts.topWorkers.map((w, i) => (
                        <div key={w.id} className="rounded-xl p-3"
                          style={{ background: 'var(--bg2)', border: '1px solid var(--border)' }}>
                          <div className="flex items-center gap-1.5 mb-1">
                            <span className="text-[10px] font-black" style={{ color: i === 0 ? 'var(--kpi-yellow)' : 'var(--text4)' }}>#{i + 1}</span>
                            <span className="text-xs font-semibold truncate" style={{ color: 'var(--text1)' }}>{w.name}</span>
                          </div>
                          <p className="text-xl font-black tabular-nums"
                            style={{ color: w.efficiency >= 80 ? 'var(--kpi-green)' : w.efficiency >= 60 ? 'var(--kpi-yellow)' : 'var(--kpi-red)' }}>
                            {w.efficiency.toFixed(1)}%
                          </p>
                          <p className="text-[10px]" style={{ color: 'var(--text4)' }}>{w.qty.toLocaleString()} pcs</p>
                          <p className="text-[10px]" style={{ color: 'var(--text4)' }}>DHU: {w.dhu.toFixed(2)}%</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* No data state */}
                {!hasAny && !loading && (
                  <div className="card p-10 text-center animate-fade-up">
                    <p className="text-lg font-bold mb-2" style={{ color: 'var(--text3)' }}>No data found</p>
                    <p className="text-sm" style={{ color: 'var(--text4)' }}>
                      Make sure MongoDB is connected and the sync script has been run.
                    </p>
                    <code className="inline-block mt-3 px-3 py-1.5 rounded-lg text-xs font-mono"
                      style={{ background: 'var(--bg3)', color: 'var(--accent)' }}>
                      python scripts/sync.py --full
                    </code>
                  </div>
                )}
              </>
            )}

            {/* ── ALL LINES tab ─────────────────────────────────────────────── */}
            {activeTab === 'lines' && (
              <AllLinesTable
                lines6r={data.lines6r}
                lines7r={data.lines7r}
                linesSql={data.linesSql}
              />
            )}

            {/* ── WORKERS tab ───────────────────────────────────────────────── */}
            {activeTab === 'workers' && (
              <WorkerTable
                workers={workers}
                page={workerMeta.page}
                pages={workerMeta.pages}
                total={workerMeta.total}
                onPageChange={(p) => { setWorkerPage(p); void fetchWorkers() }}
                loading={workerLoading}
              />
            )}

            {/* ── TRENDS tab ────────────────────────────────────────────────── */}
            {activeTab === 'trends' && (
              <div className="space-y-4">
                <ChartsSection
                  defects={data.charts.defectBreakdown}
                  dailyTrend={data.charts.dailyTrend}
                />
                {data.charts.dailyTrend.length > 0 && (
                  <div className="card overflow-hidden animate-fade-up">
                    <div className="px-4 pt-4 pb-2"><SectionLabel>Daily Breakdown (6R)</SectionLabel></div>
                    <div className="overflow-x-auto">
                      <table className="data-table">
                        <thead>
                          <tr><th>Date</th><th>Output</th><th>Efficiency %</th><th>Defects</th><th>DHU %</th></tr>
                        </thead>
                        <tbody>
                          {[...data.charts.dailyTrend].reverse().map((d) => (
                            <tr key={d.date}>
                              <td className="font-mono font-bold text-xs" style={{ color: 'var(--accent)' }}>{d.date}</td>
                              <td className="font-bold" style={{ color: 'var(--text1)' }}>{d.output.toLocaleString()}</td>
                              <td>
                                <span className="font-black"
                                  style={{ color: d.efficiency >= 80 ? 'var(--kpi-green)' : d.efficiency >= 60 ? 'var(--kpi-yellow)' : 'var(--kpi-red)' }}>
                                  {d.efficiency.toFixed(1)}%
                                </span>
                              </td>
                              <td style={{ color: d.defects > 0 ? 'var(--kpi-orange)' : 'var(--text4)' }}>{d.defects}</td>
                              <td>
                                <span className="font-bold"
                                  style={{ color: d.dhu <= 2 ? 'var(--kpi-green)' : d.dhu <= 5 ? 'var(--kpi-yellow)' : 'var(--kpi-red)' }}>
                                  {d.dhu.toFixed(2)}%
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </main>

      {/* Floating refresh indicator */}
      {loading && hasAny && (
        <div className="fixed bottom-5 right-5 flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs shadow-xl"
          style={{ background: 'var(--surface)', border: '1px solid var(--border2)', color: 'var(--text2)' }}>
          <svg className="w-3 h-3 animate-spin" style={{ color: 'var(--accent)' }}
            viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5}>
            <path strokeLinecap="round" strokeLinejoin="round"
              d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>
          </svg>
          Refreshing…
        </div>
      )}
    </div>
  )
}
