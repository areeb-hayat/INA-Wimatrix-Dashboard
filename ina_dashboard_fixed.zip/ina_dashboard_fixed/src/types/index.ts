// src/types/index.ts

// ── 6R Line KPIs (from production_info_6r + qc_rework_info_6r) ───────────────
export interface Line6rKpis {
  source: '6r'
  line: number           // odpi_line_number (numeric)
  lineName: string       // e.g. "6R Line 15"
  output: number         // pc_key=9999 pieces
  plannedQty: number     // stpo_plannedquantity
  efficiency: number
  earnedMinutes: number
  planMinutes: number
  dhu: number
  totalDefects: number
  rework: number
  pendingRework: number
  wip: number
  avgRepairTat: number
  workerCount: number
  targetAchievedPct: number
}

// ── 7R Line KPIs (from production_info + quality_rework_info) ─────────────────
export interface Line7rKpis {
  source: '7r'
  line: string           // ppd_line_number (string like "Line11", "FIN01")
  lineName: string       // e.g. "7R Line11"
  output: number         // total ppd_quantity
  totalDefects: number   // from quality_rework_info bindquantity
  rework: number
  efficiency: number
  earnedMinutes: number
  planMinutes: number
  dhu: number
  workerCount: number
}

// ── SQL Line KPIs (from worker_wage_by_bundle + worker_wage_summary) ──────────
export interface LineSqlKpis {
  source: 'sql'
  line: string           // LineCode (e.g. "8")
  lineName: string       // LineName (e.g. "Stitching Line 08")
  output: number         // sum ScannedQuantity
  totalWage: number      // sum Wage
  workerCount: number
  productiveMinutes: number
  efficiency: number     // from WorkerWageSummary.Efficiency
}

// ── Unified line type for AllLinesTable ──────────────────────────────────────
export type AnyLineKpis = Line6rKpis | Line7rKpis | LineSqlKpis

// ── Summary (6R only — the primary KPI block) ─────────────────────────────────
export interface Summary6r {
  output: number
  plannedQty: number
  efficiency: number
  earnedMinutes: number
  planMinutes: number
  dhu: number
  totalDefects: number
  rework: number
  pendingRework: number
  wip: number
  avgRepairTat: number
  workerCount: number
  targetAchievedPct: number
}

export interface DashboardData {
  date: string
  selectedLine: string

  // Primary KPIs: 6R system (has the richest data)
  summary6r: Summary6r

  // Per-line breakdowns per source
  lines6r:  Line6rKpis[]
  lines7r:  Line7rKpis[]
  linesSql: LineSqlKpis[]

  // Charts (6R-based)
  charts: {
    defectBreakdown: { name: string; count: number }[]
    topWorkers:      { id: number; name: string; qty: number; efficiency: number; dhu: number }[]
    dailyTrend:      { date: string; label: string; output: number; efficiency: number; defects: number; dhu: number }[]
  }

  availableLines6r:  number[]
  availableLines7r:  string[]
  availableLinesSql: string[]
}

export interface WorkerRow {
  id: number
  name: string
  line: number | string
  source: '6r' | '7r' | 'sql'
  qty: number
  earnedMins: number
  efficiency: number
  wage: number
  defects: number
  dhu: number
  opCount: number
  clockIn?: string
  clockOut?: string
}

export interface TrendDay {
  date: string
  label: string
  output: number
  efficiency: number
  defects: number
  dhu: number
}

export interface SyncSource {
  source: string
  lastSyncedAt?: string
  totalRecords?: number
  status?: string
}

// ── Time filter ───────────────────────────────────────────────────────────────
export type TimeFilterPreset =
  | 'all'
  | 'yesterday'
  | 'this_week'   | 'last_week'
  | 'this_month'  | 'last_month'
  | 'last_3_months' | 'last_6_months'
  | 'custom'

export interface TimeFilter {
  preset: TimeFilterPreset
  from:   Date | null
  to:     Date | null
  label:  string
}

// ── Legacy types (keep for WorkerTable compatibility) ─────────────────────────
export interface LineKpis {
  line: number | string
  lineName: string
  source: '6r' | '7r' | 'sql'
  output: number
  plannedQty: number
  efficiency: number
  earnedMinutes: number
  planMinutes: number
  dhu: number
  totalDefects: number
  rework: number
  pendingRework: number
  wip: number
  avgRepairTat: number
  workerCount: number
  targetAchievedPct: number
  totalWage?: number
  productiveMinutes?: number
}
