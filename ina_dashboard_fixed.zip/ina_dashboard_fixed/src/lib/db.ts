// src/lib/db.ts
import mongoose from 'mongoose'

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/mga_production'

interface Cache { conn: typeof mongoose | null; promise: Promise<typeof mongoose> | null }
declare global { var __mongoCache: Cache | undefined }

const cache: Cache = global.__mongoCache ?? { conn: null, promise: null }
if (!global.__mongoCache) global.__mongoCache = cache

export async function connectDB() {
  if (cache.conn) return cache.conn
  if (!cache.promise) {
    cache.promise = mongoose.connect(MONGODB_URI, {
      bufferCommands: false,
      maxPoolSize: 10,
      serverSelectionTimeoutMS: 10000,
      socketTimeoutMS: 45000,
    })
  }
  cache.conn = await cache.promise
  return cache.conn
}
