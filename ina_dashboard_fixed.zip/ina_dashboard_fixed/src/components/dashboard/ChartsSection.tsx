'use client'
// src/components/dashboard/ChartsSection.tsx
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  ComposedChart, Line, Area,
} from 'recharts'
import { useTheme } from '@/app/context/ThemeContext'
import { SectionLabel } from '@/components/ui/KpiCard'

const DEFECT_COLORS = ['#EF4444','#F97316','#F59E0B','#EAB308','#EC4899','#A855F7','#6366F1','#3B82F6','#06B6D4','#10B981']

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function ChartTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null
  return (
    <div className="rounded-xl p-3 text-xs shadow-xl"
      style={{ background: 'var(--surface)', border: '1px solid var(--border2)' }}>
      <p className="font-bold mb-1.5" style={{ color: 'var(--text3)' }}>{label}</p>
      {payload.map((p: { name: string; value: number; color: string }, i: number) => (
        <div key={i} className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: p.color }} />
          <span style={{ color: 'var(--text3)' }}>{p.name}:</span>
          <span className="font-bold" style={{ color: 'var(--text1)' }}>{p.value}</span>
        </div>
      ))}
    </div>
  )
}

interface DefectItem  { name: string; count: number }
interface TrendItem   { label: string; output: number; efficiency: number; defects: number; dhu: number }

interface Props {
  defects:    DefectItem[]
  dailyTrend: TrendItem[]
}

function EmptyState({ msg, icon = '—', good = false }: { msg: string; icon?: string; good?: boolean }) {
  return (
    <div className="h-40 flex flex-col items-center justify-center gap-2">
      <span className="text-2xl" style={{ color: good ? 'var(--kpi-green)' : 'var(--text4)' }}>{icon}</span>
      <p className="text-xs" style={{ color: 'var(--text4)' }}>{msg}</p>
    </div>
  )
}

export function ChartsSection({ defects, dailyTrend }: Props) {
  const { isDark } = useTheme()
  const axisColor  = isDark ? '#3A6888' : '#82AAC4'
  const gridColor  = isDark ? '#1C3850' : '#C2DFF2'

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">

        {/* Defect breakdown */}
        <div className="card p-4">
          <SectionLabel>Top Defect Types (6R)</SectionLabel>
          {defects.length === 0 ? (
            <EmptyState msg="No defects recorded" icon="✓" good />
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={defects} layout="vertical" margin={{ left: 8, right: 16, top: 4, bottom: 4 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke={gridColor} />
                <XAxis type="number" tick={{ fill: axisColor, fontSize: 10 }} axisLine={false} tickLine={false} />
                <YAxis
                  type="category" dataKey="name" width={140}
                  tick={{ fill: axisColor, fontSize: 9 }} axisLine={false} tickLine={false}
                  tickFormatter={(v: string) => v.length > 22 ? v.slice(0, 22) + '…' : v}
                />
                <Tooltip content={<ChartTooltip />} />
                <Bar dataKey="count" name="Count" radius={[0, 4, 4, 0]}>
                  {defects.map((_, i) => (
                    <rect key={i} fill={DEFECT_COLORS[i % DEFECT_COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* Daily output trend */}
        <div className="card p-4">
          <SectionLabel>Daily Output Trend (6R)</SectionLabel>
          {dailyTrend.length === 0 ? (
            <EmptyState msg="No daily trend data" />
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <ComposedChart data={dailyTrend} margin={{ left: 0, right: 16, top: 4, bottom: 4 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
                <XAxis dataKey="label" tick={{ fill: axisColor, fontSize: 9 }} axisLine={false} tickLine={false} />
                <YAxis yAxisId="left"  tick={{ fill: axisColor, fontSize: 10 }} axisLine={false} tickLine={false} />
                <YAxis yAxisId="right" orientation="right" tick={{ fill: axisColor, fontSize: 10 }} axisLine={false} tickLine={false}
                  tickFormatter={(v: number) => `${v.toFixed(0)}%`} />
                <Tooltip content={<ChartTooltip />} />
                <Area yAxisId="left"  type="monotone" dataKey="output"     name="Output"     fill="rgba(14,165,233,0.1)" stroke="var(--kpi-cyan)"   strokeWidth={2} />
                <Line yAxisId="right" type="monotone" dataKey="efficiency" name="Eff %"      stroke="var(--kpi-green)"  strokeWidth={2} dot={false} />
                <Line yAxisId="right" type="monotone" dataKey="dhu"        name="DHU %"      stroke="var(--kpi-red)"    strokeWidth={1.5} dot={false} strokeDasharray="4 2" />
              </ComposedChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>
    </div>
  )
}
