'use client'
// src/components/dashboard/DashboardHeader.tsx
import { useState, useRef, useEffect } from 'react'
import { useTheme } from '@/app/context/ThemeContext'
import type { SyncSource, TimeFilter, TimeFilterPreset } from '@/types'

// ─── Time filter logic ────────────────────────────────────────────────────────
export function makeTimeFilter(preset: TimeFilterPreset): TimeFilter {
  const today = new Date(); today.setHours(0, 0, 0, 0)
  const end   = new Date(); end.setHours(23, 59, 59, 999)
  switch (preset) {
    case 'yesterday': {
      const from = new Date(today); from.setDate(from.getDate() - 1)
      const to   = new Date(from);  to.setHours(23, 59, 59, 999)
      return { preset, from, to, label: 'Yesterday' }
    }
    case 'this_week': {
      const from = new Date(today); from.setDate(today.getDate() - today.getDay())
      const to   = new Date(from);  to.setDate(from.getDate() + 6); to.setHours(23, 59, 59, 999)
      return { preset, from, to, label: 'This week' }
    }
    case 'last_week': {
      const from = new Date(today); from.setDate(today.getDate() - today.getDay() - 7)
      const to   = new Date(from);  to.setDate(from.getDate() + 6); to.setHours(23, 59, 59, 999)
      return { preset, from, to, label: 'Last week' }
    }
    case 'this_month': {
      const from = new Date(today.getFullYear(), today.getMonth(), 1)
      const to   = new Date(today.getFullYear(), today.getMonth() + 1, 0, 23, 59, 59)
      return { preset, from, to, label: 'This month' }
    }
    case 'last_month': {
      const from = new Date(today.getFullYear(), today.getMonth() - 1, 1)
      const to   = new Date(today.getFullYear(), today.getMonth(), 0, 23, 59, 59)
      return { preset, from, to, label: 'Last month' }
    }
    case 'last_3_months': {
      const from = new Date(today); from.setMonth(from.getMonth() - 3)
      return { preset, from, to: end, label: 'Last 3 months' }
    }
    case 'last_6_months': {
      const from = new Date(today); from.setMonth(from.getMonth() - 6)
      return { preset, from, to: end, label: 'Last 6 months' }
    }
    default:
      return { preset: 'all', from: null, to: null, label: 'All time' }
  }
}

const PRESETS: { key: TimeFilterPreset; label: string }[] = [
  { key: 'yesterday',     label: 'Yesterday'     },
  { key: 'this_week',     label: 'This week'     },
  { key: 'last_week',     label: 'Last week'     },
  { key: 'this_month',    label: 'This month'    },
  { key: 'last_month',    label: 'Last month'    },
  { key: 'last_3_months', label: 'Last 3 months' },
  { key: 'last_6_months', label: 'Last 6 months' },
]

function TimeFilterWidget({ filter, onChange }: { filter: TimeFilter; onChange: (f: TimeFilter) => void }) {
  const [open,       setOpen]       = useState(false)
  const [customFrom, setCustomFrom] = useState('')
  const [customTo,   setCustomTo]   = useState('')
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const h = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false)
    }
    document.addEventListener('mousedown', h)
    return () => document.removeEventListener('mousedown', h)
  }, [])

  const isFiltered = filter.preset !== 'all'

  const btnStyle = (active: boolean) => ({
    background: active ? 'var(--accent)'  : 'var(--bg2)',
    color:      active ? '#fff'           : 'var(--text2)',
    border:     `1px solid ${active ? 'var(--accent)' : 'var(--border)'}`,
    cursor:     'pointer',
    padding:    '4px 10px',
    borderRadius: '6px',
    fontSize:   '11px',
    fontWeight: 600,
    transition: 'all 0.15s',
    whiteSpace: 'nowrap' as const,
  })

  return (
    <div ref={ref} style={{ position: 'relative' }}>
      <button
        onClick={() => setOpen(o => !o)}
        style={{
          ...btnStyle(isFiltered),
          display: 'flex', alignItems: 'center', gap: 6,
        }}>
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5}>
          <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/>
          <line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>
        </svg>
        {filter.label}
        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5}>
          <polyline points="6 9 12 15 18 9"/>
        </svg>
      </button>

      {open && (
        <div style={{
          position: 'absolute', top: 'calc(100% + 6px)', right: 0, zIndex: 50,
          background: 'var(--surface)', border: '1px solid var(--border2)',
          borderRadius: '12px', padding: '10px', minWidth: '200px',
          boxShadow: '0 8px 32px rgba(0,0,0,0.18)',
        }}>
          <button
            onClick={() => { onChange(makeTimeFilter('all')); setOpen(false) }}
            style={{ ...btnStyle(filter.preset === 'all'), display: 'block', width: '100%', marginBottom: 6, textAlign: 'left' }}>
            All time
          </button>
          {PRESETS.map(({ key, label }) => (
            <button key={key}
              onClick={() => { onChange(makeTimeFilter(key)); setOpen(false) }}
              style={{ ...btnStyle(filter.preset === key), display: 'block', width: '100%', marginBottom: 4, textAlign: 'left' }}>
              {label}
            </button>
          ))}
          {/* Custom range */}
          <div style={{ borderTop: '1px solid var(--border)', paddingTop: 8, marginTop: 4 }}>
            <p style={{ fontSize: 10, color: 'var(--text4)', marginBottom: 6, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Custom range</p>
            <div style={{ display: 'flex', gap: 6, flexDirection: 'column' }}>
              <input type="date" value={customFrom} onChange={e => setCustomFrom(e.target.value)}
                style={{ background: 'var(--bg2)', border: '1px solid var(--border)', color: 'var(--text1)', borderRadius: 6, padding: '3px 6px', fontSize: 11 }} />
              <input type="date" value={customTo} onChange={e => setCustomTo(e.target.value)}
                style={{ background: 'var(--bg2)', border: '1px solid var(--border)', color: 'var(--text1)', borderRadius: 6, padding: '3px 6px', fontSize: 11 }} />
              <button
                disabled={!customFrom || !customTo}
                onClick={() => {
                  if (!customFrom || !customTo) return
                  const from = new Date(customFrom); from.setHours(0, 0, 0, 0)
                  const to   = new Date(customTo);   to.setHours(23, 59, 59, 999)
                  onChange({ preset: 'custom', from, to, label: `${customFrom} → ${customTo}` })
                  setOpen(false)
                }}
                style={{ ...btnStyle(false), opacity: (!customFrom || !customTo) ? 0.4 : 1 }}>
                Apply
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

const TABS = [
  { key: 'overview', label: 'Overview'  },
  { key: 'lines',    label: 'All Lines' },
  { key: 'workers',  label: 'Workers'   },
  { key: 'trends',   label: 'Trends'    },
]

interface Props {
  timeFilter:           TimeFilter
  onTimeFilterChange:   (f: TimeFilter) => void
  loading:              boolean
  onRefresh:            () => void
  syncSources:          SyncSource[]
  activeTab:            string
  onTabChange:          (t: string) => void
  total6rLines?:        number
  total7rLines?:        number
  totalSqlLines?:       number
}

export function DashboardHeader({
  timeFilter, onTimeFilterChange,
  loading, onRefresh,
  syncSources, activeTab, onTabChange,
  total6rLines = 0, total7rLines = 0, totalSqlLines = 0,
}: Props) {
  const { isDark, toggle } = useTheme()

  // Last sync time
  const lastSync = syncSources
    .filter(s => s.lastSyncedAt)
    .sort((a, b) => (b.lastSyncedAt ?? '').localeCompare(a.lastSyncedAt ?? ''))
    [0]

  const syncStatus = syncSources.some(s => s.status === 'error') ? 'error'
    : syncSources.length > 0 ? 'ok' : 'unknown'

  return (
    <header style={{ background: 'var(--surface)', borderBottom: '1px solid var(--border)', position: 'sticky', top: 0, zIndex: 40 }}>
      <div className="max-w-screen-2xl mx-auto w-full px-4 sm:px-6">

        {/* Top row */}
        <div className="flex items-center justify-between py-3 gap-3 flex-wrap">

          {/* Logo + title */}
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl flex items-center justify-center font-black text-xs"
              style={{ background: 'var(--accent)', color: '#fff' }}>M</div>
            <div>
              <p className="font-black text-sm leading-tight" style={{ color: 'var(--text1)' }}>MGA Production</p>
              <p className="text-[10px] leading-tight" style={{ color: 'var(--text4)' }}>Dashboard</p>
            </div>
          </div>

          {/* Source badges */}
          <div className="flex items-center gap-2 flex-wrap">
            {total6rLines > 0 && (
              <span className="px-2 py-0.5 rounded-md text-[10px] font-black uppercase"
                style={{ background: 'var(--accent)', color: '#fff' }}>
                6R · {total6rLines} lines
              </span>
            )}
            {total7rLines > 0 && (
              <span className="px-2 py-0.5 rounded-md text-[10px] font-black uppercase"
                style={{ background: 'var(--kpi-purple, #A855F7)', color: '#fff' }}>
                7R · {total7rLines} lines
              </span>
            )}
            {totalSqlLines > 0 && (
              <span className="px-2 py-0.5 rounded-md text-[10px] font-black uppercase"
                style={{ background: 'var(--kpi-orange)', color: '#fff' }}>
                SQL · {totalSqlLines} lines
              </span>
            )}
          </div>

          {/* Right controls */}
          <div className="flex items-center gap-2 ml-auto">
            <TimeFilterWidget filter={timeFilter} onChange={onTimeFilterChange} />

            {/* Sync status */}
            {lastSync && (
              <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[10px]"
                style={{ background: 'var(--bg2)', border: '1px solid var(--border)' }}>
                <span className="w-1.5 h-1.5 rounded-full"
                  style={{ background: syncStatus === 'error' ? 'var(--kpi-red)' : syncStatus === 'ok' ? 'var(--kpi-green)' : 'var(--text4)' }} />
                <span style={{ color: 'var(--text3)' }}>
                  Synced {lastSync.lastSyncedAt ? new Date(lastSync.lastSyncedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '—'}
                </span>
              </div>
            )}

            {/* Refresh */}
            <button
              onClick={onRefresh}
              disabled={loading}
              className="w-8 h-8 rounded-lg flex items-center justify-center transition-all disabled:opacity-50"
              style={{ background: 'var(--bg2)', border: '1px solid var(--border)', color: 'var(--accent)' }}>
              <svg className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5}>
                <path strokeLinecap="round" strokeLinejoin="round"
                  d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>
              </svg>
            </button>

            {/* Dark mode */}
            <button
              onClick={toggle}
              className="w-8 h-8 rounded-lg flex items-center justify-center transition-all"
              style={{ background: 'var(--bg2)', border: '1px solid var(--border)', color: 'var(--text2)' }}>
              {isDark
                ? <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>
                : <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
              }
            </button>
          </div>
        </div>

        {/* Tab row */}
        <div className="flex gap-1 pb-0">
          {TABS.map(({ key, label }) => {
            const active = activeTab === key
            return (
              <button key={key} onClick={() => onTabChange(key)}
                className="px-4 py-2 text-xs font-bold rounded-t-lg transition-all"
                style={{
                  background:   active ? 'var(--bg)' : 'transparent',
                  color:        active ? 'var(--accent)' : 'var(--text3)',
                  borderBottom: active ? '2px solid var(--accent)' : '2px solid transparent',
                }}>
                {label}
                {key === 'lines' && (total6rLines + total7rLines + totalSqlLines) > 0 && (
                  <span className="ml-1.5 px-1.5 py-0.5 rounded-full text-[9px] font-black"
                    style={{ background: active ? 'var(--accent)' : 'var(--bg3)', color: active ? '#fff' : 'var(--text4)' }}>
                    {total6rLines + total7rLines + totalSqlLines}
                  </span>
                )}
              </button>
            )
          })}
        </div>
      </div>
    </header>
  )
}
