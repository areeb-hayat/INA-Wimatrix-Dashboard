'use client'
// src/components/dashboard/AllLinesTable.tsx
import { ProgressBar } from '@/components/ui/ProgressBar'
import { SectionLabel } from '@/components/ui/KpiCard'
import type { Line6rKpis, Line7rKpis, LineSqlKpis } from '@/types'

interface Props {
  lines6r:  Line6rKpis[]
  lines7r:  Line7rKpis[]
  linesSql: LineSqlKpis[]
  onLineSelect?: (line: string, source: '6r' | '7r' | 'sql') => void
}

function SourceBadge({ source }: { source: '6r' | '7r' | 'sql' }) {
  const styles: Record<string, string> = {
    '6r':  'background: var(--accent); color: #fff;',
    '7r':  'background: var(--kpi-purple, #A855F7); color: #fff;',
    'sql': 'background: var(--kpi-orange); color: #fff;',
  }
  const labels = { '6r': 'INA 6R', '7r': 'INA 7R', 'sql': 'SQL' }
  return (
    <span
      className="inline-block rounded-md px-1.5 py-0.5 text-[9px] font-black uppercase tracking-wider"
      style={{ ...(styles[source] ? Object.fromEntries(styles[source].split(';').filter(Boolean).map(s => s.split(':').map(x => x.trim()) as [string, string])) : {}) }}>
      {labels[source]}
    </span>
  )
}

function DhuBadge({ dhu }: { dhu: number }) {
  const color = dhu <= 2 ? 'var(--kpi-green)' : dhu <= 5 ? 'var(--kpi-yellow)' : 'var(--kpi-red)'
  return <span className="font-bold text-xs" style={{ color }}>{dhu.toFixed(2)}%</span>
}

function EffCell({ value }: { value: number }) {
  return (
    <div style={{ minWidth: 110 }}>
      <ProgressBar value={value} showValue height={5} />
    </div>
  )
}

export function AllLinesTable({ lines6r, lines7r, linesSql, onLineSelect }: Props) {
  const hasAny = lines6r.length > 0 || lines7r.length > 0 || linesSql.length > 0

  if (!hasAny) {
    return (
      <div className="card p-8 text-center">
        <p className="text-sm" style={{ color: 'var(--text4)' }}>No line data for this period</p>
      </div>
    )
  }

  return (
    <div className="space-y-5 animate-fade-up">

      {/* ── 6R Lines (INA 6R: production_info_6r + qc_rework_info_6r) ── */}
      {lines6r.length > 0 && (
        <div className="card overflow-hidden">
          <div className="px-4 pt-4 pb-2 flex items-center gap-3">
            <SectionLabel>INA 6R Lines</SectionLabel>
            <SourceBadge source="6r" />
            <span className="text-[11px]" style={{ color: 'var(--text4)' }}>
              production_info_6r · qc_rework_info_6r · {lines6r.length} line{lines6r.length !== 1 ? 's' : ''}
            </span>
          </div>
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Line</th>
                  <th>Output</th>
                  <th>Target</th>
                  <th>Achieved</th>
                  <th>MTD Output</th>
                  <th>Workers</th>
                  <th>Earned Mins</th>
                  <th>Plan Mins</th>
                  <th style={{ minWidth: 120 }}>Efficiency</th>
                  <th>DHU %</th>
                  <th>Defects</th>
                  <th>Rework</th>
                  <th>Pending</th>
                  <th>WIP</th>
                  <th>Avg TAT (m)</th>
                </tr>
              </thead>
              <tbody>
                {lines6r.map((l) => (
                  <tr
                    key={`6r-${l.line}`}
                    onClick={() => onLineSelect?.(String(l.line), '6r')}
                    style={{ cursor: onLineSelect ? 'pointer' : undefined }}
                  >
                    <td>
                      <span className="font-black text-sm" style={{ color: 'var(--accent)' }}>
                        Line {l.line}
                      </span>
                    </td>
                    <td><span className="font-bold" style={{ color: 'var(--text1)' }}>{l.output.toLocaleString()}</span></td>
                    <td style={{ color: 'var(--text3)' }}>{l.plannedQty > 0 ? l.plannedQty.toLocaleString() : '—'}</td>
                    <td>
                      {l.targetAchievedPct > 0
                        ? <span className="font-bold text-xs" style={{ color: l.targetAchievedPct >= 80 ? 'var(--kpi-green)' : l.targetAchievedPct >= 60 ? 'var(--kpi-yellow)' : 'var(--kpi-red)' }}>{l.targetAchievedPct}%</span>
                        : <span style={{ color: 'var(--text4)' }}>—</span>}
                    </td>
                    <td style={{ color: 'var(--kpi-cyan)' }}>{l.mtdOutput?.toLocaleString() ?? '—'}</td>
                    <td style={{ color: 'var(--text2)' }}>{l.workerCount}</td>
                    <td style={{ color: 'var(--kpi-green)' }}>{l.earnedMinutes.toLocaleString()}</td>
                    <td style={{ color: 'var(--text3)' }}>{l.planMinutes.toLocaleString()}</td>
                    <td style={{ minWidth: 120 }}><EffCell value={l.efficiency} /></td>
                    <td><DhuBadge dhu={l.dhu} /></td>
                    <td style={{ color: l.totalDefects > 0 ? 'var(--kpi-orange)' : 'var(--text4)' }}>{l.totalDefects}</td>
                    <td style={{ color: l.rework > 0 ? 'var(--kpi-red)' : 'var(--text4)' }}>{l.rework}</td>
                    <td>
                      {l.pendingRework > 0
                        ? <span style={{ color: 'var(--kpi-red)', fontWeight: 700 }}>{l.pendingRework}</span>
                        : <span style={{ color: 'var(--text4)' }}>0</span>}
                    </td>
                    <td style={{ color: 'var(--text2)' }}>{l.wip}</td>
                    <td style={{ color: l.avgRepairTat > 60 ? 'var(--kpi-red)' : l.avgRepairTat > 30 ? 'var(--kpi-yellow)' : 'var(--kpi-green)' }}>
                      {l.avgRepairTat > 0 ? l.avgRepairTat : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ── 7R Lines (INA 7R: production_info + quality_rework_info) ── */}
      {lines7r.length > 0 && (
        <div className="card overflow-hidden">
          <div className="px-4 pt-4 pb-2 flex items-center gap-3">
            <SectionLabel>INA 7R Lines</SectionLabel>
            <SourceBadge source="7r" />
            <span className="text-[11px]" style={{ color: 'var(--text4)' }}>
              production_info · quality_rework_info · {lines7r.length} line{lines7r.length !== 1 ? 's' : ''}
            </span>
          </div>
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Line</th>
                  <th>Output</th>
                  <th>Workers</th>
                  <th>Earned Mins</th>
                  <th>Plan Mins</th>
                  <th style={{ minWidth: 120 }}>Efficiency</th>
                  <th>Defects</th>
                  <th>Rework Count</th>
                  <th>DHU %</th>
                </tr>
              </thead>
              <tbody>
                {lines7r.map((l) => (
                  <tr
                    key={`7r-${l.line}`}
                    onClick={() => onLineSelect?.(l.line, '7r')}
                    style={{ cursor: onLineSelect ? 'pointer' : undefined }}
                  >
                    <td>
                      <span className="font-black text-sm" style={{ color: 'var(--kpi-purple, #A855F7)' }}>
                        {l.line}
                      </span>
                    </td>
                    <td><span className="font-bold" style={{ color: 'var(--text1)' }}>{l.output.toLocaleString()}</span></td>
                    <td style={{ color: 'var(--text2)' }}>{l.workerCount}</td>
                    <td style={{ color: 'var(--kpi-green)' }}>{l.earnedMinutes.toLocaleString()}</td>
                    <td style={{ color: 'var(--text3)' }}>{l.planMinutes.toLocaleString()}</td>
                    <td style={{ minWidth: 120 }}><EffCell value={l.efficiency} /></td>
                    <td style={{ color: l.totalDefects > 0 ? 'var(--kpi-orange)' : 'var(--text4)' }}>{l.totalDefects}</td>
                    <td style={{ color: l.rework > 0 ? 'var(--kpi-red)' : 'var(--text4)' }}>{l.rework}</td>
                    <td><DhuBadge dhu={l.dhu} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ── SQL Lines (SQL Server: worker_wage_by_bundle + worker_wage_summary) ── */}
      {linesSql.length > 0 && (
        <div className="card overflow-hidden">
          <div className="px-4 pt-4 pb-2 flex items-center gap-3">
            <SectionLabel>SQL Server Lines</SectionLabel>
            <SourceBadge source="sql" />
            <span className="text-[11px]" style={{ color: 'var(--text4)' }}>
              worker_wage_by_bundle · worker_wage_summary · {linesSql.length} line{linesSql.length !== 1 ? 's' : ''}
            </span>
          </div>
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Line</th>
                  <th>Scanned Output</th>
                  <th>Workers</th>
                  <th>Productive Mins</th>
                  <th style={{ minWidth: 120 }}>Efficiency</th>
                  <th>Total Wage (PKR)</th>
                </tr>
              </thead>
              <tbody>
                {linesSql.map((l) => (
                  <tr
                    key={`sql-${l.line}`}
                    onClick={() => onLineSelect?.(l.line, 'sql')}
                    style={{ cursor: onLineSelect ? 'pointer' : undefined }}
                  >
                    <td>
                      <div className="font-black text-sm" style={{ color: 'var(--kpi-orange)' }}>{l.lineName}</div>
                      <div className="text-[10px] font-mono" style={{ color: 'var(--text4)' }}>Code: {l.line}</div>
                    </td>
                    <td><span className="font-bold" style={{ color: 'var(--text1)' }}>{l.output.toLocaleString()}</span></td>
                    <td style={{ color: 'var(--text2)' }}>{l.workerCount}</td>
                    <td style={{ color: 'var(--kpi-green)' }}>{l.productiveMinutes.toLocaleString()}</td>
                    <td style={{ minWidth: 120 }}><EffCell value={l.efficiency} /></td>
                    <td>
                      <span className="font-mono text-[11px]" style={{ color: 'var(--accent)' }}>
                        {l.totalWage.toLocaleString('en-PK', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}
