// src/components/ui/KpiCard.tsx
'use client'
import { useEffect, useState } from 'react'
import { useTheme } from '@/app/context/ThemeContext'

function useCountUp(target: number, ms = 700): number {
  const [v, setV] = useState(0)
  useEffect(() => {
    let t0: number | null = null
    const step = (ts: number) => {
      if (!t0) t0 = ts
      const p = Math.min((ts - t0) / ms, 1)
      setV(Math.round((1 - Math.pow(1 - p, 3)) * target))
      if (p < 1) requestAnimationFrame(step)
    }
    requestAnimationFrame(step)
  }, [target, ms])
  return v
}

interface Pal { bgL: string; bgD: string; bL: string; bD: string; accent: string; icon: string }

const PAL: Record<string, Pal> = {
  output:     { bgL:'#EFF6FF', bgD:'rgba(47,168,223,0.08)',  bL:'#BFDBFE', bD:'rgba(47,168,223,0.18)',  accent:'var(--kpi-cyan)',   icon:'⊡' },
  efficiency: { bgL:'#F0FDF4', bgD:'rgba(15,123,66,0.08)',   bL:'#BBF7D0', bD:'rgba(15,123,66,0.18)',   accent:'var(--kpi-green)',  icon:'%' },
  dhu:        { bgL:'#FFF1F2', bgD:'rgba(192,26,26,0.08)',   bL:'#FECDD3', bD:'rgba(192,26,26,0.18)',   accent:'var(--kpi-red)',    icon:'⚠' },
  rework:     { bgL:'#FFF7ED', bgD:'rgba(192,80,0,0.08)',    bL:'#FED7AA', bD:'rgba(192,80,0,0.18)',    accent:'var(--kpi-orange)', icon:'↺' },
  wip:        { bgL:'#F5F3FF', bgD:'rgba(109,40,217,0.08)',  bL:'#DDD6FE', bD:'rgba(109,40,217,0.18)',  accent:'var(--kpi-purple)', icon:'◉' },
  plan:       { bgL:'#FFFBEB', bgD:'rgba(168,92,8,0.08)',    bL:'#FDE68A', bD:'rgba(168,92,8,0.18)',    accent:'var(--kpi-yellow)', icon:'⏱' },
  workers:    { bgL:'#EFF6FF', bgD:'rgba(47,168,223,0.08)',  bL:'#BFDBFE', bD:'rgba(47,168,223,0.18)',  accent:'var(--kpi-cyan)',   icon:'人' },
  tat:        { bgL:'#ECFDF5', bgD:'rgba(15,123,66,0.08)',   bL:'#A7F3D0', bD:'rgba(15,123,66,0.18)',   accent:'var(--kpi-green)',  icon:'⏳' },
  mtd:        { bgL:'#EFF6FF', bgD:'rgba(47,168,223,0.08)',  bL:'#BFDBFE', bD:'rgba(47,168,223,0.18)',  accent:'var(--kpi-cyan)',   icon:'📅' },
}

interface CardProps {
  label:       string
  value:       string | number
  sub?:        string
  palKey:      string
  animateNum?: number
  badge?:      { text: string; type: 'ok' | 'warn' | 'bad' }
}

export function KpiCard({ label, value, sub, palKey, animateNum, badge }: CardProps) {
  const { isDark } = useTheme()
  const animated   = useCountUp(animateNum ?? 0)
  const pal        = PAL[palKey] || PAL.output
  const display    = animateNum != null
    ? animated.toLocaleString('en-PK')
    : typeof value === 'number' ? value.toLocaleString('en-PK') : value

  return (
    <div className="rounded-xl p-4 transition-all duration-200"
      style={{ background: isDark ? pal.bgD : pal.bgL, border: `1.5px solid ${isDark ? pal.bD : pal.bL}` }}>
      <div className="flex items-start justify-between mb-2">
        <p className="text-[11px] font-semibold uppercase tracking-wider" style={{ color: pal.accent }}>
          {label}
        </p>
        <span className="text-sm opacity-40" style={{ color: pal.accent }}>{pal.icon}</span>
      </div>
      <p className="text-2xl font-black tabular-nums leading-none" style={{ color: pal.accent }}>
        {display}
      </p>
      {sub && <p className="text-[11px] mt-1.5" style={{ color: 'var(--text3)' }}>{sub}</p>}
      {badge && (
        <span className={`inline-block mt-1.5 px-2 py-0.5 rounded-md text-[10px] font-bold
          ${badge.type === 'ok' ? 'badge-ok' : badge.type === 'warn' ? 'badge-risk' : 'badge-delay'}`}>
          {badge.text}
        </span>
      )}
    </div>
  )
}

export function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <p className="text-[10px] font-black uppercase tracking-widest mb-2" style={{ color: 'var(--text4)' }}>
      {children}
    </p>
  )
}
