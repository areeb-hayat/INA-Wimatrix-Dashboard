// src/components/ui/LoadingSkeleton.tsx
'use client'

function Shimmer({ className }: { className?: string }) {
  return <div className={`rounded-lg animate-shimmer ${className ?? ''}`} style={{ background: 'var(--bg3)' }} />
}

export function LoadingSkeleton() {
  return (
    <div className="space-y-5 py-6">
      <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-6 gap-3">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="card p-4 space-y-3">
            <Shimmer className="w-20 h-3" />
            <Shimmer className="w-14 h-7" />
            <Shimmer className="w-24 h-3" />
          </div>
        ))}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {Array.from({ length: 2 }).map((_, i) => (
          <div key={i} className="card p-5 space-y-3">
            <Shimmer className="w-40 h-4" />
            {Array.from({ length: 5 }).map((_, j) => (
              <div key={j} className="flex gap-3">
                <Shimmer className="w-28 h-3" />
                <Shimmer className="flex-1 h-3" />
                <Shimmer className="w-12 h-3" />
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  )
}
