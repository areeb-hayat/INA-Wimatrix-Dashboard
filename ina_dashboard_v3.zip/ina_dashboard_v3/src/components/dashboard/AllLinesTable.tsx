'use client'
// src/components/dashboard/AllLinesTable.tsx
import { useState, useEffect, useRef } from 'react'
import { ProgressBar } from '@/components/ui/ProgressBar'
import { SectionLabel } from '@/components/ui/KpiCard'
import type { LineKpis } from '@/types'

interface Props {
  lines:        LineKpis[]
  onLineSelect: (line: string) => void
  selectedLine: string
}

// ── Mini donut ring for the modal ──────────────────────────────────────────────
function DonutRing({
  value, max, color, size = 72, label, sub,
}: {
  value: number; max: number; color: string; size?: number; label: string; sub?: string
}) {
  const r    = (size - 12) / 2
  const circ = 2 * Math.PI * r
  const pct  = max > 0 ? Math.min(value / max, 1) : 0
  const dash = pct * circ
  return (
    <div className="flex flex-col items-center gap-1">
      <div style={{ position: 'relative', width: size, height: size }}>
        <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}
          style={{ transform: 'rotate(-90deg)' }}>
          <circle cx={size / 2} cy={size / 2} r={r}
            fill="none" stroke="var(--gauge-track)" strokeWidth={8} />
          <circle cx={size / 2} cy={size / 2} r={r}
            fill="none" stroke={color} strokeWidth={8}
            strokeDasharray={`${dash} ${circ}`}
            strokeLinecap="round"
            style={{ transition: 'stroke-dasharray 0.7s ease' }}
          />
        </svg>
        <div style={{
          position: 'absolute', inset: 0,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <span style={{
            fontSize: label.length > 5 ? 9 : 11,
            fontWeight: 900, color, lineHeight: 1, textAlign: 'center',
          }}>
            {label}
          </span>
        </div>
      </div>
      {sub && (
        <span className="text-[10px] font-semibold text-center"
          style={{ color: 'var(--text3)' }}>
          {sub}
        </span>
      )}
    </div>
  )
}

// ── Line detail modal ──────────────────────────────────────────────────────────
function LineModal({ line, onClose, maxOutput }: {
  line: LineKpis; onClose: () => void; maxOutput: number
}) {
  const ref = useRef<HTMLDivElement>(null)

  // Close on outside click
  useEffect(() => {
    function handler(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) onClose()
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [onClose])

  // Close on Escape
  useEffect(() => {
    function handler(e: KeyboardEvent) { if (e.key === 'Escape') onClose() }
    document.addEventListener('keydown', handler)
    return () => document.removeEventListener('keydown', handler)
  }, [onClose])

  const effColor = line.efficiency >= 80 ? 'var(--kpi-green)'
    : line.efficiency >= 60 ? 'var(--kpi-yellow)' : 'var(--kpi-red)'
  const dhuColor = line.dhu <= 2 ? 'var(--kpi-green)'
    : line.dhu <= 5 ? 'var(--kpi-yellow)' : 'var(--kpi-red)'
  const defects  = line.totalDefects > 0 ? line.totalDefects : line.defects7r

  const rows: { label: string; value: string | number; color?: string }[] = [
    { label: 'Output',         value: line.output.toLocaleString(),                        color: 'var(--kpi-cyan)'    },
    { label: 'Workers',        value: line.workerCount                                                                  },
    { label: 'Earned Mins',    value: line.earnedMinutes > 0 ? line.earnedMinutes.toLocaleString() : '—',
                                                                                           color: 'var(--kpi-green)'   },
    { label: 'Plan Mins',      value: line.planMinutes > 0 ? line.planMinutes.toLocaleString() : '—'                   },
    { label: 'DHU %',          value: line.dhu > 0 ? `${line.dhu.toFixed(2)}%` : '—',     color: dhuColor              },
    { label: 'Defects',        value: defects > 0 ? defects : '—',                        color: 'var(--kpi-orange)'  },
    { label: 'Rework',         value: line.rework > 0 ? line.rework : '—',                color: 'var(--kpi-orange)'  },
    { label: 'Pending Repair', value: line.pendingRework > 0 ? line.pendingRework : '—',  color: 'var(--kpi-red)'     },
    { label: 'WIP',            value: line.wip > 0 ? line.wip.toLocaleString() : '—',     color: 'var(--kpi-yellow)'  },
    { label: 'Wage (PKR)',     value: line.totalWage > 0
        ? line.totalWage.toLocaleString('en-PK', { maximumFractionDigits: 0 })
        : '—',                                                                             color: 'var(--accent)'      },
  ]

  return (
    <div
      style={{
        position: 'fixed', inset: 0, zIndex: 9999,
        background: 'rgba(0,0,0,0.55)', backdropFilter: 'blur(3px)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: '1rem',
      }}
    >
      <div
        ref={ref}
        className="animate-fade-up"
        style={{
          background: 'var(--surface)',
          border: '1px solid var(--border2)',
          borderRadius: '1.25rem',
          boxShadow: '0 24px 60px rgba(0,0,0,0.4)',
          width: '100%', maxWidth: 480,
          overflow: 'hidden',
        }}
      >
        {/* Header */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '1rem 1.25rem',
          borderBottom: '1px solid var(--border)',
        }}>
          <div>
            <p className="text-[10px] font-black uppercase tracking-widest"
              style={{ color: 'var(--text4)' }}>
              {line.system === 'ina_6r' ? 'INA 6R'
                : line.system === 'ina_7r' ? 'INA 7R' : 'WiMatrix SQL'}
            </p>
            <h3 className="text-xl font-black" style={{ color: 'var(--text1)' }}>
              {line.lineName}
            </h3>
          </div>
          <button
            onClick={onClose}
            style={{
              width: 32, height: 32, borderRadius: '50%',
              background: 'var(--bg2)', border: '1px solid var(--border)',
              cursor: 'pointer', color: 'var(--text2)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 16, lineHeight: 1,
            }}
          >×</button>
        </div>

        {/* Donut row */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-around',
          padding: '1.25rem 1rem',
          borderBottom: '1px solid var(--border)',
          background: 'var(--bg2)',
        }}>
          <DonutRing
            value={line.efficiency} max={100} color={effColor} size={80}
            label={`${line.efficiency.toFixed(1)}%`} sub="Efficiency"
          />
          <DonutRing
            value={line.output} max={maxOutput} color="var(--kpi-cyan)" size={80}
            label={line.output >= 1_000_000 ? `${(line.output / 1_000_000).toFixed(1)}M`
              : line.output >= 1000 ? `${(line.output / 1000).toFixed(1)}k`
              : String(line.output)}
            sub="Output"
          />
          {(line.dhu > 0 || defects > 0) ? (
            <DonutRing
              value={line.dhu > 0 ? line.dhu : defects}
              max={line.dhu > 0 ? 20 : Math.max(defects * 2, 1)}
              color={line.dhu > 0 ? dhuColor : 'var(--kpi-orange)'} size={80}
              label={line.dhu > 0 ? `${line.dhu.toFixed(1)}%` : String(defects)}
              sub={line.dhu > 0 ? 'DHU %' : 'Defects'}
            />
          ) : line.totalWage > 0 ? (
            <DonutRing
              value={1} max={1} color="var(--kpi-yellow)" size={80}
              label={`${(line.totalWage / 1000).toFixed(0)}k`}
              sub="Wage PKR"
            />
          ) : (
            <DonutRing
              value={0} max={1} color="var(--text4)" size={80}
              label="—" sub="No QC data"
            />
          )}
        </div>

        {/* Stats grid */}
        <div style={{ padding: '1rem 1.25rem' }}>
          <div style={{
            display: 'grid', gridTemplateColumns: '1fr 1fr',
            gap: '0.5rem 1rem',
          }}>
            {rows.map(({ label, value, color }) => (
              <div key={label} style={{
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                padding: '0.4rem 0.6rem',
                borderRadius: '0.5rem',
                background: 'var(--bg2)',
              }}>
                <span className="text-[11px]" style={{ color: 'var(--text4)' }}>{label}</span>
                <span className="text-[12px] font-black tabular-nums"
                  style={{ color: color || 'var(--text1)' }}>
                  {value}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

// ── Comparison panel: top-N lines by output ────────────────────────────────────
function ComparisonBar({ lines }: { lines: LineKpis[] }) {
  const top = [...lines].sort((a, b) => b.output - a.output).slice(0, 8)
  const max  = top[0]?.output || 1
  return (
    <div className="card p-4 animate-fade-up">
      <SectionLabel>Top Lines by Output</SectionLabel>
      <div className="space-y-2 mt-2">
        {top.map((l, i) => {
          const pct = (l.output / max) * 100
          const effColor = l.efficiency >= 80 ? 'var(--kpi-green)'
            : l.efficiency >= 60 ? 'var(--kpi-yellow)' : 'var(--kpi-red)'
          return (
            <div key={l.line}>
              <div className="flex justify-between items-center mb-0.5">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black tabular-nums w-4"
                    style={{ color: i < 3 ? 'var(--kpi-yellow)' : 'var(--text4)' }}>
                    #{i + 1}
                  </span>
                  <span className="text-xs font-bold" style={{ color: 'var(--text1)' }}>
                    {l.lineName}
                  </span>
                  {l.efficiency > 0 && (
                    <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-full"
                      style={{
                        background: `${effColor}22`,
                        color: effColor,
                        border: `1px solid ${effColor}44`,
                      }}>
                      {l.efficiency.toFixed(0)}% eff
                    </span>
                  )}
                </div>
                <span className="text-xs font-black tabular-nums" style={{ color: 'var(--kpi-cyan)' }}>
                  {l.output.toLocaleString()}
                </span>
              </div>
              <div className="h-1.5 rounded-full" style={{ background: 'var(--gauge-track)' }}>
                <div className="h-full rounded-full transition-all duration-700"
                  style={{ width: `${pct}%`, background: 'var(--kpi-cyan)' }} />
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

// ── Main export ────────────────────────────────────────────────────────────────
export function AllLinesTable({ lines, onLineSelect, selectedLine }: Props) {
  const [modalLine, setModalLine] = useState<LineKpis | null>(null)

  if (!lines.length) {
    return (
      <div className="card p-8 text-center">
        <p className="text-sm" style={{ color: 'var(--text4)' }}>No line data for this period</p>
      </div>
    )
  }

  const maxOutput = Math.max(...lines.map(l => l.output), 1)

  return (
    <>
      {/* Comparison summary */}
      <ComparisonBar lines={lines} />

      {/* Main table */}
      <div className="card overflow-hidden animate-fade-up">
        <div className="px-4 pt-4 pb-2 flex items-center justify-between">
          <SectionLabel>All Lines</SectionLabel>
          <span className="text-[11px]" style={{ color: 'var(--text4)' }}>
            {lines.length} line{lines.length !== 1 ? 's' : ''} · click row for detail
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="data-table">
            <thead>
              <tr>
                <th>Line</th>
                <th>System</th>
                <th>Output</th>
                <th>Workers</th>
                <th>Earned Mins</th>
                <th>Plan Mins</th>
                <th style={{ minWidth: 140 }}>Efficiency</th>
                <th>DHU %</th>
                <th>Defects</th>
                <th>Rework</th>
                <th>Pending</th>
                <th>WIP</th>
                <th>Wage (PKR)</th>
              </tr>
            </thead>
            <tbody>
              {lines.map((l) => {
                const active   = selectedLine === l.line
                const defects  = l.totalDefects > 0 ? l.totalDefects : l.defects7r
                const systemBadge = l.system === 'ina_6r' ? { label: '6R', color: 'var(--kpi-cyan)' }
                  : l.system === 'ina_7r' ? { label: '7R', color: 'var(--kpi-green)' }
                  : { label: 'Wimatrix', color: 'var(--kpi-yellow)' }

                return (
                  <tr key={l.line}
                    onClick={() => setModalLine(l)}
                    style={{
                      cursor: 'pointer',
                      background: active ? 'var(--info-bg)' : undefined,
                    }}>
                    <td>
                      <span className="font-black text-sm" style={{ color: 'var(--accent)' }}>
                        {l.lineName}
                      </span>
                    </td>
                    <td>
                      <span className="text-[10px] font-bold px-1.5 py-0.5 rounded"
                        style={{
                          background: `${systemBadge.color}22`,
                          color: systemBadge.color,
                        }}>
                        {systemBadge.label}
                      </span>
                    </td>
                    <td>
                      <span className="font-bold" style={{ color: 'var(--kpi-cyan)' }}>
                        {l.output.toLocaleString()}
                      </span>
                    </td>
                    <td style={{ color: 'var(--text2)' }}>{l.workerCount}</td>
                    <td style={{ color: 'var(--kpi-green)' }}>
                      {l.earnedMinutes > 0 ? l.earnedMinutes.toLocaleString() : '—'}
                    </td>
                    <td style={{ color: 'var(--text3)' }}>
                      {l.planMinutes > 0 ? l.planMinutes.toLocaleString() : '—'}
                    </td>
                    <td style={{ minWidth: 140 }}>
                      {l.efficiency > 0
                        ? <ProgressBar value={l.efficiency} showValue height={6} max={150} />
                        : <span style={{ color: 'var(--text4)' }}>—</span>}
                    </td>
                    <td>
                      {l.dhu > 0
                        ? <span className="font-bold text-xs" style={{
                            color: l.dhu <= 2 ? 'var(--kpi-green)'
                              : l.dhu <= 5 ? 'var(--kpi-yellow)' : 'var(--kpi-red)',
                          }}>{l.dhu.toFixed(2)}%</span>
                        : <span style={{ color: 'var(--text4)' }}>—</span>}
                    </td>
                    <td>
                      <span style={{ color: defects > 0 ? 'var(--kpi-orange)' : 'var(--text4)' }}>
                        {defects > 0 ? defects.toLocaleString() : '—'}
                      </span>
                    </td>
                    <td>
                      <span style={{ color: l.rework > 0 ? 'var(--kpi-orange)' : 'var(--text4)' }}>
                        {l.rework > 0 ? l.rework : '—'}
                      </span>
                    </td>
                    <td>
                      <span style={{ color: l.pendingRework > 0 ? 'var(--kpi-red)' : 'var(--text4)' }}>
                        {l.pendingRework > 0 ? l.pendingRework : '—'}
                      </span>
                    </td>
                    <td>
                      <span style={{ color: l.wip > 0 ? 'var(--kpi-yellow)' : 'var(--text4)' }}>
                        {l.wip > 0 ? l.wip.toLocaleString() : '—'}
                      </span>
                    </td>
                    <td>
                      {l.totalWage > 0
                        ? <span className="font-mono text-[11px]" style={{ color: 'var(--accent)' }}>
                            {l.totalWage.toLocaleString('en-PK', { maximumFractionDigits: 0 })}
                          </span>
                        : <span style={{ color: 'var(--text4)' }}>—</span>}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal */}
      {modalLine && (
        <LineModal
          line={modalLine}
          maxOutput={maxOutput}
          onClose={() => setModalLine(null)}
        />
      )}
    </>
  )
}