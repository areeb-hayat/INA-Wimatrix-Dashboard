'use client'
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  ComposedChart, Line, Area, Cell,
} from 'recharts'
import { useTheme } from '@/app/context/ThemeContext'
import { SectionLabel } from '@/components/ui/KpiCard'

const DEFECT_COLORS = ['#EF4444','#F97316','#F59E0B','#EAB308','#EC4899','#A855F7','#6366F1','#3B82F6','#06B6D4','#10B981']

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function ChartTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null
  return (
    <div className="rounded-xl p-3 text-xs shadow-xl"
      style={{ background: 'var(--surface)', border: '1px solid var(--border2)' }}>
      <p className="font-bold mb-1.5" style={{ color: 'var(--text3)' }}>{label}</p>
      {payload.map((p: { name: string; value: number; color: string }, i: number) => (
        <div key={i} className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: p.color }} />
          <span style={{ color: 'var(--text3)' }}>{p.name}:</span>
          <span className="font-bold" style={{ color: 'var(--text1)' }}>
            {p.name === 'Efficiency %' ? `${p.value}%` : p.value.toLocaleString()}
          </span>
        </div>
      ))}
    </div>
  )
}

interface DefectItem  { name: string; count: number }
// hourlyTrend is now repurposed as daily: hour = date label, target = efficiency%
interface HourlyItem  { hour: string; qty: number; target: number }
interface TrendItem   { label: string; output: number; efficiency: number; dhu: number }

interface Props {
  defects: DefectItem[]
  hourly:  HourlyItem[]   // actually daily output data from API
  trend:   TrendItem[]
}

function EmptyState({ msg, icon = '—', good = false }: { msg: string; icon?: string; good?: boolean }) {
  return (
    <div className="h-40 flex flex-col items-center justify-center gap-2">
      <span className="text-2xl" style={{ color: good ? 'var(--kpi-green)' : 'var(--text4)' }}>{icon}</span>
      <p className="text-xs" style={{ color: 'var(--text4)' }}>{msg}</p>
    </div>
  )
}

export function ChartsSection({ defects, hourly, trend }: Props) {
  const { isDark } = useTheme()
  const axisColor  = isDark ? '#3A6888' : '#82AAC4'
  const gridColor  = isDark ? '#1C3850' : '#C2DFF2'

  // Determine if we have meaningful data in the daily trend
  const hasDailyData = hourly.length > 0
  // Decide whether to show short date labels or abbreviated ones based on count
  const tickInterval = hourly.length > 14 ? Math.floor(hourly.length / 7) : 0

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">

        {/* ── Daily Output (replaces hourly — data is synced to yesterday, not live) ── */}
        <div className="card p-4">
          <div className="flex items-center justify-between mb-1">
            <SectionLabel>Daily Output Trend</SectionLabel>
            <span className="text-[10px] px-2 py-0.5 rounded-full font-semibold"
              style={{ background: 'var(--bg2)', color: 'var(--text4)', border: '1px solid var(--border)' }}>
              Synced to yesterday
            </span>
          </div>
          {!hasDailyData ? (
            <EmptyState msg="No daily output data for this period" />
          ) : (
            <ResponsiveContainer width="100%" height={200}>
              <ComposedChart data={hourly} barSize={14}>
                <CartesianGrid stroke={gridColor} strokeDasharray="3 3" vertical={false} />
                <XAxis
                  dataKey="hour"
                  tick={{ fontSize: 9, fill: axisColor }}
                  axisLine={false}
                  tickLine={false}
                  interval={tickInterval}
                />
                <YAxis yAxisId="left" tick={{ fontSize: 9, fill: axisColor }} axisLine={false} tickLine={false} />
                <YAxis yAxisId="right" orientation="right"
                  tick={{ fontSize: 9, fill: axisColor }} axisLine={false} tickLine={false}
                  domain={[0, 150]} tickFormatter={(v) => `${v}%`} />
                <Tooltip content={<ChartTooltip />} />
                <Bar yAxisId="left" dataKey="qty" name="Output" radius={[3, 3, 0, 0]}>
                  {hourly.map((h, i) => (
                    <Cell
                      key={i}
                      fill={
                        h.target >= 80 ? 'var(--kpi-green)'
                          : h.target >= 60 ? 'var(--kpi-yellow)'
                          : h.target > 0 ? 'var(--kpi-red)'
                          : 'var(--border2)'
                      }
                    />
                  ))}
                </Bar>
                {/* Efficiency overlay — only if we have efficiency data (target field repurposed) */}
                {hourly.some(h => h.target > 0) && (
                  <Line
                    yAxisId="right"
                    dataKey="target"
                    name="Efficiency %"
                    stroke="var(--kpi-cyan)"
                    strokeWidth={1.5}
                    dot={false}
                    strokeDasharray="4 2"
                  />
                )}
              </ComposedChart>
            </ResponsiveContainer>
          )}
          {hasDailyData && hourly.some(h => h.target > 0) && (
            <div className="flex items-center gap-4 mt-1">
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-sm" style={{ background: 'var(--kpi-green)' }} />
                <span className="text-[9px]" style={{ color: 'var(--text4)' }}>≥80% eff</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-sm" style={{ background: 'var(--kpi-yellow)' }} />
                <span className="text-[9px]" style={{ color: 'var(--text4)' }}>60–79%</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-sm" style={{ background: 'var(--kpi-red)' }} />
                <span className="text-[9px]" style={{ color: 'var(--text4)' }}>&lt;60%</span>
              </div>
              <div className="flex items-center gap-1.5 ml-auto">
                <div className="w-4 h-0.5" style={{ background: 'var(--kpi-cyan)', borderTop: '1px dashed var(--kpi-cyan)' }} />
                <span className="text-[9px]" style={{ color: 'var(--text4)' }}>Efficiency %</span>
              </div>
            </div>
          )}
        </div>

        {/* ── Defect breakdown ── */}
        <div className="card p-4">
          <SectionLabel>Top Defect Types</SectionLabel>
          {defects.length === 0 ? <EmptyState msg="No defects recorded" icon="✓" good /> : (
            <div className="space-y-2 max-h-48 overflow-y-auto pr-1 mt-1">
              {defects.map((d, i) => {
                const pct = (d.count / defects[0].count) * 100
                return (
                  <div key={i}>
                    <div className="flex justify-between mb-0.5">
                      <span className="text-xs truncate pr-2 max-w-[75%]" style={{ color: 'var(--text2)' }}>{d.name}</span>
                      <span className="text-xs font-bold tabular-nums" style={{ color: DEFECT_COLORS[i % 10] }}>{d.count.toLocaleString()}</span>
                    </div>
                    <div className="h-1.5 rounded-full" style={{ background: 'var(--gauge-track)' }}>
                      <div className="h-full rounded-full transition-all duration-700"
                        style={{ width: `${pct}%`, background: DEFECT_COLORS[i % 10] }} />
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </div>
      </div>

      {/* ── Output & Efficiency Trend ── */}
      {trend.length > 0 && (
        <div className="card p-4">
          <SectionLabel>Output &amp; Efficiency Trend (14 days)</SectionLabel>
          <ResponsiveContainer width="100%" height={200}>
            <ComposedChart data={trend} margin={{ top: 4, right: 40, left: 0, bottom: 0 }}>
              <CartesianGrid stroke={gridColor} strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="label" tick={{ fontSize: 9, fill: axisColor }} axisLine={false} tickLine={false} />
              <YAxis yAxisId="left" tick={{ fontSize: 9, fill: axisColor }} axisLine={false} tickLine={false} />
              <YAxis yAxisId="right" orientation="right"
                tick={{ fontSize: 9, fill: axisColor }} axisLine={false} tickLine={false}
                domain={[0, 150]} tickFormatter={(v) => `${v}%`} />
              <Tooltip content={<ChartTooltip />} />
              <Area yAxisId="left"
                type="monotone" dataKey="output" name="Output"
                fill="var(--accent-muted)" stroke="var(--accent)" strokeWidth={2}
                fillOpacity={0.15} dot={false} />
              <Line yAxisId="right"
                type="monotone" dataKey="efficiency" name="Efficiency %"
                stroke="var(--kpi-green)" strokeWidth={2} dot={{ r: 3, fill: 'var(--kpi-green)' }} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  )
}