'use client'

interface Props {
  value:      number   // actual value
  max?:       number   // scale max, defaults to 100
  showValue?: boolean
  height?:    number
}

export function ProgressBar({ value, max = 100, showValue, height = 6 }: Props) {
  // Percentage for bar width — never exceed 100% visually
  const pct     = max > 0 ? Math.min((value / max) * 100, 100) : 0
  // Color thresholds based on % of max
  const color   = pct >= 80 ? 'var(--kpi-green)' : pct >= 60 ? 'var(--kpi-yellow)' : 'var(--kpi-red)'

  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 rounded-full overflow-hidden" style={{ height, background: 'var(--gauge-track)' }}>
        <div
          className="h-full rounded-full transition-all duration-700"
          style={{ width: `${pct}%`, background: color }}
        />
      </div>
      {showValue && (
        <span className="text-[11px] font-black tabular-nums w-12 text-right" style={{ color }}>
          {value.toFixed(1)}%
        </span>
      )}
    </div>
  )
}