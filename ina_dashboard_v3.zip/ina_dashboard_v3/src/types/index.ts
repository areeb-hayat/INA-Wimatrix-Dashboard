// src/types/index.ts

// ─── Which system a line belongs to ──────────────────────────────────────────
// 'ina_6r'  = production_info_6r + qc_rework_info_6r  (INA Hangers, 6R system)
// 'ina_7r'  = production_info + quality_rework_info    (INA Hangers, 7R system)
// 'sql'     = worker_wage_by_bundle + worker_wage_summary (WiMatrix / SQL Server)
export type LineSystem = 'ina_6r' | 'ina_7r' | 'sql'

// ─── Unified LineKpis — used for ALL lines regardless of source ───────────────
// Fields not available for a given source are set to 0 / null.
// The dashboard shows all lines together; the system filter lets users narrow down.
export interface LineKpis {
  // Identity
  line:       string       // unique key: "15" (6r numeric), "Line11" (7r string), "8" (sql code)
  lineName:   string       // display label, e.g. "Line 15", "Line11", "Stitching Line 08"
  system:     LineSystem   // which data source

  // Production
  output:         number   // finished pieces (pc_key=9999 for 6r; ppd_quantity for 7r; ScannedQuantity for sql)
  workerCount:    number   // distinct workers
  earnedMinutes:  number   // earned / productive minutes
  planMinutes:    number   // workers × 480 (0 for sql)
  efficiency:     number   // %

  // Quality (6r only — 0 for 7r/sql which lack this granularity)
  dhu:            number   // Defects per Hundred Units %
  totalDefects:   number
  rework:         number   // total rework events
  pendingRework:  number   // unrepaired rework
  avgRepairTat:   number   // minutes
  wip:            number   // loaded - unloaded

  // MTD (6r only)
  mtdOutput:      number

  // 7R quality (from quality_rework_info)
  defects7r:      number   // bindquantity sum

  // SQL financials
  totalWage:        number   // PKR
  productiveMinutes: number  // from wage bundles

  // NOTE: plannedQty / targetAchievedPct removed — stpo_plannedquantity is
  // test/seed data (value=500), not a real daily production target.
}

// ─── Dashboard summary (aggregated across all selected lines) ─────────────────
export interface DashboardData {
  date:         string
  selectedLine: string   // 'all' | line key | system filter ('ina_6r'|'ina_7r'|'sql')

  summary: {
    output:         number
    efficiency:     number
    earnedMinutes:  number
    planMinutes:    number
    dhu:            number
    totalDefects:   number
    rework:         number
    pendingRework:  number
    wip:            number
    mtdOutput:      number
    avgRepairTat:   number
    workerCount:    number
    totalWage:      number
  }

  allLines: LineKpis[]

  charts: {
    defectBreakdown: { name: string; count: number }[]
    hourlyTrend:     { hour: string; qty: number; target: number }[]
    topWorkers:      { id: number; name: string; qty: number; efficiency: number; dhu: number }[]
  }

  // All unique line keys in data (used to populate line selector)
  availableLines: string[]
}

export interface WorkerRow {
  id:         number
  name:       string
  line:       number | string
  qty:        number
  earnedMins: number
  efficiency: number
  wage:       number
  defects:    number
  dhu:        number
  opCount:    number
  clockIn?:   string
  clockOut?:  string
}

export interface TrendDay {
  date:       string
  label:      string
  output:     number
  efficiency: number
  defects:    number
  dhu:        number
}

export interface SyncSource {
  source:        string
  lastSyncedAt?: string
  totalRecords?: number
  status?:       string
}

// ── Time filter ───────────────────────────────────────────────────────────────
export type TimeFilterPreset =
  | 'all'
  | 'yesterday'
  | 'this_week'   | 'last_week'
  | 'this_month'  | 'last_month'
  | 'last_3_months' | 'last_6_months'
  | 'custom'

export interface TimeFilter {
  preset: TimeFilterPreset
  from:   Date | null
  to:     Date | null
  label:  string
}
