'use client'
// src/app/page.tsx
import { useCallback, useEffect, useState, useMemo } from 'react'
import { format, subDays } from 'date-fns'
import { DashboardHeader, makeTimeFilter } from '@/components/dashboard/DashboardHeader'
import { AllLinesTable }     from '@/components/dashboard/AllLinesTable'
import { WorkerTable }       from '@/components/dashboard/WorkerTable'
import { ChartsSection }     from '@/components/dashboard/ChartsSection'
import { EfficiencyGauge }   from '@/components/ui/EfficiencyGauge'
import { MtdRing }           from '@/components/ui/MtdRing'
import { KpiCard, SectionLabel } from '@/components/ui/KpiCard'
import { LoadingSkeleton }   from '@/components/ui/LoadingSkeleton'
import type { DashboardData, WorkerRow, TrendDay, SyncSource, TimeFilter } from '@/types'

const EMPTY_SUMMARY = {
  output: 0, efficiency: 0, earnedMinutes: 0, planMinutes: 0,
  dhu: 0, totalDefects: 0, rework: 0, pendingRework: 0,
  wip: 0, mtdOutput: 0, avgRepairTat: 0, workerCount: 0, totalWage: 0,
}

const EMPTY_DATA: DashboardData = {
  date: '', selectedLine: 'all',
  summary: EMPTY_SUMMARY,
  allLines: [],
  charts: { defectBreakdown: [], hourlyTrend: [], topWorkers: [] },
  availableLines: [],
}

// Data is always synced up to yesterday — default to yesterday's view
const DEFAULT_TIME_FILTER = makeTimeFilter('yesterday')

export default function Page() {
  const [selectedLine, setSelectedLine] = useState('all')
  const [timeFilter,   setTimeFilter]   = useState<TimeFilter>(DEFAULT_TIME_FILTER)
  const [activeTab,    setActiveTab]    = useState('overview')

  const [data,          setData]          = useState<DashboardData>(EMPTY_DATA)
  const [workers,       setWorkers]       = useState<WorkerRow[]>([])
  const [workerMeta,    setWorkerMeta]    = useState({ total: 0, page: 1, pages: 1 })
  const [trend,         setTrend]         = useState<TrendDay[]>([])
  const [syncSources,   setSyncSources]   = useState<SyncSource[]>([])
  const [loading,       setLoading]       = useState(false)
  const [workerLoading, setWorkerLoading] = useState(false)
  const [workerPage,    setWorkerPage]    = useState(1)
  const [error,         setError]         = useState('')

  const dateParams = useMemo(() => {
    const p = new URLSearchParams({ line: selectedLine })
    if (timeFilter.preset === 'all' || (!timeFilter.from && !timeFilter.to)) {
      p.set('preset', 'all')
    } else if (timeFilter.from && timeFilter.to) {
      p.set('from', format(timeFilter.from, 'yyyy-MM-dd'))
      p.set('to',   format(timeFilter.to,   'yyyy-MM-dd'))
    }
    return p
  }, [timeFilter, selectedLine])

  const fetchKpis = useCallback(async () => {
    setLoading(true); setError('')
    try {
      const res  = await fetch(`/api/kpis?${dateParams}`)
      if (!res.ok) throw new Error(`HTTP ${res.status}: ${await res.text()}`)
      const json = await res.json()
      if (json.error) throw new Error(json.error)
      setData(json)
    } catch (e) { setError(String(e)) }
    finally     { setLoading(false) }
  }, [dateParams])

  const fetchWorkers = useCallback(async () => {
    setWorkerLoading(true)
    try {
      const p = new URLSearchParams(dateParams)
      p.set('page', String(workerPage)); p.set('limit', '25')
      const res = await fetch(`/api/workers?${p}`)
      if (!res.ok) return
      const d = await res.json()
      setWorkers(d.workers || [])
      setWorkerMeta(d.pagination || { total: 0, page: 1, pages: 1 })
    } catch (e) { console.error('Workers fetch:', e) }
    finally     { setWorkerLoading(false) }
  }, [dateParams, workerPage])

  const fetchTrend = useCallback(async () => {
    try {
      const p   = new URLSearchParams({ days: '14', line: selectedLine })
      const res = await fetch(`/api/trends?${p}`)
      if (!res.ok) return
      const d = await res.json()
      setTrend(d.trend || [])
    } catch { /* silent */ }
  }, [selectedLine])

  const fetchSync = useCallback(async () => {
    try {
      const res = await fetch('/api/sync')
      if (!res.ok) return
      const d = await res.json()
      setSyncSources(d.sources || [])
    } catch { /* silent */ }
  }, [])

  useEffect(() => { void fetchKpis(); void fetchTrend(); void fetchSync() },
    [fetchKpis, fetchTrend, fetchSync])
  useEffect(() => { if (activeTab === 'workers') void fetchWorkers() },
    [activeTab, fetchWorkers])
  useEffect(() => { setWorkerPage(1) }, [dateParams])
  useEffect(() => {
    // Auto-refresh every 5 minutes (data won't change until next sync at 01:00 PKT,
    // but refreshes keep sync status and any mid-day patches up to date)
    const id = setInterval(() => { void fetchKpis(); void fetchTrend() }, 300_000)
    return () => clearInterval(id)
  }, [fetchKpis, fetchTrend])

  const s     = data.summary
  const lines = data.availableLines

  // Efficiency color
  const effColor = s.efficiency >= 80 ? 'var(--kpi-green)'
    : s.efficiency >= 60 ? 'var(--kpi-yellow)' : 'var(--kpi-red)'

  // Insights derived from data
  const insights = useMemo(() => {
    const out: { type: 'good' | 'warn' | 'bad'; msg: string }[] = []
    if (s.efficiency > 0 && s.efficiency < 60) out.push({ type: 'bad',  msg: `Overall efficiency is low at ${s.efficiency}%` })
    if (s.efficiency >= 85)                    out.push({ type: 'good', msg: `Strong efficiency of ${s.efficiency}% — above target` })
    if (s.dhu > 5)                             out.push({ type: 'bad',  msg: `DHU at ${s.dhu}% is above acceptable threshold (5%)` })
    if (s.dhu > 0 && s.dhu <= 2)              out.push({ type: 'good', msg: `DHU at ${s.dhu}% — excellent quality control` })
    if (s.pendingRework > 50)                  out.push({ type: 'warn', msg: `${s.pendingRework} pieces pending repair — action needed` })
    if (s.wip > 0)                             out.push({ type: 'warn', msg: `WIP balance: ${s.wip.toLocaleString()} pieces in pipeline (cumulative)` })
    if (s.avgRepairTat > 60)                   out.push({ type: 'bad',  msg: `Avg repair TAT is ${s.avgRepairTat}m — above 60 min target` })
    return out
  }, [s])

  return (
    <div className="min-h-screen flex flex-col" style={{ background: 'var(--bg)' }}>
      <DashboardHeader
        selectedLine={selectedLine}
        lines={lines}
        onLineChange={(l) => { setSelectedLine(l); setWorkerPage(1) }}
        timeFilter={timeFilter}
        onTimeFilterChange={(f) => { setTimeFilter(f); setWorkerPage(1) }}
        loading={loading}
        onRefresh={() => { void fetchKpis(); void fetchTrend() }}
        syncSources={syncSources}
        activeTab={activeTab}
        onTabChange={setActiveTab}
      />

      <main className="flex-1 max-w-screen-2xl mx-auto w-full px-4 sm:px-6 py-4 space-y-4">

        {error && (
          <div className="px-5 py-4 rounded-xl text-sm"
            style={{ background: 'var(--danger-bg)', border: '1px solid var(--danger-border)', color: 'var(--danger)' }}>
            <span className="font-semibold">Error: </span>{error}
            <button onClick={() => void fetchKpis()} className="ml-3 underline underline-offset-2">Retry</button>
          </div>
        )}

        {loading && data.availableLines.length === 0 ? (
          <LoadingSkeleton />
        ) : (
          <>
            {/* ── OVERVIEW ─────────────────────────────────────────────────── */}
            {activeTab === 'overview' && (
              <>
                {/* Insights bar — only shown when there's meaningful data */}
                {insights.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {insights.map((ins, i) => (
                      <div key={i} className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold"
                        style={{
                          background: ins.type === 'good' ? 'var(--success-bg)'
                            : ins.type === 'warn' ? '#7C4D0022' : 'var(--danger-bg)',
                          border: `1px solid ${ins.type === 'good' ? 'var(--kpi-green)33'
                            : ins.type === 'warn' ? '#F59E0B33' : 'var(--danger-border)'}`,
                          color: ins.type === 'good' ? 'var(--kpi-green)'
                            : ins.type === 'warn' ? 'var(--kpi-yellow)' : 'var(--danger)',
                        }}>
                        <span>{ins.type === 'good' ? '✓' : ins.type === 'warn' ? '⚠' : '✕'}</span>
                        {ins.msg}
                      </div>
                    ))}
                  </div>
                )}

                {/* Hero row */}
                <div className="grid grid-cols-12 gap-4">

                  {/* Output card */}
                  <div className="col-span-12 md:col-span-3">
                    <div className="card p-4 h-full flex flex-col gap-3">
                      <p className="text-[10px] font-black uppercase tracking-widest"
                        style={{ color: 'var(--text4)' }}>
                        Total Output
                      </p>
                      <div>
                        <p className="text-4xl font-black tabular-nums leading-none"
                          style={{ color: 'var(--kpi-cyan)' }}>
                          {s.output.toLocaleString()}
                        </p>
                        <p className="text-xs mt-1" style={{ color: 'var(--text4)' }}>
                          pcs · {data.allLines.length} lines · {data.date}
                        </p>
                      </div>

                      {/* Earned vs Plan minutes */}
                      {(s.planMinutes > 0 || s.earnedMinutes > 0) && (
                        <div className="rounded-lg p-3 space-y-1.5"
                          style={{ background: 'var(--bg2)', border: '1px solid var(--border)' }}>
                          <p className="text-[10px] font-black uppercase tracking-widest"
                            style={{ color: 'var(--text4)' }}>
                            Minutes (Earned / Plan)
                          </p>
                          <p className="text-base font-black tabular-nums" style={{ color: 'var(--kpi-green)' }}>
                            {s.earnedMinutes.toLocaleString()}
                            <span className="text-sm font-semibold" style={{ color: 'var(--text3)' }}>
                              {' '}/ {s.planMinutes.toLocaleString()}
                            </span>
                          </p>
                          <p className="text-[10px]" style={{ color: 'var(--text4)' }}>
                            Plan = workers × 480 min/shift
                          </p>
                        </div>
                      )}

                      {s.mtdOutput > 0 && (
                        <div className="rounded-lg p-2.5"
                          style={{ background: 'var(--bg2)', border: '1px solid var(--border)' }}>
                          <p className="text-[10px] font-semibold uppercase tracking-wider"
                            style={{ color: 'var(--text4)' }}>MTD Output</p>
                          <p className="text-lg font-black tabular-nums"
                            style={{ color: 'var(--accent)' }}>
                            {s.mtdOutput.toLocaleString()}
                          </p>
                        </div>
                      )}

                      {s.totalWage > 0 && (
                        <div className="rounded-lg p-2.5"
                          style={{ background: 'var(--bg2)', border: '1px solid var(--border)' }}>
                          <p className="text-[10px] font-semibold uppercase tracking-wider"
                            style={{ color: 'var(--text4)' }}>Total Wage (PKR)</p>
                          <p className="text-lg font-black tabular-nums"
                            style={{ color: 'var(--accent)' }}>
                            {s.totalWage.toLocaleString('en-PK', { maximumFractionDigits: 0 })}
                          </p>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Efficiency gauge */}
                  <div className="col-span-12 md:col-span-3 card flex flex-col items-center justify-center p-4 gap-2">
                    <EfficiencyGauge value={s.efficiency} size={200} />
                    <div className="text-center">
                      <p className="text-[10px] font-black uppercase tracking-widest"
                        style={{ color: 'var(--text4)' }}>
                        Overall Efficiency
                      </p>
                      <p className="text-xs mt-0.5" style={{ color: 'var(--text4)' }}>
                        Earned mins ÷ Plan mins · capped at 150%
                      </p>
                    </div>
                  </div>

                  {/* DHU + Quality */}
                  <div className="col-span-12 md:col-span-3 flex flex-col gap-3">
                    <KpiCard
                      label="DHU %"
                      value={`${s.dhu.toFixed(2)}%`}
                      sub={`${s.totalDefects.toLocaleString()} defects · ${s.workerCount} workers`}
                      palKey={s.dhu <= 2 ? 'efficiency' : s.dhu <= 5 ? 'plan' : 'dhu'}
                    />
                    <KpiCard
                      label="Pending Repair"
                      value={s.pendingRework}
                      animateNum={s.pendingRework}
                      palKey={s.pendingRework > 10 ? 'dhu' : 'tat'}
                      badge={s.pendingRework > 10 ? { text: 'action needed', type: 'bad' } : undefined}
                    />
                    <KpiCard
                      label="Avg Repair TAT"
                      value={`${s.avgRepairTat}m`}
                      palKey={s.avgRepairTat <= 30 ? 'tat' : s.avgRepairTat <= 60 ? 'plan' : 'dhu'}
                      sub="mins to close rework"
                    />
                  </div>

                  {/* MTD ring */}
                  <div className="col-span-12 md:col-span-3 card flex flex-col items-center justify-center p-4 gap-2">
                    <MtdRing
                      achieved={s.mtdOutput > 0 ? s.mtdOutput : s.output}
                      target={Math.max((s.mtdOutput > 0 ? s.mtdOutput : s.output) * 1.1, 1)}
                    />
                    <p className="text-[10px] font-black uppercase tracking-widest text-center"
                      style={{ color: 'var(--text4)' }}>
                      MTD vs Projection
                    </p>
                  </div>
                </div>

                {/* KPI strip */}
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
                  <KpiCard label="Total Output"  value={s.output}        animateNum={s.output}        palKey="output"  sub="all systems" />
                  <KpiCard label="Workers"        value={s.workerCount}   animateNum={s.workerCount}   palKey="workers" sub="across all lines" />
                  <KpiCard label="WIP"            value={s.wip}           animateNum={s.wip}           palKey="wip"
                    sub={s.wip > 0 ? "cumulative unfinished pieces" : "no open WIP (6R only)"}
                  />
                  <KpiCard label="Rework"         value={s.rework}        animateNum={s.rework}        palKey="rework"  sub="pieces flagged" />
                  <KpiCard label="Total Defects"  value={s.totalDefects}  animateNum={s.totalDefects}
                    palKey={s.totalDefects > 0 ? 'dhu' : 'efficiency'}
                    sub="6R lines only"
                  />
                </div>

                {/* Charts (daily output trend + defects + 14-day trend) */}
                <ChartsSection
                  defects={data.charts.defectBreakdown}
                  hourly={data.charts.hourlyTrend}
                  trend={trend}
                />

                {/* Top workers */}
                {data.charts.topWorkers.length > 0 && (
                  <div className="card p-4 animate-fade-up">
                    <SectionLabel>Top 10 Workers by Efficiency</SectionLabel>
                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 mt-2">
                      {data.charts.topWorkers.map((w, i) => (
                        <div key={w.id} className="rounded-xl p-3"
                          style={{ background: 'var(--bg2)', border: '1px solid var(--border)' }}>
                          <div className="flex items-center gap-1.5 mb-1">
                            <span className="text-[10px] font-black"
                              style={{ color: i === 0 ? 'var(--kpi-yellow)' : 'var(--text4)' }}>
                              #{i + 1}
                            </span>
                            <span className="text-xs font-semibold truncate"
                              style={{ color: 'var(--text1)' }}>{w.name}</span>
                          </div>
                          <p className="text-xl font-black tabular-nums"
                            style={{ color: w.efficiency >= 80 ? 'var(--kpi-green)'
                              : w.efficiency >= 60 ? 'var(--kpi-yellow)' : 'var(--kpi-red)' }}>
                            {w.efficiency.toFixed(1)}%
                          </p>
                          <p className="text-[10px]" style={{ color: 'var(--text4)' }}>
                            {w.qty.toLocaleString()} pcs
                          </p>
                          {w.dhu > 0 && (
                            <p className="text-[10px]" style={{ color: w.dhu > 5 ? 'var(--kpi-red)' : 'var(--text4)' }}>
                              DHU {w.dhu.toFixed(1)}%
                            </p>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {data.availableLines.length === 0 && !loading && (
                  <div className="card p-10 text-center animate-fade-up">
                    <p className="text-lg font-bold mb-2" style={{ color: 'var(--text3)' }}>No data found</p>
                    <p className="text-sm" style={{ color: 'var(--text4)' }}>
                      Make sure MongoDB is connected and the sync script has run.
                    </p>
                    <code className="inline-block mt-3 px-3 py-1.5 rounded-lg text-xs font-mono"
                      style={{ background: 'var(--bg3)', color: 'var(--accent)' }}>
                      python scripts/sync.py --full
                    </code>
                  </div>
                )}
              </>
            )}

            {/* ── ALL LINES ─────────────────────────────────────────────────── */}
            {activeTab === 'lines' && (
              <AllLinesTable
                lines={data.allLines}
                onLineSelect={(l) => { setSelectedLine(l); setActiveTab('overview') }}
                selectedLine={selectedLine}
              />
            )}

            {/* ── WORKERS ───────────────────────────────────────────────────── */}
            {activeTab === 'workers' && (
              <WorkerTable
                workers={workers}
                page={workerMeta.page}
                pages={workerMeta.pages}
                total={workerMeta.total}
                onPageChange={(p) => { setWorkerPage(p); void fetchWorkers() }}
                loading={workerLoading}
              />
            )}

            {/* ── TRENDS ────────────────────────────────────────────────────── */}
            {activeTab === 'trends' && (
              <div className="space-y-4">
                <ChartsSection
                  defects={data.charts.defectBreakdown}
                  hourly={data.charts.hourlyTrend}
                  trend={trend}
                />
                {trend.length > 0 && (
                  <div className="card overflow-hidden animate-fade-up">
                    <div className="px-4 pt-4 pb-2"><SectionLabel>Daily Breakdown (14 days)</SectionLabel></div>
                    <div className="overflow-x-auto">
                      <table className="data-table">
                        <thead>
                          <tr>
                            <th>Date</th><th>Output</th>
                            <th>Efficiency %</th><th>Defects</th><th>DHU %</th>
                          </tr>
                        </thead>
                        <tbody>
                          {[...trend].reverse().map((d) => (
                            <tr key={d.date}>
                              <td className="font-mono font-bold text-xs"
                                style={{ color: 'var(--accent)' }}>{d.label}</td>
                              <td className="font-bold"
                                style={{ color: 'var(--text1)' }}>{d.output.toLocaleString()}</td>
                              <td>
                                <span className="font-black" style={{
                                  color: d.efficiency >= 80 ? 'var(--kpi-green)'
                                    : d.efficiency >= 60 ? 'var(--kpi-yellow)' : 'var(--kpi-red)',
                                }}>
                                  {d.efficiency.toFixed(1)}%
                                </span>
                              </td>
                              <td style={{ color: d.defects > 0 ? 'var(--kpi-orange)' : 'var(--text4)' }}>
                                {d.defects.toLocaleString()}
                              </td>
                              <td>
                                <span className="font-bold" style={{
                                  color: d.dhu <= 2 ? 'var(--kpi-green)'
                                    : d.dhu <= 5 ? 'var(--kpi-yellow)' : 'var(--kpi-red)',
                                }}>
                                  {d.dhu.toFixed(2)}%
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </main>

      {loading && data.availableLines.length > 0 && (
        <div className="fixed bottom-5 right-5 flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs shadow-xl"
          style={{ background: 'var(--surface)', border: '1px solid var(--border2)', color: 'var(--text2)' }}>
          <svg className="w-3 h-3 animate-spin" style={{ color: 'var(--accent)' }}
            viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5}>
            <path strokeLinecap="round" strokeLinejoin="round"
              d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>
          </svg>
          Refreshing…
        </div>
      )}
    </div>
  )
}