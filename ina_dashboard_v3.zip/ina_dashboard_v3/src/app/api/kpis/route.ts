// src/app/api/kpis/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { connectDB } from '@/lib/db'
import {
  Prod6rModel, QcRework6rModel,
  ProdInfoModel, QcReworkModel,
  WageByBundleModel, WageSummaryModel,
} from '@/lib/models'
import { startOfDay, endOfDay, startOfMonth, subDays, format, parseISO } from 'date-fns'

export const dynamic   = 'force-dynamic'
export const revalidate = 0

export async function GET(req: NextRequest) {
  try {
    await connectDB()
    const { searchParams } = new URL(req.url)
    // lineParam can be: 'all' | 'ina_6r' | 'ina_7r' | 'sql' | a specific line key
    const lineParam = searchParams.get('line') || 'all'
    const preset    = searchParams.get('preset')
    const fromParam = searchParams.get('from')
    const toParam   = searchParams.get('to')

    let dayStart: Date | null = null
    let dayEnd:   Date | null = null

    if (preset === 'all' || (!fromParam && !toParam)) {
      // No date filter — query all data
      dayStart = null
      dayEnd   = null
    } else if (fromParam && toParam) {
      dayStart = startOfDay(parseISO(fromParam))
      dayEnd   = endOfDay(parseISO(toParam))
    } else if (searchParams.get('date')) {
      const d  = parseISO(searchParams.get('date')!)
      dayStart = startOfDay(d)
      dayEnd   = endOfDay(d)
    }

    const data = await buildDashboard(dayStart, dayEnd, lineParam)
    return NextResponse.json(data)
  } catch (err) {
    console.error('KPI error:', err)
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}

// ─── IMPORTANT: All date fields in MongoDB are stored as ISO strings ───────────
// Oracle ORDS returns dates like "2026-04-13T04:00:00Z" or "2026-05-25T16:45:59"
// ISO 8601 strings sort lexicographically, so $gte/$lte string comparisons work.
// NEVER compare a JS Date against these fields — always convert with toISOString().

function sf(field: string, start: Date | null, end: Date | null): Record<string, unknown> {
  if (!start || !end) return {}
  return { [field]: { $gte: start.toISOString(), $lte: end.toISOString() } }
}

function sfDate(field: string, start: Date | null, end: Date | null): Record<string, unknown> {
  if (!start || !end) return {}
  return { [field]: { $gte: format(start, 'yyyy-MM-dd'), $lte: format(end, 'yyyy-MM-dd') } }
}

// ─────────────────────────────────────────────────────────────────────────────
// INA 6R — production_info_6r + qc_rework_info_6r
// Lines are numeric (odpi_line_number e.g. 6, 15, 17)
//
// EFFICIENCY FORMULA:
//   Earned Minutes = SUM(output_qty × standard_time_per_piece) — only for FINISHED output (pc_key=9999)
//   Plan Minutes   = worker_count × 480 (one 8-hour shift)
//   Efficiency %   = Earned Minutes / Plan Minutes × 100
//   Cap at 150% to filter data anomalies.
//
// WIP:
//   WIP is a real-time snapshot: pieces loaded into line but not yet output.
//   Since data is synced daily (yesterday's snapshot), we compute:
//     All-time loaded (odpi_stop_order=1) minus all-time output (pc_key=9999)
//   Date filter is NOT applied to WIP — it's always a cumulative snapshot.
// ─────────────────────────────────────────────────────────────────────────────

async function build6rLines(start: Date | null, end: Date | null, lineFilter: string) {
  const Prod6r     = Prod6rModel()
  const QcRework6r = QcRework6rModel()

  // Determine which 6r line numbers to query (scoped to date range for line discovery)
  const allLineNumbers = await (async () => {
    const f: Record<string, unknown> = {
      odpi_line_number: { $ne: null, $type: 'number' },
      ...sf('odpi_date', start, end),
    }
    const l = await Prod6r.distinct('odpi_line_number', f)
    return (l as number[]).filter(n => n > 0).sort((a, b) => a - b)
  })()

  // Apply system/line filter
  const lineNumbers = lineFilter === 'all' || lineFilter === 'ina_6r'
    ? allLineNumbers
    : lineFilter === 'ina_7r' || lineFilter === 'sql'
      ? []
      : allLineNumbers.filter(n => String(n) === lineFilter)

  return Promise.all(lineNumbers.map(async (ln) => {
    // Base filter for the SELECTED DATE RANGE (production metrics)
    const prodBase: Record<string, unknown> = {
      odpi_odpd_is_overtime: 0,
      odpi_quantity:         { $gt: 0 },
      odpi_line_number:      ln,
      ...sf('odpi_date', start, end),
    }
    const qcBase: Record<string, unknown> = {
      QCRI_LineNumber: ln,
      ...sf('QCRI_QC_DateTime', start, end),
    }
    const mtdBase: Record<string, unknown> = {
      odpi_odpd_is_overtime: 0,
      odpi_quantity:         { $gt: 0 },
      pc_key:                9999,
      odpi_line_number:      ln,
      ...(start ? sf('odpi_date', startOfMonth(start), end ?? new Date()) : {}),
    }
    // WIP uses ALL-TIME data (no date filter) — it's a running balance
    const wipLoadBase: Record<string, unknown> = {
      odpi_quantity:    { $gt: 0 },
      odpi_line_number: ln,
      odpi_stop_order:  1,
    }
    const wipOutBase: Record<string, unknown> = {
      odpi_quantity:    { $gt: 0 },
      odpi_line_number: ln,
      pc_key:           9999,
    }

    const [
      outputAgg,      // finished output in date range
      earnedMinsAgg,  // earned mins from OUTPUT only (pc_key=9999), date range
      workerCountAgg, // distinct workers in date range
      defectAgg,
      tatAgg,
      mtdAgg,
      wipLoadAgg,     // ALL-TIME loaded
      wipOutAgg,      // ALL-TIME output
      totalRework,
      pendingRework,
    ] = await Promise.all([
      // 1. Finished output (pc_key=9999 = final pass)
      Prod6r.aggregate([
        { $match: { ...prodBase, pc_key: 9999 } },
        { $group: { _id: null, total: { $sum: '$odpi_quantity' } } },
      ]),
      // 2. CORRECT efficiency: earned mins = output qty × standard time, output operations ONLY
      //    This gives actual value-added time, not inflated by intermediate ops
      Prod6r.aggregate([
        { $match: { ...prodBase, pc_key: 9999 } },
        { $group: {
          _id: null,
          earnedMins: { $sum: { $multiply: ['$odpi_quantity', { $divide: ['$odpi_oc_standard_time', 60] }] } },
        }},
      ]),
      // 3. Distinct workers across ALL operations in date range (for plan mins calc)
      Prod6r.aggregate([
        { $match: prodBase },
        { $group: { _id: '$odpi_em_key' } },
        { $count: 'total' },
      ]),
      // 4. Defects
      QcRework6r.aggregate([
        { $match: { ...qcBase, QCRI_QCSC_Is_Rework: 1 } },
        { $group: { _id: null, total: { $sum: '$QCRI_Defect_Quantity' } } },
      ]),
      // 5. Repair TAT
      QcRework6r.aggregate([
        { $match: { ...qcBase, QCRI_Repair_Quantity: { $gt: 0 }, QCRI_Repair_EM_Key: { $gt: 0 } } },
        { $addFields: { tatMins: { $divide: [
          { $subtract: [{ $toDate: '$QCRI_Repair_DateTime' }, { $toDate: '$QCRI_QC_DateTime' }] },
          60000,
        ]}},
        },
        { $match: { tatMins: { $gt: 0, $lt: 480 } } },
        { $group: { _id: null, avg: { $avg: '$tatMins' } } },
      ]),
      // 6. MTD output
      Prod6r.aggregate([
        { $match: mtdBase },
        { $group: { _id: null, total: { $sum: '$odpi_quantity' } } },
      ]),
      // 7. WIP: all-time loaded (no date filter)
      Prod6r.aggregate([
        { $match: wipLoadBase },
        { $group: { _id: null, total: { $sum: '$odpi_quantity' } } },
      ]),
      // 8. WIP: all-time output (no date filter)
      Prod6r.aggregate([
        { $match: wipOutBase },
        { $group: { _id: null, total: { $sum: '$odpi_quantity' } } },
      ]),
      // 9-10. Rework counts
      QcRework6r.countDocuments({ ...qcBase, QCRI_QCSC_Is_Rework: 1 }),
      QcRework6r.countDocuments({ ...qcBase, QCRI_Repair_Quantity: 0, QCRI_QCSC_Is_Rework: 1 }),
    ])

    const output      = (outputAgg[0]?.total as number) || 0
    const earnedMins  = Math.round((earnedMinsAgg[0]?.earnedMins as number) || 0)
    const workerCount = (workerCountAgg[0]?.total as number) || 0
    const planMins    = workerCount * 480

    // Efficiency: cap at 150% to avoid data anomalies (standard_time mismatches etc.)
    const rawEfficiency = planMins > 0 ? (earnedMins / planMins) * 100 : 0
    const efficiency    = Math.round(Math.min(rawEfficiency, 150) * 10) / 10

    const totalDef = (defectAgg[0]?.total as number) || 0
    const dhu      = output > 0 ? Math.round((totalDef / output) * 10000) / 100 : 0

    // WIP = all-time loaded - all-time output (running balance, not date-scoped)
    const allTimeLoaded = (wipLoadAgg[0]?.total as number) || 0
    const allTimeOut    = (wipOutAgg[0]?.total as number) || 0
    const wip           = Math.max(0, allTimeLoaded - allTimeOut)

    return {
      line:              String(ln),
      lineName:          `Line ${ln}`,
      system:            'ina_6r' as const,
      output,
      workerCount,
      earnedMinutes:     earnedMins,
      planMinutes:       planMins,
      efficiency,
      dhu,
      totalDefects:      totalDef,
      rework:            totalRework,
      pendingRework,
      avgRepairTat:      Math.round((tatAgg[0]?.avg as number) || 0),
      wip,
      mtdOutput:         (mtdAgg[0]?.total as number) || 0,
      defects7r:         0,
      totalWage:         0,
      productiveMinutes: 0,
    }
  }))
}

// ─────────────────────────────────────────────────────────────────────────────
// INA 7R — production_info + quality_rework_info
// Lines are strings (ppd_line_number e.g. "Line10", "Line11", "FIN01")
// Efficiency: earnedMins / (workers × 480), capped at 150%
// ─────────────────────────────────────────────────────────────────────────────

async function build7rLines(start: Date | null, end: Date | null, lineFilter: string) {
  const ProdInfo = ProdInfoModel()
  const QcRework = QcReworkModel()

  const allLineStrs = await (async () => {
    const f: Record<string, unknown> = {
      ppd_line_number: { $ne: null },
      ...sf('ppd_date', start, end),
    }
    const l = await ProdInfo.distinct('ppd_line_number', f)
    return (l as string[]).filter(s => s && typeof s === 'string').sort()
  })()

  const lineStrs = lineFilter === 'all' || lineFilter === 'ina_7r'
    ? allLineStrs
    : lineFilter === 'ina_6r' || lineFilter === 'sql'
      ? []
      : allLineStrs.filter(s => s === lineFilter)

  return Promise.all(lineStrs.map(async (ln) => {
    const prodBase: Record<string, unknown> = {
      ppd_line_number: ln,
      ...sf('ppd_date', start, end),
    }
    const qcBase: Record<string, unknown> = {
      ppd_line_number: ln,
      ...sf('date_back', start, end),
    }

    const [outputAgg, workerAgg, defectAgg] = await Promise.all([
      ProdInfo.aggregate([
        { $match: prodBase },
        { $group: {
          _id: null,
          total:      { $sum: '$ppd_quantity' },
          earnedMins: { $sum: { $multiply: ['$ppd_quantity', { $divide: ['$ppd_standard_time', 60] }] } },
        }},
      ]),
      ProdInfo.aggregate([
        { $match: prodBase },
        { $group: { _id: '$ppd_hei_code' } },
        { $count: 'total' },
      ]),
      QcRework.aggregate([
        { $match: qcBase },
        { $group: { _id: null, total: { $sum: '$bindquantity' }, rework: { $sum: 1 } } },
      ]),
    ])

    const output      = (outputAgg[0]?.total as number)      || 0
    const earnedMins  = Math.round((outputAgg[0]?.earnedMins as number) || 0)
    const workerCount = (workerAgg[0]?.total as number)       || 0
    const planMins    = workerCount * 480

    // Cap at 150%
    const rawEff   = planMins > 0 ? (earnedMins / planMins) * 100 : 0
    const efficiency = Math.round(Math.min(rawEff, 150) * 10) / 10

    const defects7r = (defectAgg[0]?.total as number)  || 0
    const rework    = (defectAgg[0]?.rework as number)  || 0
    const dhu       = output > 0 ? Math.round((defects7r / output) * 10000) / 100 : 0

    return {
      line:              ln,
      lineName:          ln,
      system:            'ina_7r' as const,
      output,
      workerCount,
      earnedMinutes:     earnedMins,
      planMinutes:       planMins,
      efficiency,
      dhu,
      totalDefects:      0,
      rework,
      pendingRework:     0,
      avgRepairTat:      0,
      wip:               0,
      mtdOutput:         0,
      defects7r,
      totalWage:         0,
      productiveMinutes: 0,
    }
  }))
}

// ─────────────────────────────────────────────────────────────────────────────
// WiMatrix / SQL — worker_wage_by_bundle + worker_wage_summary
// Lines: LineCode string (e.g. "8"), LineName (e.g. "Stitching Line 08")
// Efficiency: productiveMinutes / (workers × 480), capped at 150%
// ─────────────────────────────────────────────────────────────────────────────

async function buildSqlLines(start: Date | null, end: Date | null, lineFilter: string) {
  const WageBundle  = WageByBundleModel()
  const WageSummary = WageSummaryModel()

  // Get all distinct line codes
  const allLineCodes = await (async () => {
    const f: Record<string, unknown> = {
      LineCode: { $ne: null },
      ...sfDate('ScanDate', start, end),
    }
    const rows = await WageBundle.aggregate([
      { $match: f },
      { $group: { _id: '$LineCode', name: { $first: '$LineName' } } },
      { $sort: { _id: 1 } },
    ])
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    return (rows as any[]).map((r: any) => ({ code: String(r._id), name: (r.name as string) || `SQL Line ${r._id}` }))
  })()

  const lineCodes = lineFilter === 'all' || lineFilter === 'sql'
    ? allLineCodes
    : lineFilter === 'ina_6r' || lineFilter === 'ina_7r'
      ? []
      : allLineCodes.filter(l => l.code === lineFilter)

  return Promise.all(lineCodes.map(async ({ code, name }) => {
    const bundleFilter: Record<string, unknown> = {
      LineCode: code,
      ...sfDate('ScanDate', start, end),
    }

    const [bundleAgg, workerAgg] = await Promise.all([
      WageBundle.aggregate([
        { $match: bundleFilter },
        { $group: {
          _id:      null,
          output:   { $sum: '$ScannedQuantity' },
          wage:     { $sum: '$Wage' },
          prodMins: { $sum: '$ProductiveMinutes' },
        }},
      ]),
      WageBundle.aggregate([
        { $match: bundleFilter },
        { $group: { _id: '$WorkerCode' } },
        { $count: 'total' },
      ]),
    ])

    const output      = (bundleAgg[0]?.output  as number) || 0
    const totalWage   = (bundleAgg[0]?.wage    as number) || 0
    const prodMins    = Math.round((bundleAgg[0]?.prodMins as number) || 0)
    const workerCount = (workerAgg[0]?.total   as number) || 0

    // Efficiency from productive minutes vs plan (workers × 480), cap at 150%
    const planMins   = workerCount * 480
    const rawEff     = planMins > 0 ? (prodMins / planMins) * 100 : 0
    const efficiency = Math.round(Math.min(rawEff, 150) * 10) / 10

    return {
      line:              code,
      lineName:          name,
      system:            'sql' as const,
      output,
      workerCount,
      earnedMinutes:     prodMins,
      planMinutes:       planMins,
      efficiency,
      dhu:               0,
      totalDefects:      0,
      rework:            0,
      pendingRework:     0,
      avgRepairTat:      0,
      wip:               0,
      mtdOutput:         0,
      defects7r:         0,
      totalWage,
      productiveMinutes: prodMins,
    }
  }))
}

// ─────────────────────────────────────────────────────────────────────────────
// Charts — sourced from 6R (richest quality data)
// DAILY TREND replaces hourly (data is synced to yesterday, not real-time)
// ─────────────────────────────────────────────────────────────────────────────

async function buildCharts(start: Date | null, end: Date | null, lineFilter: string) {
  const Prod6r     = Prod6rModel()
  const QcRework6r = QcRework6rModel()

  const workerFilter: Record<string, unknown> = {
    odpi_odpd_is_overtime: 0,
    odpi_quantity:         { $gt: 0 },
    ...sf('odpi_date', start, end),
  }
  const qcFilter: Record<string, unknown> = {
    QCRI_QCSC_Is_Rework: 1,
    ...sf('QCRI_QC_DateTime', start, end),
  }
  // Apply line filter if it's a specific 6r line
  if (lineFilter !== 'all' && lineFilter !== 'ina_6r' && lineFilter !== 'ina_7r' && lineFilter !== 'sql') {
    const n = parseInt(lineFilter)
    if (!isNaN(n)) {
      workerFilter.odpi_line_number = n
      qcFilter.QCRI_LineNumber = n
    }
  }

  const [defectBreakdown, topWorkers] = await Promise.all([
    QcRework6r.aggregate([
      { $match: qcFilter },
      { $group: { _id: '$QCRI_QCSC_Description', count: { $sum: '$QCRI_Defect_Quantity' } } },
      { $sort: { count: -1 } },
      { $limit: 10 },
    ]),
    Prod6r.aggregate([
      { $match: { ...workerFilter, pc_key: 9999 } },
      { $group: {
        _id:        '$odpi_em_key',
        name:       { $first: { $ifNull: ['$odpi_em_lcd_name', '$odpi_em_firstname'] } },
        qty:        { $sum: '$odpi_quantity' },
        earnedMins: { $sum: { $multiply: ['$odpi_quantity', { $divide: ['$odpi_oc_standard_time', 60] }] } },
      }},
      { $addFields: { rawEff: { $multiply: [{ $divide: ['$earnedMins', 480] }, 100] } } },
      // Cap per-worker efficiency at 150% too
      { $addFields: { efficiency: { $min: ['$rawEff', 150] } } },
      { $sort: { efficiency: -1 } },
      { $limit: 10 },
    ]),
  ])

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const topWorkerIds = (topWorkers as any[]).map((w: any) => w._id).filter(Boolean)
  const workerDefects = topWorkerIds.length ? await QcRework6r.aggregate([
    { $match: { QCRI_Defect_EM_Key: { $in: topWorkerIds }, ...sf('QCRI_QC_DateTime', start, end) } },
    { $group: { _id: '$QCRI_Defect_EM_Key', defects: { $sum: '$QCRI_Defect_Quantity' } } },
  ]) : []
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const defectMap = new Map((workerDefects as any[]).map((d: any) => [d._id, d.defects as number]))

  // DAILY output trend — last 30 days (or date range), grouped by date
  // This replaces hourly since data is always synced to yesterday (not live)
  const trendStart = start ?? subDays(new Date(), 30)
  const trendEnd   = end   ?? subDays(new Date(), 1) // cap at yesterday since that's latest synced

  const dailyTrendAgg = await Prod6r.aggregate([
    { $match: {
      odpi_odpd_is_overtime: 0,
      odpi_quantity:         { $gt: 0 },
      pc_key:                9999,
      ...sf('odpi_date', trendStart, trendEnd),
      ...(lineFilter !== 'all' && lineFilter !== 'ina_6r' && lineFilter !== 'ina_7r' && lineFilter !== 'sql'
        ? { odpi_line_number: parseInt(lineFilter) || undefined }
        : {}),
    }},
    { $addFields: {
      dateStr: { $substr: ['$odpi_date', 0, 10] }, // "YYYY-MM-DD"
    }},
    { $group: {
      _id:        '$dateStr',
      output:     { $sum: '$odpi_quantity' },
      earnedMins: { $sum: { $multiply: ['$odpi_quantity', { $divide: ['$odpi_oc_standard_time', 60] }] } },
      workers:    { $addToSet: '$odpi_em_key' },
    }},
    { $sort: { _id: 1 } },
  ])

  return {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    defectBreakdown: (defectBreakdown as any[]).map((d: any) => ({
      name: (d._id as string) || 'Unknown', count: d.count as number,
    })),
    // Daily trend replaces hourlyTrend — field kept as hourlyTrend for interface compat
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    hourlyTrend: (dailyTrendAgg as any[]).map((d: any) => {
      const workerCnt = ((d.workers as unknown[]) || []).length
      const planMins  = workerCnt * 480
      const rawEff    = planMins > 0 ? (d.earnedMins / planMins) * 100 : 0
      const eff       = Math.round(Math.min(rawEff, 150) * 10) / 10
      // Format date label as "Mon 26 May" style
      const dt        = new Date(d._id as string)
      const label     = dt.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' })
      return {
        hour:   label,               // repurposed as date label
        qty:    d.output as number,
        target: eff,                 // repurposed as efficiency %
      }
    }),
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    topWorkers: (topWorkers as any[]).map((w: any) => ({
      id:         w._id as number,
      name:       (w.name as string) || `Worker ${w._id}`,
      qty:        Math.round(w.qty as number),
      efficiency: Math.round((w.efficiency as number) * 10) / 10,
      dhu:        (w.qty as number) > 0
        ? Math.round(((defectMap.get(w._id) || 0) / (w.qty as number)) * 10000) / 100 : 0,
    })),
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Main dashboard builder — combines ALL sources into a single unified response
// ─────────────────────────────────────────────────────────────────────────────

async function buildDashboard(start: Date | null, end: Date | null, lineParam: string) {
  // Run all three source queries + charts concurrently
  const [lines6r, lines7r, linesSql, charts] = await Promise.all([
    build6rLines(start, end, lineParam),
    build7rLines(start, end, lineParam),
    buildSqlLines(start, end, lineParam),
    buildCharts(start, end, lineParam),
  ])

  // Merge ALL lines into a single array — names are unique across sources
  const allLines = [...lines6r, ...lines7r, ...linesSql]

  // Available lines list for the line selector (all keys combined)
  const availableLines = allLines.map(l => l.line)

  // Overall efficiency: weighted by plan minutes (more workers = more weight)
  // Falls back to simple average if no plan minutes available
  const totalPlanMins   = allLines.reduce((a, l) => a + l.planMinutes, 0)
  const totalEarnedMins = allLines.reduce((a, l) => a + l.earnedMinutes, 0)
  const overallEfficiency = totalPlanMins > 0
    ? Math.round(Math.min((totalEarnedMins / totalPlanMins) * 100, 150) * 10) / 10
    : allLines.filter(l => l.efficiency > 0).length > 0
      ? Math.round(
          allLines.filter(l => l.efficiency > 0).reduce((a, l) => a + l.efficiency, 0)
          / allLines.filter(l => l.efficiency > 0).length * 10
        ) / 10
      : 0

  // Aggregate summary across all lines in the result set
  const summary = {
    output:        allLines.reduce((a, l) => a + l.output, 0),
    efficiency:    overallEfficiency,
    earnedMinutes: totalEarnedMins,
    planMinutes:   totalPlanMins,
    dhu:           (() => {
      // Weighted DHU: total defects / total output × 100 (6r only)
      const totalOut = lines6r.reduce((a, l) => a + l.output, 0)
      const totalDef = lines6r.reduce((a, l) => a + l.totalDefects, 0)
      return totalOut > 0 ? Math.round((totalDef / totalOut) * 10000) / 100 : 0
    })(),
    totalDefects:  lines6r.reduce((a, l) => a + l.totalDefects, 0),
    rework:        lines6r.reduce((a, l) => a + l.rework, 0),
    pendingRework: lines6r.reduce((a, l) => a + l.pendingRework, 0),
    wip:           lines6r.reduce((a, l) => a + l.wip, 0),
    mtdOutput:     lines6r.reduce((a, l) => a + l.mtdOutput, 0),
    avgRepairTat:  (() => {
      const tats = lines6r.filter(l => l.avgRepairTat > 0)
      return tats.length > 0 ? Math.round(tats.reduce((a, l) => a + l.avgRepairTat, 0) / tats.length) : 0
    })(),
    workerCount:   allLines.reduce((a, l) => a + l.workerCount, 0),
    totalWage:     linesSql.reduce((a, l) => a + l.totalWage, 0),
  }

  return {
    date: start && end
      ? `${format(start, 'dd MMM yyyy')} → ${format(end, 'dd MMM yyyy')}`
      : 'All time',
    selectedLine: lineParam,
    summary,
    allLines,
    charts,
    availableLines,
  }
}