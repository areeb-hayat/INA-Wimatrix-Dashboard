// src/app/api/sync/route.ts
import { NextResponse } from 'next/server'
import { connectDB } from '@/lib/db'
import { SyncMetaModel } from '@/lib/models'

export const dynamic   = 'force-dynamic'
export const revalidate = 0

export async function GET() {
  try {
    await connectDB()
    const SyncMeta = SyncMetaModel()
    const sources  = await SyncMeta.find({}).sort({ lastSyncedAt: -1 }).lean()
    return NextResponse.json({ sources })
  } catch (err) {
    console.error('Sync meta error:', err)
    return NextResponse.json({ sources: [] })
  }
}
