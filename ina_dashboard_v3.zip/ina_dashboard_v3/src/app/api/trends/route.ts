// src/app/api/trends/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { connectDB } from '@/lib/db'
import { Prod6rModel, QcRework6rModel } from '@/lib/models'
import { subDays, format } from 'date-fns'

export const dynamic   = 'force-dynamic'
export const revalidate = 0

function sf(field: string, start: Date, end: Date) {
  return { [field]: { $gte: start.toISOString(), $lte: end.toISOString() } }
}

export async function GET(req: NextRequest) {
  try {
    await connectDB()
    const { searchParams } = new URL(req.url)
    const days = Math.min(90, parseInt(searchParams.get('days') || '14'))
    const Prod6r     = Prod6rModel()
    const QcRework6r = QcRework6rModel()

    const end   = new Date(); end.setHours(23, 59, 59, 999)
    const start = subDays(end, days); start.setHours(0, 0, 0, 0)

    const [dailyAgg, defectAgg] = await Promise.all([
      Prod6r.aggregate([
        { $match: {
          odpi_odpd_is_overtime: 0,
          pc_key: 9999,
          ...sf('odpi_date', start, end),
        }},
        { $group: {
          _id:        { $dateToString: { format: '%Y-%m-%d', date: { $toDate: '$odpi_date' } } },
          output:     { $sum: '$odpi_quantity' },
          earnedMins: { $sum: { $multiply: ['$odpi_quantity', { $divide: ['$odpi_oc_standard_time', 60] }] } },
          workers:    { $addToSet: '$odpi_em_key' },
        }},
        { $sort: { _id: 1 } },
      ]),
      QcRework6r.aggregate([
        { $match: { QCRI_QCSC_Is_Rework: 1, ...sf('QCRI_QC_DateTime', start, end) } },
        { $group: {
          _id:     { $dateToString: { format: '%Y-%m-%d', date: { $toDate: '$QCRI_QC_DateTime' } } },
          defects: { $sum: '$QCRI_Defect_Quantity' },
        }},
      ]),
    ])

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const defectMap = new Map((defectAgg as any[]).map((d: any) => [d._id as string, d.defects as number]))

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const trend = (dailyAgg as any[]).map((d: any) => {
      const dateStr   = d._id as string
      const output    = d.output as number
      const eMins     = d.earnedMins as number
      const wCount    = ((d.workers as unknown[]) || []).length
      const pMins     = wCount * 480
      const efficiency = pMins > 0 ? Math.round((eMins / pMins) * 1000) / 10 : 0
      const defects   = defectMap.get(dateStr) || 0
      const dhu       = output > 0 ? Math.round((defects / output) * 10000) / 100 : 0
      const dt        = new Date(dateStr)
      return {
        date:  dateStr,
        label: format(dt, 'dd MMM'),
        output, efficiency, defects, dhu,
      }
    })

    return NextResponse.json({ trend })
  } catch (err) {
    console.error('Trends error:', err)
    return NextResponse.json({ trend: [] })
  }
}
