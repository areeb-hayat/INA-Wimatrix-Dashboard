// src/lib/models.ts
import mongoose, { Schema } from 'mongoose'

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function model(name: string, schema: Schema): any {
  return mongoose.models[name] || mongoose.model(name, schema)
}

// ─── INA 6R: production_info_6r ──────────────────────────────────────────────
// Endpoint: /production_info_6r/odp_info → {items:[...], hasMore:bool} (7r-style)
// Lines: numeric odpi_line_number (e.g. 6, 15, 17)
const Prod6rSchema = new Schema({
  odpi_key: { type: String, required: true, unique: true },
}, { strict: false, collection: 'production_info_6r' })
Prod6rSchema.index({ odpi_date: 1, odpi_line_number: 1 })
Prod6rSchema.index({ odpi_date: 1, odpi_line_number: 1, odpi_odpd_is_overtime: 1 })
Prod6rSchema.index({ odpi_date: 1, pc_key: 1 })
Prod6rSchema.index({ odpi_em_key: 1, odpi_date: 1 })
Prod6rSchema.index({ pc_key: 1 })
Prod6rSchema.index({ odp_last_hanger_time: 1 })
Prod6rSchema.index({ odpi_line_number: 1 })
export const Prod6rModel = () => model('Prod6r', Prod6rSchema)

// ─── INA 6R: qc_rework_info_6r ───────────────────────────────────────────────
// Endpoint: /quality_rework_info_6r/qc_rework_info → {status,total,data:[...]} (6r-style)
// Lines: numeric QCRI_LineNumber (e.g. 15, 17)
const QcRework6rSchema = new Schema({
  QCRI_Key: { type: String, required: true, unique: true },
}, { strict: false, collection: 'qc_rework_info_6r' })
QcRework6rSchema.index({ QCRI_QC_DateTime: 1, QCRI_LineNumber: 1 })
QcRework6rSchema.index({ QCRI_QC_DateTime: 1, QCRI_QCSC_Is_Rework: 1 })
QcRework6rSchema.index({ QCRI_Defect_EM_Key: 1 })
QcRework6rSchema.index({ QCRI_QCSC_Is_Rework: 1 })
QcRework6rSchema.index({ QCRI_LineNumber: 1 })
export const QcRework6rModel = () => model('QcRework6r', QcRework6rSchema)

// ─── INA 7R: production_info ──────────────────────────────────────────────────
// Endpoint: /production_info/get → {items:[...], hasMore:bool}
// Lines: string ppd_line_number (e.g. "Line10", "Line11", "FIN01", "FIN02", "LINE-01")
const ProdInfoSchema = new Schema({
  ppd_key: { type: String, required: true, unique: true },
}, { strict: false, collection: 'production_info' })
ProdInfoSchema.index({ ppd_date: 1, ppd_line_number: 1 })
ProdInfoSchema.index({ ppd_hei_code: 1, ppd_date: 1 })
export const ProdInfoModel = () => model('ProdInfo', ProdInfoSchema)

// ─── INA 7R: quality_rework_info ─────────────────────────────────────────────
// Endpoint: /quality_rework_info/get → {items:[...], hasMore:bool}
// Unique key is qtm_key. Lines: string ppd_line_number (e.g. "Line10")
const QcReworkSchema = new Schema({
  qtm_key: { type: String, required: true, unique: true },
}, { strict: false, collection: 'quality_rework_info' })
QcReworkSchema.index({ date_back: 1, ppd_line_number: 1 })
QcReworkSchema.index({ workbill: 1 })
export const QcReworkModel = () => model('QcRework', QcReworkSchema)

// ─── WiMatrix / SQL: worker_wage_by_bundle ────────────────────────────────────
// Lines: LineCode string (e.g. "8"), LineName (e.g. "Stitching Line 08")
const WageByBundleSchema = new Schema({
  WorkerWageByBundleID: { type: Number, required: true, unique: true },
}, { strict: false, collection: 'worker_wage_by_bundle' })
WageByBundleSchema.index({ ScanDate: 1, LineCode: 1 })
WageByBundleSchema.index({ WorkerCode: 1, ScanDate: 1 })
export const WageByBundleModel = () => model('WageByBundle', WageByBundleSchema)

// ─── WiMatrix / SQL: worker_wage_summary ─────────────────────────────────────
const WageSummarySchema = new Schema({
  WorkerWageSummaryID: { type: Number, required: true, unique: true },
}, { strict: false, collection: 'worker_wage_summary' })
WageSummarySchema.index({ CreatedAtDate: 1 })
WageSummarySchema.index({ WorkerCode: 1, CreatedAtDate: 1 })
export const WageSummaryModel = () => model('WageSummary', WageSummarySchema)

// ─── Sync metadata ────────────────────────────────────────────────────────────
const SyncMetaSchema = new Schema({
  source:       { type: String, required: true, unique: true },
  lastSyncedAt: Date,
  totalRecords: Number,
  status:       String,
}, { collection: 'sync_meta', timestamps: true })
export const SyncMetaModel = () => model('SyncMeta', SyncMetaSchema)
