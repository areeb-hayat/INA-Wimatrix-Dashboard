# scripts/sync.py
"""
MGA Production Dashboard — Unified Sync Script
================================================
Syncs all 4 Oracle ORDS endpoints + SQL Server into MongoDB.

ENDPOINT FORMAT MAP (verified from actual API responses):
  production_info/get             → {items:[...], hasMore:bool}  → '7r' format
  quality_rework_info/get         → {items:[...], hasMore:bool}  → '7r' format
  production_info_6r/odp_info     → {items:[...], hasMore:bool}  → '7r' format  ← NOT '6r'!
  quality_rework_info_6r/...      → {status, total, data:[...]}  → '6r' format

SYNC BUG FIX (2026-06-01):
  Incremental filter was broken: f-string had a space before the variable name
  ("{ date_field}" instead of "{date_field}") causing the key to be empty "".
  Also the date value must include a time component (T00:00:00) to match Oracle's
  stored ISO timestamp format, otherwise the server returns 400 Bad Request.

Usage:
  python scripts/sync.py                    # incremental (yesterday's data)
  python scripts/sync.py --full             # full historical sync
  python scripts/sync.py --schedule         # daily at 01:00 PKT
  python scripts/sync.py --full --schedule  # full now, then daily

Requirements:
  pip install pymongo requests python-dotenv
  pip install pyodbc  (optional, for SQL Server)
"""

import pymongo, requests, os, time, threading, argparse
from datetime import datetime, timedelta, date, timezone
from dotenv import load_dotenv
from concurrent.futures import ThreadPoolExecutor, as_completed

try:
    import pyodbc
    HAS_PYODBC = True
except ImportError:
    HAS_PYODBC = False
    print("[WARN] pyodbc not installed — SQL Server sync skipped", flush=True)

load_dotenv(os.path.join(os.path.dirname(__file__), '../.env.local'))

SQL_SERVER   = os.getenv('SQL_SERVER',      '192.168.142.31,1433')
SQL_DATABASE = os.getenv('SQL_DATABASE',    'SooperWizer')
SQL_USER     = os.getenv('SQL_USER',        'MGIT')
SQL_PASSWORD = os.getenv('SQL_PASSWORD',    'P@$$w0rD_$$')
MONGODB_URI  = os.getenv('MONGODB_URI',     'mongodb://localhost:27017/mga_production')
ORACLE_BASE  = os.getenv('ORACLE_API_BASE', 'http://110.38.236.7:7003/ords/ws_apparel')

# ─── Endpoint configuration ────────────────────────────────────────────────────
# (url, unique_id_field, response_format, page_size, timeout_sec, date_field_for_incremental)
ORACLE_ENDPOINTS = {
    'production_info':    (f'{ORACLE_BASE}/production_info/get',                   'ppd_key',  '7r', 1000, 60,  'ppd_date'),
    'quality_rework_info':(f'{ORACLE_BASE}/quality_rework_info/get',               'qtm_key',  '7r', 1000, 60,  'date_back'),
    'production_info_6r': (f'{ORACLE_BASE}/production_info_6r/odp_info',           'odpi_key', '7r',  500, 120, 'odpi_date'),
    'qc_rework_info_6r':  (f'{ORACLE_BASE}/quality_rework_info_6r/qc_rework_info', 'QCRI_Key', '6r',  500, 120, 'QCRI_QC_DateTime'),
}

INDEXES = {
    'production_info': [
        [('ppd_date', 1), ('ppd_line_number', 1)],
        [('ppd_hei_code', 1), ('ppd_date', 1)],
    ],
    'quality_rework_info': [
        [('date_back', 1), ('ppd_line_number', 1)],
        [('workbill', 1)],
    ],
    'production_info_6r': [
        [('odpi_date', 1), ('odpi_line_number', 1)],
        [('odpi_date', 1), ('odpi_line_number', 1), ('odpi_odpd_is_overtime', 1)],
        [('odpi_date', 1), ('pc_key', 1)],
        [('odpi_em_key', 1), ('odpi_date', 1)],
        [('pc_key', 1)],
        [('odp_last_hanger_time', 1)],
        [('odpi_line_number', 1)],
    ],
    'qc_rework_info_6r': [
        [('QCRI_QC_DateTime', 1), ('QCRI_LineNumber', 1)],
        [('QCRI_QC_DateTime', 1), ('QCRI_QCSC_Is_Rework', 1)],
        [('QCRI_Defect_EM_Key', 1)],
        [('QCRI_QCSC_Is_Rework', 1)],
        [('QCRI_LineNumber', 1)],
    ],
    'worker_wage_by_bundle': [
        [('ScanDate', 1), ('LineCode', 1)],
        [('WorkerCode', 1), ('ScanDate', 1)],
    ],
    'worker_wage_summary': [
        [('CreatedAtDate', 1), ('LineCode', 1)],
        [('WorkerCode', 1), ('CreatedAtDate', 1)],
    ],
}

def log(msg, src='SYNC'):
    ts = datetime.now().strftime('%H:%M:%S')
    print(f"[{ts}] [{src}] {msg}", flush=True)

def get_mongo():
    return pymongo.MongoClient(MONGODB_URI, serverSelectionTimeoutMS=10000)

def get_sql():
    if not HAS_PYODBC:
        raise RuntimeError("pyodbc not installed")
    return pyodbc.connect(
        f"DRIVER={{SQL Server}};SERVER={SQL_SERVER};DATABASE={SQL_DATABASE};"
        f"UID={SQL_USER};PWD={SQL_PASSWORD};Connect Timeout=30;"
    )

def serialize(row):
    return {k: (v.isoformat() if isinstance(v, (datetime, date)) else v) for k, v in row.items()}

def upsert(col, docs, id_field):
    valid = [d for d in docs if d.get(id_field) is not None]
    if not valid:
        return
    ops = [pymongo.UpdateOne({id_field: d[id_field]}, {'$set': d}, upsert=True) for d in valid]
    col.bulk_write(ops, ordered=False)

def build_indexes(db, collection):
    col = db[collection]
    for idx_fields in INDEXES.get(collection, []):
        try:
            col.create_index(idx_fields, background=True)
        except Exception:
            pass

def set_meta(db, source, total, status='ok'):
    db['sync_meta'].update_one(
        {'source': source},
        {'$set': {'lastSyncedAt': datetime.now().isoformat(), 'totalRecords': total, 'status': status}},
        upsert=True)

def fetch_page_with_retry(url, timeout, retries=3):
    for attempt in range(1, retries + 1):
        try:
            r = requests.get(url, timeout=timeout)
            r.raise_for_status()
            return r.json()
        except Exception as e:
            if attempt == retries:
                raise
            wait = attempt * 5
            log(f"  Attempt {attempt} failed ({e}), retrying in {wait}s…")
            time.sleep(wait)

def sync_oracle_one(name, url, id_field, fmt, page_size, timeout, db, since_date=None):
    """
    FIX: The q= filter was broken — f-string space bug caused empty key name.
    FIX: Oracle date columns are stored as full ISO timestamps; plain date
         strings (YYYY-MM-DD) cause 400. Use YYYY-MM-DDTHH:MM:SS format.
    """
    col = db[name]
    offset, total, idx_done = 0, 0, False

    base_url = url
    if since_date:
        import urllib.parse
        date_field = ORACLE_ENDPOINTS[name][5]
        # FIX: use string concat (not f-string) to avoid space-before-var bug
        # FIX: append T00:00:00 so Oracle timestamp comparison works
        since_ts = since_date + 'T00:00:00'
        q = '{"' + date_field + '":{"$gte":"' + since_ts + '"}}'
        base_url = url + '?q=' + urllib.parse.quote(q)

    mode = f"incremental from {since_date}" if since_date else "FULL"
    log(f'Starting ({fmt.upper()}, {mode}, page={page_size})', name)

    while True:
        sep = '&' if '?' in base_url else '?'
        page_url = f'{base_url}{sep}offset={offset}&limit={page_size}'

        try:
            page = fetch_page_with_retry(page_url, timeout)
        except Exception as e:
            log(f'Fatal error at offset {offset}: {e}', name)
            break

        if fmt == '7r':
            items    = page.get('items', [])
            has_more = page.get('hasMore', False)
        else:
            items      = [i for i in page.get('data', []) if i.get(id_field)]
            page_total = page.get('total', 0)
            has_more   = offset + page_size < page_total

        if not items:
            if offset == 0:
                log(f'No data returned from API (check URL and date filter)', name)
            break

        upsert(col, items, id_field)
        total += len(items)

        if not idx_done:
            idx_done = True
            build_indexes(db, name)

        if total % 5000 == 0 or len(items) < page_size:
            log(f'{total:,} records upserted…', name)

        if not has_more:
            break
        offset += page_size

    log(f'Done — {total:,} records', name)
    return total

def sync_oracle_all(db, since_date=None):
    log(f'Starting Oracle sync — all 4 endpoints concurrently ({"incremental" if since_date else "FULL"})')
    results = {}

    def run(name):
        url, id_field, fmt, page_size, timeout, _ = ORACLE_ENDPOINTS[name]
        try:
            n = sync_oracle_one(name, url, id_field, fmt, page_size, timeout, db, since_date)
            set_meta(db, name, n)
            results[name] = n
            log(f'✓ {n:,} records synced', name)
        except Exception as e:
            log(f'ERROR: {e}', name)
            set_meta(db, name, 0, 'error')
            results[name] = 0

    with ThreadPoolExecutor(max_workers=4) as pool:
        futures = {pool.submit(run, name): name for name in ORACLE_ENDPOINTS}
        for future in as_completed(futures):
            try:
                future.result()
            except Exception as e:
                log(f'Thread error: {e}')

    log(f'Oracle complete: { {k: f"{v:,}" for k, v in results.items()} }')
    return results

def sync_sql_table(table, id_field, date_field, since, db, cursor):
    col_map = {
        'WorkerWageByBundle': 'worker_wage_by_bundle',
        'WorkerWageSummary':  'worker_wage_summary',
    }
    col   = db[col_map[table]]
    where = f"WHERE {date_field} >= '{since}'" if since else ''
    log(f'{"incremental from " + since if since else "FULL"}', table)
    cursor.execute(f"SELECT * FROM Reports.[{table}] {where} ORDER BY {id_field}")
    cols  = [c[0] for c in cursor.description]
    batch, total = [], 0
    for row in cursor:
        batch.append(serialize(dict(zip(cols, row))))
        if len(batch) >= 2000:
            upsert(col, batch, id_field)
            total += len(batch)
            if total % 10000 == 0:
                log(f'{total:,} records…', table)
            batch = []
    if batch:
        upsert(col, batch, id_field)
        total += len(batch)
    build_indexes(db, col_map[table])
    log(f'Done — {total:,} records', table)
    return total

def sync_sql_all(db, since=None):
    log('Starting SQL Server sync')
    try:
        conn   = get_sql()
        cursor = conn.cursor()
    except Exception as e:
        log(f'Connection failed: {e} (skipping SQL sync)')
        return {}
    results = {}
    for table, id_field, date_field in [
        ('WorkerWageByBundle', 'WorkerWageByBundleID', 'ScanDate'),
        ('WorkerWageSummary',  'WorkerWageSummaryID',  'CreatedAtDate'),
    ]:
        try:
            n = sync_sql_table(table, id_field, date_field, since, db, cursor)
            set_meta(db, f'sql_{table.lower()}', n)
            results[table] = n
        except Exception as e:
            log(f'ERROR: {e}', table)
            results[table] = 0
    conn.close()
    return results

def run_sync(full=False):
    since = None if full else (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
    t0    = time.time()
    log(f'{"FULL" if full else "INCREMENTAL (since " + since + ")"} sync starting…')

    try:
        client = get_mongo()
        db     = client['mga_production']
    except Exception as e:
        log(f'MongoDB connection failed: {e}')
        return

    oracle_r, sql_r = {}, {}

    def do_oracle(): nonlocal oracle_r; oracle_r = sync_oracle_all(db, since)
    def do_sql():    nonlocal sql_r;    sql_r    = sync_sql_all(db, since)

    t1 = threading.Thread(target=do_oracle, daemon=True)
    t2 = threading.Thread(target=do_sql,    daemon=True)
    t1.start(); t2.start()
    t1.join(); t2.join()

    elapsed = time.time() - t0
    log(f'All done in {elapsed:.1f}s')
    client.close()

def run_scheduled():
    pkt = timezone(timedelta(hours=5))
    while True:
        now    = datetime.now(pkt)
        target = now.replace(hour=1, minute=0, second=0, microsecond=0)
        if now >= target:
            target += timedelta(days=1)
        wait = (target - now).total_seconds()
        log(f'Next sync at {target.strftime("%Y-%m-%d %H:%M PKT")} (in {wait/3600:.2f}h)', 'SCHEDULER')
        time.sleep(wait)
        log('01:00 PKT — running incremental sync', 'SCHEDULER')
        run_sync(full=False)

if __name__ == '__main__':
    p = argparse.ArgumentParser(description='MGA Production sync')
    p.add_argument('--full',     action='store_true', help='Full historical sync')
    p.add_argument('--schedule', action='store_true', help='Keep running, sync daily at 01:00 PKT')
    args = p.parse_args()

    if args.schedule:
        if args.full:
            log('Running full sync now, then scheduling daily at 01:00 PKT')
            run_sync(full=True)
        else:
            log('Waiting for 01:00 PKT before first sync…')
        run_scheduled()
    else:
        run_sync(full=args.full)
