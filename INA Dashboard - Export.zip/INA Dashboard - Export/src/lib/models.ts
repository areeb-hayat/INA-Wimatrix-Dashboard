// src/lib/models.ts
import mongoose, { Schema } from 'mongoose'

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function model(name: string, schema: Schema): any {
  return mongoose.models[name] || mongoose.model(name, schema)
}

// ─── System 6R: production_info_6r ───────────────────────────────────────────
// Endpoint: /production_info_6r/get → {items:[...], hasMore:bool} (7r-style pagination)
// All date fields stored as ISO strings (e.g. "2026-04-13T04:00:00Z")
const Prod6rSchema = new Schema({
  odpi_key: { type: String, required: true, unique: true },
}, { strict: false, collection: 'production_info_6r' })
Prod6rSchema.index({ odpi_date: 1, odpi_line_number: 1 })
Prod6rSchema.index({ odpi_date: 1, odpi_line_number: 1, odpi_odpd_is_overtime: 1 })
Prod6rSchema.index({ odpi_date: 1, pc_key: 1 })
Prod6rSchema.index({ odpi_em_key: 1, odpi_date: 1 })
Prod6rSchema.index({ pc_key: 1 })
Prod6rSchema.index({ odp_last_hanger_time: 1 })
Prod6rSchema.index({ odpi_line_number: 1 })
export const Prod6rModel = () => model('Prod6r', Prod6rSchema)

// ─── System 6R: qc_rework_info_6r ────────────────────────────────────────────
// Endpoint: /quality_rework_info_6r/qc_rework_info → {status, total, data:[...]} (6r-style)
// All date fields stored as ISO strings (e.g. "2026-05-25T16:45:59", no Z suffix)
const QcRework6rSchema = new Schema({
  QCRI_Key: { type: String, required: true, unique: true },
}, { strict: false, collection: 'qc_rework_info_6r' })
QcRework6rSchema.index({ QCRI_QC_DateTime: 1, QCRI_LineNumber: 1 })
QcRework6rSchema.index({ QCRI_QC_DateTime: 1, QCRI_QCSC_Is_Rework: 1 })
QcRework6rSchema.index({ QCRI_Defect_EM_Key: 1 })
QcRework6rSchema.index({ QCRI_QCSC_Is_Rework: 1 })
QcRework6rSchema.index({ QCRI_LineNumber: 1 })
export const QcRework6rModel = () => model('QcRework6r', QcRework6rSchema)

// ─── System 7R: production_info ──────────────────────────────────────────────
const ProdInfoSchema = new Schema({
  ppd_key: { type: String, required: true, unique: true },
}, { strict: false, collection: 'production_info' })
ProdInfoSchema.index({ ppd_date: 1, ppd_line_number: 1 })
ProdInfoSchema.index({ ppd_hei_code: 1, ppd_date: 1 })
export const ProdInfoModel = () => model('ProdInfo', ProdInfoSchema)

// ─── System 7R: quality_rework_info ──────────────────────────────────────────
// Unique key is qtm_key (NOT ppd_key — ppd_key does not exist in this collection)
const QcReworkSchema = new Schema({
  qtm_key: { type: String, required: true, unique: true },
  // Note: unique: true already creates an index on qtm_key — do NOT also call .index({qtm_key:1})
}, { strict: false, collection: 'quality_rework_info' })
QcReworkSchema.index({ date_back: 1, ppd_line_number: 1 })
QcReworkSchema.index({ workbill: 1 })
export const QcReworkModel = () => model('QcRework', QcReworkSchema)

// ─── SQL Server: worker_wage_by_bundle ────────────────────────────────────────
const WageByBundleSchema = new Schema({
  WorkerWageByBundleID: { type: Number, required: true, unique: true },
}, { strict: false, collection: 'worker_wage_by_bundle' })
WageByBundleSchema.index({ ScanDate: 1, LineCode: 1 })
WageByBundleSchema.index({ WorkerCode: 1, ScanDate: 1 })
export const WageByBundleModel = () => model('WageByBundle', WageByBundleSchema)

// ─── Sync metadata ────────────────────────────────────────────────────────────
const SyncMetaSchema = new Schema({
  source:        { type: String, required: true, unique: true },
  lastSyncedAt:  Date,
  totalRecords:  Number,
  status:        String,
}, { collection: 'sync_meta', timestamps: true })
export const SyncMetaModel = () => model('SyncMeta', SyncMetaSchema)