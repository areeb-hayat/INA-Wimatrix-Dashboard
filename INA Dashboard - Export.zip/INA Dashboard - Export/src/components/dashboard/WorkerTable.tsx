'use client'
import { ProgressBar } from '@/components/ui/ProgressBar'
import { SectionLabel } from '@/components/ui/KpiCard'
import type { WorkerRow } from '@/types'

interface Props {
  workers:      WorkerRow[]
  page:         number
  pages:        number
  total:        number
  onPageChange: (p: number) => void
  loading:      boolean
}

export function WorkerTable({ workers, page, pages, total, onPageChange, loading }: Props) {
  return (
    <div className="card overflow-hidden animate-fade-up">
      <div className="flex items-center justify-between px-4 pt-4 pb-2">
        <SectionLabel>Worker Performance</SectionLabel>
        <span className="text-[11px]" style={{ color: 'var(--text4)' }}>{total.toLocaleString()} workers</span>
      </div>
      <div className="overflow-x-auto">
        <table className="data-table">
          <thead>
            <tr>
              <th>Worker</th><th>Line</th><th>Output</th><th>Earned Mins</th>
              <th style={{ minWidth: 130 }}>Efficiency</th>
              <th>Defects</th><th>DHU %</th><th>Wage (PKR)</th><th>Ops</th>
            </tr>
          </thead>
          <tbody>
            {loading
              ? Array.from({ length: 8 }).map((_, i) => (
                  <tr key={i}>
                    {Array.from({ length: 9 }).map((_, j) => (
                      <td key={j}><div className="h-4 rounded animate-shimmer" style={{ background: 'var(--border)' }} /></td>
                    ))}
                  </tr>
                ))
              : workers.map((w) => (
                  <tr key={w.id}>
                    <td>
                      <div className="font-semibold text-xs" style={{ color: 'var(--text1)' }}>{w.name}</div>
                      <div className="text-[10px] font-mono" style={{ color: 'var(--text4)' }}>#{w.id}</div>
                    </td>
                    <td><span className="font-bold text-xs" style={{ color: 'var(--accent)' }}>L{w.line}</span></td>
                    <td><span className="font-bold" style={{ color: 'var(--text1)' }}>{w.qty.toLocaleString()}</span></td>
                    <td style={{ color: 'var(--kpi-green)' }}>{w.earnedMins}</td>
                    <td style={{ minWidth: 130 }}>
                      <div className="flex items-center gap-2">
                        <div className="flex-1"><ProgressBar value={w.efficiency} height={5} /></div>
                        <span className="text-[11px] font-black tabular-nums w-11 text-right"
                          style={{ color: w.efficiency >= 80 ? 'var(--kpi-green)' : w.efficiency >= 60 ? 'var(--kpi-yellow)' : 'var(--kpi-red)' }}>
                          {w.efficiency.toFixed(1)}%
                        </span>
                      </div>
                    </td>
                    <td><span style={{ color: w.defects > 0 ? 'var(--kpi-red)' : 'var(--text4)' }}>{w.defects}</span></td>
                    <td>
                      <span className="font-bold text-xs"
                        style={{ color: w.dhu > 5 ? 'var(--kpi-red)' : w.dhu > 2 ? 'var(--kpi-yellow)' : 'var(--kpi-green)' }}>
                        {w.dhu.toFixed(2)}%
                      </span>
                    </td>
                    <td>
                      <span className="font-mono text-[11px]" style={{ color: 'var(--accent)' }}>
                        {w.wage.toLocaleString('en-PK', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </span>
                    </td>
                    <td style={{ color: 'var(--text3)' }}>{w.opCount}</td>
                  </tr>
                ))}
          </tbody>
        </table>
      </div>
      {pages > 1 && (
        <div className="flex items-center justify-between px-4 py-2.5" style={{ borderTop: '1px solid var(--border)' }}>
          <span className="text-[11px]" style={{ color: 'var(--text4)' }}>Page {page} of {pages}</span>
          <div className="flex gap-1">
            {[
              { label: '←', disabled: page === 1,     action: () => onPageChange(page - 1) },
              { label: '→', disabled: page === pages, action: () => onPageChange(page + 1) },
            ].map(({ label, disabled, action }) => (
              <button key={label} onClick={action} disabled={disabled}
                className="w-7 h-7 rounded-lg text-xs font-bold disabled:opacity-30 transition-all"
                style={{ background: 'var(--bg2)', border: '1px solid var(--border2)', color: 'var(--accent)' }}>
                {label}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
