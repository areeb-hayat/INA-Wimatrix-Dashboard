'use client'
import { useState, useRef, useEffect } from 'react'
import { useTheme } from '@/app/context/ThemeContext'
import type { SyncSource, TimeFilter, TimeFilterPreset } from '@/types'

// ─── Time filter logic ────────────────────────────────────────────────────────
export function makeTimeFilter(preset: TimeFilterPreset): TimeFilter {
  const today = new Date(); today.setHours(0, 0, 0, 0)
  const end   = new Date(); end.setHours(23, 59, 59, 999)
  switch (preset) {
    case 'yesterday': {
      const from = new Date(today); from.setDate(from.getDate() - 1)
      const to   = new Date(from);  to.setHours(23, 59, 59, 999)
      return { preset, from, to, label: 'Yesterday' }
    }
    case 'this_week': {
      const from = new Date(today); from.setDate(today.getDate() - today.getDay())
      const to   = new Date(from);  to.setDate(from.getDate() + 6); to.setHours(23, 59, 59, 999)
      return { preset, from, to, label: 'This week' }
    }
    case 'last_week': {
      const from = new Date(today); from.setDate(today.getDate() - today.getDay() - 7)
      const to   = new Date(from);  to.setDate(from.getDate() + 6); to.setHours(23, 59, 59, 999)
      return { preset, from, to, label: 'Last week' }
    }
    case 'this_month': {
      const from = new Date(today.getFullYear(), today.getMonth(), 1)
      const to   = new Date(today.getFullYear(), today.getMonth() + 1, 0, 23, 59, 59)
      return { preset, from, to, label: 'This month' }
    }
    case 'last_month': {
      const from = new Date(today.getFullYear(), today.getMonth() - 1, 1)
      const to   = new Date(today.getFullYear(), today.getMonth(), 0, 23, 59, 59)
      return { preset, from, to, label: 'Last month' }
    }
    case 'last_3_months': {
      const from = new Date(today); from.setMonth(from.getMonth() - 3)
      return { preset, from, to: end, label: 'Last 3 months' }
    }
    case 'last_6_months': {
      const from = new Date(today); from.setMonth(from.getMonth() - 6)
      return { preset, from, to: end, label: 'Last 6 months' }
    }
    default:
      return { preset: 'all', from: null, to: null, label: 'All time' }
  }
}

// ─── Presets list ─────────────────────────────────────────────────────────────
const PRESETS: { key: TimeFilterPreset; label: string }[] = [
  { key: 'yesterday',     label: 'Yesterday'     },
  { key: 'this_week',     label: 'This week'     },
  { key: 'last_week',     label: 'Last week'     },
  { key: 'this_month',    label: 'This month'    },
  { key: 'last_month',    label: 'Last month'    },
  { key: 'last_3_months', label: 'Last 3 months' },
  { key: 'last_6_months', label: 'Last 6 months' },
]

// ─── Inline time filter widget (matches reference DashboardHeader.tsx exactly) ─
function TimeFilterWidget({ filter, onChange }: { filter: TimeFilter; onChange: (f: TimeFilter) => void }) {
  const [open,       setOpen]       = useState(false)
  const [customFrom, setCustomFrom] = useState('')
  const [customTo,   setCustomTo]   = useState('')
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const h = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false)
    }
    document.addEventListener('mousedown', h)
    return () => document.removeEventListener('mousedown', h)
  }, [])

  const isFiltered = filter.preset !== 'all'

  const btnStyle = (active: boolean) => ({
    background: active ? 'var(--accent)'  : 'var(--bg2)',
    color:      active ? '#fff'           : 'var(--text2)',
    border:     `1px solid ${active ? 'var(--accent)' : 'var(--border)'}`,
  })

  return (
    <div className="relative" ref={ref}>
      {/* Trigger — label shown inline, × inside when filtered */}
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex items-center gap-1.5 h-8 px-3 rounded-lg text-[11px] font-semibold transition-all"
        style={{
          background: isFiltered ? 'rgba(255,255,255,0.25)' : 'rgba(255,255,255,0.12)',
          border:     `1px solid ${isFiltered ? 'rgba(255,255,255,0.5)' : 'rgba(255,255,255,0.18)'}`,
          color:      '#fff',
        }}
      >
        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
          <rect x="3" y="4" width="18" height="18" rx="2"/>
          <line x1="16" y1="2" x2="16" y2="6"/>
          <line x1="8"  y1="2" x2="8"  y2="6"/>
          <line x1="3"  y1="10" x2="21" y2="10"/>
        </svg>
        <span className="max-w-[110px] truncate">{filter.label}</span>
        {/* × clears filter inline — no badge */}
        {isFiltered && (
          <button
            onClick={(e) => { e.stopPropagation(); onChange(makeTimeFilter('all')); setOpen(false) }}
            className="ml-0.5 opacity-70 hover:opacity-100 font-bold leading-none text-sm"
          >
            ×
          </button>
        )}
        <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5}
          style={{ transform: open ? 'rotate(180deg)' : 'rotate(0deg)', transition: 'transform 0.2s', opacity: 0.7 }}>
          <polyline points="6 9 12 15 18 9"/>
        </svg>
      </button>

      {/* Dropdown — opens to the right */}
      {open && (
        <div
          className="absolute right-0 top-full mt-1.5 z-50 rounded-2xl p-3"
          style={{
            width: 262,
            background:  'var(--surface)',
            border:      '1px solid var(--border2)',
            boxShadow:   '0 12px 40px rgba(0,0,0,0.22)',
          }}
        >
          {/* All time */}
          <button
            onClick={() => { onChange(makeTimeFilter('all')); setOpen(false) }}
            className="w-full text-left px-3 py-1.5 rounded-lg text-xs font-bold mb-2 transition-colors"
            style={btnStyle(filter.preset === 'all')}
          >
            All time
          </button>

          {/* Preset grid */}
          <div className="grid grid-cols-2 gap-1 mb-3">
            {PRESETS.map((p) => (
              <button
                key={p.key}
                onClick={() => { onChange(makeTimeFilter(p.key)); setOpen(false) }}
                className="px-2 py-1.5 rounded-lg text-[11px] font-medium text-left transition-colors"
                style={btnStyle(filter.preset === p.key)}
              >
                {p.label}
              </button>
            ))}
          </div>

          {/* Custom range */}
          <div style={{ borderTop: '1px solid var(--border)' }} className="pt-2.5 space-y-1.5">
            <p className="text-[9px] font-black uppercase tracking-widest" style={{ color: 'var(--text4)' }}>Custom Range</p>
            {(['From', 'To'] as const).map((lbl) => (
              <div key={lbl} className="flex items-center gap-2">
                <span className="text-[10px] w-7 shrink-0" style={{ color: 'var(--text4)' }}>{lbl}</span>
                <input
                  type="date"
                  value={lbl === 'From' ? customFrom : customTo}
                  onChange={(e) => lbl === 'From' ? setCustomFrom(e.target.value) : setCustomTo(e.target.value)}
                  className="flex-1 text-xs rounded-lg px-2 py-1 outline-none"
                  style={{ background: 'var(--bg2)', border: '1px solid var(--border2)', color: 'var(--text1)' }}
                />
              </div>
            ))}
            <button
              onClick={() => {
                if (!customFrom || !customTo) return
                const from  = new Date(customFrom); from.setHours(0, 0, 0, 0)
                const to    = new Date(customTo);   to.setHours(23, 59, 59, 999)
                const label = `${from.toLocaleDateString('en-PK', { day: 'numeric', month: 'short' })} – ${to.toLocaleDateString('en-PK', { day: 'numeric', month: 'short', year: '2-digit' })}`
                onChange({ preset: 'custom', from, to, label })
                setOpen(false)
              }}
              disabled={!customFrom || !customTo}
              className="w-full py-1.5 rounded-xl text-xs font-bold disabled:opacity-40 mt-1"
              style={{ background: 'var(--accent)', color: '#fff' }}
            >
              Apply Range
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

// ─── Styled line selector pill (matches time filter style) ────────────────────
function LineSelector({
  selectedLine, lines, onChange,
}: { selectedLine: string; lines: number[]; onChange: (l: string) => void }) {
  const [open, setOpen] = useState(false)
  const ref  = useRef<HTMLDivElement>(null)
  const isFiltered = selectedLine !== 'all'

  useEffect(() => {
    const h = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false)
    }
    document.addEventListener('mousedown', h)
    return () => document.removeEventListener('mousedown', h)
  }, [])

  const label = isFiltered ? `Line ${selectedLine}` : 'All Lines'

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex items-center gap-1.5 h-8 px-3 rounded-lg text-[11px] font-semibold transition-all"
        style={{
          background: isFiltered ? 'rgba(255,255,255,0.25)' : 'rgba(255,255,255,0.12)',
          border:     `1px solid ${isFiltered ? 'rgba(255,255,255,0.5)' : 'rgba(255,255,255,0.18)'}`,
          color:      '#fff',
        }}
      >
        {/* Line icon */}
        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
          <rect x="3" y="3" width="18" height="4" rx="1"/>
          <rect x="3" y="10" width="18" height="4" rx="1"/>
          <rect x="3" y="17" width="18" height="4" rx="1"/>
        </svg>
        <span className="max-w-[90px] truncate">{label}</span>
        {isFiltered && (
          <button
            onClick={(e) => { e.stopPropagation(); onChange('all'); setOpen(false) }}
            className="ml-0.5 opacity-70 hover:opacity-100 font-bold leading-none text-sm"
          >
            ×
          </button>
        )}
        <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5}
          style={{ transform: open ? 'rotate(180deg)' : 'rotate(0deg)', transition: 'transform 0.2s', opacity: 0.7 }}>
          <polyline points="6 9 12 15 18 9"/>
        </svg>
      </button>

      {open && (
        <div
          className="absolute right-0 top-full mt-1.5 z-50 rounded-2xl p-2"
          style={{
            minWidth:   160,
            background: 'var(--surface)',
            border:     '1px solid var(--border2)',
            boxShadow:  '0 12px 40px rgba(0,0,0,0.22)',
          }}
        >
          {['all', ...lines.map(String)].map((l) => {
            const active = l === selectedLine
            const lbl    = l === 'all' ? 'All Lines' : `Line ${l}`
            return (
              <button
                key={l}
                onClick={() => { onChange(l); setOpen(false) }}
                className="w-full text-left px-3 py-1.5 rounded-lg text-xs font-medium transition-colors mb-0.5"
                style={{
                  background: active ? 'var(--accent)' : 'transparent',
                  color:      active ? '#fff' : 'var(--text2)',
                }}
              >
                {lbl}
              </button>
            )
          })}
        </div>
      )}
    </div>
  )
}

// ─── Theme toggle ─────────────────────────────────────────────────────────────
function ThemeToggle() {
  const { isDark, toggleTheme } = useTheme()
  return (
    <button
      onClick={toggleTheme}
      className="flex items-center justify-center w-8 h-8 rounded-lg transition-all"
      style={{ background: 'rgba(255,255,255,0.12)', border: '1px solid rgba(255,255,255,0.18)', color: '#fff' }}
      title={isDark ? 'Light mode' : 'Dark mode'}
    >
      {isDark ? (
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
          <circle cx="12" cy="12" r="5"/>
          <line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/>
          <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/>
          <line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/>
          <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>
        </svg>
      ) : (
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
          <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
        </svg>
      )}
    </button>
  )
}

// ─── Sync popup ───────────────────────────────────────────────────────────────
const SOURCE_LABELS: Record<string, string> = {
  production_info:     'Prod (7R)',
  quality_rework_info: 'QC (7R)',
  production_info_6r:  'Prod (6R)',
  qc_rework_info_6r:   'QC (6R)',
  sql_workerwagebyb:   'Wage/Bundle',
  sql_workerwagebys:   'Wage/Summary',
}

// ─── Main header props ────────────────────────────────────────────────────────
interface Props {
  selectedLine:       string
  lines:              number[]
  onLineChange:       (l: string) => void
  timeFilter:         TimeFilter
  onTimeFilterChange: (f: TimeFilter) => void
  loading:            boolean
  onRefresh:          () => void
  syncSources:        SyncSource[]
  activeTab:          string
  onTabChange:        (t: string) => void
}

const TABS = [
  { key: 'overview', label: 'Overview'  },
  { key: 'lines',    label: 'All Lines' },
  { key: 'workers',  label: 'Workers'   },
  { key: 'trends',   label: 'Trends'    },
]

export function DashboardHeader({
  selectedLine, lines, onLineChange,
  timeFilter, onTimeFilterChange,
  loading, onRefresh, syncSources,
  activeTab, onTabChange,
}: Props) {
  const [showSync, setShowSync] = useState(false)
  const syncRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const h = (e: MouseEvent) => {
      if (syncRef.current && !syncRef.current.contains(e.target as Node)) setShowSync(false)
    }
    document.addEventListener('mousedown', h)
    return () => document.removeEventListener('mousedown', h)
  }, [])

  const lastSync  = syncSources.find((s) => s.lastSyncedAt)?.lastSyncedAt
  const hasError  = syncSources.some((s) => s.status === 'error')
  const allOk     = syncSources.length > 0 && syncSources.every((s) => s.status === 'ok')
  const dotColor  = hasError ? '#F87070' : allOk ? '#4ADE80' : 'rgba(255,255,255,0.35)'
  const syncLabel = lastSync
    ? `Synced ${new Date(lastSync).toLocaleString('en-PK', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}`
    : 'Never synced'

  return (
    <header className="sticky top-0 z-30" style={{ background: 'var(--header-bg)', boxShadow: '0 2px 16px rgba(0,0,0,0.18)' }}>
      <div className="max-w-screen-2xl mx-auto px-4 sm:px-6">

        {/* Main bar: Logo left | Controls right (matching reference) */}
        <div className="flex items-center justify-between h-16 gap-3">

          {/* Logo */}
          <div className="flex flex-col leading-none shrink-0 select-none">
            <span className="font-black tracking-tight text-lg sm:text-xl"
              style={{ color: '#FFFFFF', letterSpacing: '-0.025em', lineHeight: 1 }}>
              MG APPAREL
            </span>
            <span className="text-[9px] font-extrabold tracking-[0.22em] uppercase mt-1"
              style={{ color: 'rgba(255,255,255,0.55)', lineHeight: 1 }}>
              Production
            </span>
          </div>

          {/* Right side: all controls grouped together like reference */}
          <div className="flex items-center gap-2 flex-wrap justify-end">

            {/* Line selector — styled pill, same as time filter */}
            <LineSelector selectedLine={selectedLine} lines={lines} onChange={onLineChange} />

            {/* Time filter — inline label, × inside, no separate badge */}
            <TimeFilterWidget filter={timeFilter} onChange={onTimeFilterChange} />

            {/* Sync status */}
            <div className="relative" ref={syncRef}>
              <button
                onClick={() => setShowSync((v) => !v)}
                className="flex items-center gap-1.5 h-8 px-2.5 rounded-lg text-[11px] font-semibold"
                style={{ background: 'rgba(255,255,255,0.12)', border: '1px solid rgba(255,255,255,0.18)', color: '#fff' }}
              >
                <span className="w-1.5 h-1.5 rounded-full shrink-0"
                  style={{ background: dotColor, boxShadow: allOk ? `0 0 6px ${dotColor}` : 'none' }} />
                <span className="hidden sm:inline max-w-[140px] truncate text-[11px]">{syncLabel}</span>
              </button>

              {showSync && (
                <div className="absolute right-0 top-full mt-2 w-80 rounded-2xl z-50 p-4 animate-fade-up"
                  style={{ background: 'var(--surface)', border: '1px solid var(--border2)', boxShadow: '0 16px 48px rgba(0,0,0,0.22)' }}>
                  <div className="flex items-center justify-between mb-3">
                    <p className="text-sm font-bold" style={{ color: 'var(--text1)' }}>MongoDB Sync Status</p>
                    <button onClick={() => setShowSync(false)} className="text-xl opacity-40 hover:opacity-70" style={{ color: 'var(--text1)' }}>×</button>
                  </div>
                  <div className="space-y-1.5 mb-3">
                    {syncSources.length === 0 ? (
                      <p className="text-xs text-center py-2" style={{ color: 'var(--text4)' }}>
                        No sync data — run <code className="font-mono">python scripts/sync.py --full</code>
                      </p>
                    ) : syncSources.map((s) => (
                      <div key={s.source} className="flex items-center justify-between py-1.5 px-2 rounded-lg"
                        style={{ background: 'var(--bg2)' }}>
                        <div className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full shrink-0"
                            style={{ background: s.status === 'ok' ? '#4ADE80' : s.status === 'error' ? '#F87070' : 'var(--text4)' }} />
                          <span className="text-[11px] font-medium" style={{ color: 'var(--text2)' }}>
                            {SOURCE_LABELS[s.source] || s.source}
                          </span>
                        </div>
                        <div className="text-right">
                          {s.totalRecords !== undefined && (
                            <span className="text-[11px] font-bold" style={{ color: 'var(--accent)' }}>
                              {s.totalRecords.toLocaleString()}
                            </span>
                          )}
                          {s.lastSyncedAt && (
                            <span className="text-[10px] ml-1.5" style={{ color: 'var(--text4)' }}>
                              {new Date(s.lastSyncedAt).toLocaleString('en-PK', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="rounded-xl p-3 text-xs" style={{ background: 'var(--bg3)', border: '1px solid var(--border)' }}>
                    <p className="font-bold mb-1" style={{ color: 'var(--text2)' }}>Sync commands:</p>
                    <code className="font-mono text-[11px]" style={{ color: 'var(--accent)' }}>python scripts/sync.py --full</code>
                    <br/>
                    <code className="font-mono text-[11px]" style={{ color: 'var(--text3)' }}>npm run sync:full</code>
                  </div>
                </div>
              )}
            </div>

            {/* Refresh */}
            <button
              onClick={onRefresh} disabled={loading}
              className="flex items-center gap-1.5 h-8 px-2.5 rounded-lg text-[11px] font-semibold disabled:opacity-50"
              style={{ background: 'rgba(255,255,255,0.12)', border: '1px solid rgba(255,255,255,0.18)', color: '#fff' }}
            >
              <svg className={`w-3 h-3 ${loading ? 'animate-spin' : ''}`} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5}>
                <path strokeLinecap="round" strokeLinejoin="round"
                  d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>
              </svg>
              <span className="hidden sm:inline">{loading ? 'Loading…' : 'Refresh'}</span>
            </button>

            <ThemeToggle />
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-0 overflow-x-auto scrollbar-none" style={{ marginBottom: '-1px' }}>
          {TABS.map(({ key, label }) => (
            <button key={key} onClick={() => onTabChange(key)}
              className="px-5 py-2.5 text-[13px] font-semibold whitespace-nowrap transition-all"
              style={{
                color:         activeTab === key ? '#FFFFFF' : 'rgba(255,255,255,0.50)',
                background:    'transparent',
                border:        'none',
                outline:       'none',
                borderBottom:  activeTab === key ? '2.5px solid #FFFFFF' : '2.5px solid transparent',
                paddingBottom: '9px',
              }}
            >
              {label}
            </button>
          ))}
        </div>
      </div>
    </header>
  )
}
