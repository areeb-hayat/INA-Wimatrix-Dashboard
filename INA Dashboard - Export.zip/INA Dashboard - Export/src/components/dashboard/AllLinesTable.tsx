'use client'
import { ProgressBar } from '@/components/ui/ProgressBar'
import { SectionLabel } from '@/components/ui/KpiCard'
import type { LineKpis } from '@/types'

interface Props {
  lines:        LineKpis[]
  onLineSelect: (line: string) => void
  selectedLine: string
}

export function AllLinesTable({ lines, onLineSelect, selectedLine }: Props) {
  if (!lines.length) {
    return (
      <div className="card p-8 text-center">
        <p className="text-sm" style={{ color: 'var(--text4)' }}>No line data for this period</p>
      </div>
    )
  }

  return (
    <div className="card overflow-hidden animate-fade-up">
      <div className="px-4 pt-4 pb-2">
        <SectionLabel>All Lines — Click to drill in</SectionLabel>
      </div>
      <div className="overflow-x-auto">
        <table className="data-table">
          <thead>
            <tr>
              <th>Line</th><th>Output</th><th>Target</th><th>Achieved</th>
              <th>Workers</th><th>Earned Mins</th><th>Plan Mins</th>
              <th style={{ minWidth: 130 }}>Efficiency</th>
              <th>DHU %</th><th>Rework</th><th>Pending</th><th>WIP</th>
            </tr>
          </thead>
          <tbody>
            {lines.map((l) => {
              const active = selectedLine === String(l.line)
              return (
                <tr key={l.line}
                  onClick={() => onLineSelect(active ? 'all' : String(l.line))}
                  style={{ cursor: 'pointer', background: active ? 'var(--info-bg)' : undefined }}>
                  <td><span className="font-black text-sm" style={{ color: 'var(--accent)' }}>{l.lineName}</span></td>
                  <td><span className="font-bold" style={{ color: 'var(--text1)' }}>{l.output.toLocaleString()}</span></td>
                  <td style={{ color: 'var(--text3)' }}>{l.plannedQty.toLocaleString()}</td>
                  <td>
                    <span className="font-bold text-xs"
                      style={{ color: l.targetAchievedPct >= 80 ? 'var(--kpi-green)' : l.targetAchievedPct >= 60 ? 'var(--kpi-yellow)' : 'var(--kpi-red)' }}>
                      {l.targetAchievedPct}%
                    </span>
                  </td>
                  <td style={{ color: 'var(--text2)' }}>{l.workerCount}</td>
                  <td style={{ color: 'var(--kpi-green)' }}>{l.earnedMinutes.toLocaleString()}</td>
                  <td style={{ color: 'var(--text3)' }}>{l.planMinutes.toLocaleString()}</td>
                  <td style={{ minWidth: 130 }}><ProgressBar value={l.efficiency} showValue height={6} /></td>
                  <td>
                    <span className="font-bold text-xs"
                      style={{ color: l.dhu <= 2 ? 'var(--kpi-green)' : l.dhu <= 5 ? 'var(--kpi-yellow)' : 'var(--kpi-red)' }}>
                      {l.dhu.toFixed(2)}%
                    </span>
                  </td>
                  <td><span style={{ color: l.rework > 0 ? 'var(--kpi-orange)' : 'var(--text4)' }}>{l.rework}</span></td>
                  <td><span style={{ color: l.pendingRework > 0 ? 'var(--kpi-red)' : 'var(--kpi-green)' }}>{l.pendingRework}</span></td>
                  <td style={{ color: 'var(--text2)' }}>{l.wip.toLocaleString()}</td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}
