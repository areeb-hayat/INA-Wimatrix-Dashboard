'use client'
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  ComposedChart, Line, Area, Cell, ReferenceLine,
} from 'recharts'
import { useTheme } from '@/app/context/ThemeContext'
import { SectionLabel } from '@/components/ui/KpiCard'

const DEFECT_COLORS = ['#EF4444','#F97316','#F59E0B','#EAB308','#EC4899','#A855F7','#6366F1','#3B82F6','#06B6D4','#10B981']

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function ChartTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null
  return (
    <div className="rounded-xl p-3 text-xs shadow-xl"
      style={{ background: 'var(--surface)', border: '1px solid var(--border2)' }}>
      <p className="font-bold mb-1.5" style={{ color: 'var(--text3)' }}>{label}</p>
      {payload.map((p: { name: string; value: number; color: string }, i: number) => (
        <div key={i} className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: p.color }} />
          <span style={{ color: 'var(--text3)' }}>{p.name}:</span>
          <span className="font-bold" style={{ color: 'var(--text1)' }}>{p.value}</span>
        </div>
      ))}
    </div>
  )
}

interface DefectItem  { name: string; count: number }
interface HourlyItem  { hour: string; qty: number; target: number }
interface TrendItem   { label: string; output: number; efficiency: number; dhu: number }

interface Props {
  defects: DefectItem[]
  hourly:  HourlyItem[]
  trend:   TrendItem[]
}

function EmptyState({ msg, icon = '—', good = false }: { msg: string; icon?: string; good?: boolean }) {
  return (
    <div className="h-40 flex flex-col items-center justify-center gap-2">
      <span className="text-2xl" style={{ color: good ? 'var(--kpi-green)' : 'var(--text4)' }}>{icon}</span>
      <p className="text-xs" style={{ color: 'var(--text4)' }}>{msg}</p>
    </div>
  )
}

export function ChartsSection({ defects, hourly, trend }: Props) {
  const { isDark } = useTheme()
  const axisColor  = isDark ? '#3A6888' : '#82AAC4'
  const gridColor  = isDark ? '#1C3850' : '#C2DFF2'

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Hourly output */}
        <div className="card p-4">
          <SectionLabel>Hourly Output</SectionLabel>
          {hourly.length === 0 ? <EmptyState msg="No hourly data yet" /> : (
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={hourly} barSize={18}>
                <CartesianGrid stroke={gridColor} strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="hour" tick={{ fontSize: 10, fill: axisColor }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: axisColor }} axisLine={false} tickLine={false} />
                <Tooltip content={<ChartTooltip />} />
                <ReferenceLine y={hourly[0]?.target} stroke="var(--kpi-yellow)" strokeDasharray="4 4" strokeWidth={1.5} />
                <Bar dataKey="qty" name="Output" radius={[4, 4, 0, 0]}>
                  {hourly.map((_, i) => (
                    <Cell key={i} fill={i === hourly.length - 1 ? 'var(--kpi-cyan)' : 'var(--border2)'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* Defect breakdown */}
        <div className="card p-4">
          <SectionLabel>Top Defect Types</SectionLabel>
          {defects.length === 0 ? <EmptyState msg="No defects recorded" icon="✓" good /> : (
            <div className="space-y-2 max-h-44 overflow-y-auto pr-1">
              {defects.map((d, i) => {
                const pct = (d.count / defects[0].count) * 100
                return (
                  <div key={i}>
                    <div className="flex justify-between mb-0.5">
                      <span className="text-xs truncate pr-2 max-w-[75%]" style={{ color: 'var(--text2)' }}>{d.name}</span>
                      <span className="text-xs font-bold tabular-nums" style={{ color: DEFECT_COLORS[i % 10] }}>{d.count}</span>
                    </div>
                    <div className="h-1.5 rounded-full" style={{ background: 'var(--gauge-track)' }}>
                      <div className="h-full rounded-full transition-all duration-700"
                        style={{ width: `${pct}%`, background: DEFECT_COLORS[i % 10] }} />
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </div>
      </div>

      {/* Trend chart */}
      <div className="card p-4">
        <SectionLabel>Output &amp; Efficiency Trend</SectionLabel>
        {trend.length === 0 ? <EmptyState msg="No trend data" /> : (
          <ResponsiveContainer width="100%" height={200}>
            <ComposedChart data={trend}>
              <defs>
                <linearGradient id="outGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor="var(--kpi-cyan)" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="var(--kpi-cyan)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke={gridColor} strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="label" tick={{ fontSize: 10, fill: axisColor }} axisLine={false} tickLine={false} />
              <YAxis yAxisId="left"  tick={{ fontSize: 10, fill: axisColor }} axisLine={false} tickLine={false} />
              <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 10, fill: axisColor }} axisLine={false} tickLine={false} domain={[0, 120]} unit="%" />
              <Tooltip content={<ChartTooltip />} />
              <ReferenceLine yAxisId="right" y={80} stroke="var(--kpi-yellow)" strokeDasharray="4 4" strokeWidth={1.5} />
              <Area yAxisId="left"  type="monotone" dataKey="output" name="Output" stroke="var(--kpi-cyan)" strokeWidth={2} fill="url(#outGrad)" />
              <Line yAxisId="right" type="monotone" dataKey="efficiency" name="Efficiency %" stroke="var(--kpi-green)" strokeWidth={2.5} dot={{ fill: 'var(--kpi-green)', r: 3, strokeWidth: 0 }} />
              <Line yAxisId="right" type="monotone" dataKey="dhu" name="DHU %" stroke="var(--kpi-red)" strokeWidth={2} strokeDasharray="5 3" dot={{ fill: 'var(--kpi-red)', r: 2.5, strokeWidth: 0 }} />
            </ComposedChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  )
}
