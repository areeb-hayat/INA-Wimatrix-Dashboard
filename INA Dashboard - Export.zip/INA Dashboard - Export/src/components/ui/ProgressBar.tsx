'use client'

interface Props {
  value:      number   // 0–100
  showValue?: boolean
  height?:    number
}

export function ProgressBar({ value, showValue, height = 6 }: Props) {
  const clamped = Math.min(100, Math.max(0, value))
  const color   = clamped >= 80 ? 'var(--kpi-green)' : clamped >= 60 ? 'var(--kpi-yellow)' : 'var(--kpi-red)'

  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 rounded-full overflow-hidden" style={{ height, background: 'var(--gauge-track)' }}>
        <div
          className="h-full rounded-full transition-all duration-700"
          style={{ width: `${clamped}%`, background: color }}
        />
      </div>
      {showValue && (
        <span className="text-[11px] font-black tabular-nums w-10 text-right" style={{ color }}>
          {clamped.toFixed(1)}%
        </span>
      )}
    </div>
  )
}
