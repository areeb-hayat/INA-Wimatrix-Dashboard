'use client'
import { ProgressBar } from '@/components/ui/ProgressBar'

interface Props {
  output:    number
  planned:   number
  lastHour:  number
  mtdOutput: number
}

export function TodaysTargetCard({ output, planned, lastHour, mtdOutput }: Props) {
  const pct = planned > 0 ? Math.round((output / planned) * 100) : 0
  const color = pct >= 80 ? 'var(--kpi-green)' : pct >= 60 ? 'var(--kpi-yellow)' : 'var(--kpi-red)'

  return (
    <div className="card p-4 h-full flex flex-col gap-3">
      <p className="text-[10px] font-black uppercase tracking-widest" style={{ color: 'var(--text4)' }}>
        Today&apos;s Target
      </p>
      <div>
        <div className="flex items-end gap-1.5">
          <span className="text-4xl font-black tabular-nums leading-none" style={{ color }}>
            {output.toLocaleString()}
          </span>
          <span className="text-sm font-bold mb-0.5" style={{ color: 'var(--text3)' }}>
            / {planned.toLocaleString()} pcs
          </span>
        </div>
        <p className="text-xs mt-1" style={{ color: 'var(--text4)' }}>{pct}% of target</p>
      </div>
      <ProgressBar value={pct} showValue height={8} />
      <div className="grid grid-cols-2 gap-2 pt-1">
        <div className="rounded-lg p-2.5" style={{ background: 'var(--bg2)', border: '1px solid var(--border)' }}>
          <p className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: 'var(--text4)' }}>Last Hour</p>
          <p className="text-lg font-black tabular-nums" style={{ color: 'var(--kpi-cyan)' }}>{lastHour.toLocaleString()}</p>
        </div>
        <div className="rounded-lg p-2.5" style={{ background: 'var(--bg2)', border: '1px solid var(--border)' }}>
          <p className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: 'var(--text4)' }}>MTD Total</p>
          <p className="text-lg font-black tabular-nums" style={{ color: 'var(--kpi-cyan)' }}>{mtdOutput.toLocaleString()}</p>
        </div>
      </div>
    </div>
  )
}
