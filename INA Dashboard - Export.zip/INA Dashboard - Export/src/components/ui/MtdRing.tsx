'use client'

interface Props { achieved: number; target: number }

export function MtdRing({ achieved, target }: Props) {
  const pct     = target > 0 ? Math.min(100, (achieved / target) * 100) : 0
  const r       = 70, cx = 90, cy = 90, sw = 14
  const circ    = 2 * Math.PI * r
  const color   = pct >= 80 ? 'var(--kpi-green)' : pct >= 50 ? 'var(--kpi-yellow)' : 'var(--kpi-red)'

  return (
    <div className="flex flex-col items-center select-none">
      <svg width={180} height={180} viewBox="0 0 180 180">
        <circle cx={cx} cy={cy} r={r} fill="none" stroke="var(--gauge-track)" strokeWidth={sw} />
        <circle cx={cx} cy={cy} r={r} fill="none" stroke={color} strokeWidth={sw}
          strokeDasharray={`${(pct / 100) * circ} ${circ}`}
          strokeDashoffset={circ / 4}
          strokeLinecap="round"
          style={{ transition: 'stroke-dasharray 1s ease', filter: `drop-shadow(0 0 6px ${color})` }}
        />
        <text x={cx} y={cy - 8}  textAnchor="middle" fontFamily="var(--font-inter)" fontWeight="900" fontSize="22" fill={color}>
          {pct.toFixed(1)}%
        </text>
        <text x={cx} y={cy + 12} textAnchor="middle" fontFamily="var(--font-inter)" fontWeight="600" fontSize="10" fill="var(--text4)">
          MTD OUTPUT
        </text>
        <text x={cx} y={cy + 28} textAnchor="middle" fontFamily="var(--font-inter)" fontWeight="700" fontSize="12" fill="var(--text2)">
          {achieved.toLocaleString()}
        </text>
      </svg>
    </div>
  )
}
