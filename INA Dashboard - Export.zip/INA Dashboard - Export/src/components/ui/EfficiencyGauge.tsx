'use client'

interface Props { value: number; size?: number }

export function EfficiencyGauge({ value, size = 210 }: Props) {
  const clamped = Math.min(100, Math.max(0, value))
  const r = (size - 24) / 2
  const cx = size / 2, cy = size / 2
  const startAngle = -220, totalDeg = 260
  const angle = startAngle + (clamped / 100) * totalDeg
  const toRad = (d: number) => (d * Math.PI) / 180

  const arcPath = (start: number, end: number) => {
    const s = { x: cx + r * Math.cos(toRad(start)), y: cy + r * Math.sin(toRad(start)) }
    const e = { x: cx + r * Math.cos(toRad(end)),   y: cy + r * Math.sin(toRad(end)) }
    const large = end - start > 180 ? 1 : 0
    return `M ${s.x} ${s.y} A ${r} ${r} 0 ${large} 1 ${e.x} ${e.y}`
  }

  const color = clamped >= 80 ? 'var(--gauge-good)' : clamped >= 60 ? 'var(--gauge-warn)' : 'var(--gauge-bad)'
  const glowClass = clamped >= 80 ? 'arc-glow-good' : clamped >= 60 ? 'arc-glow-warn' : 'arc-glow-bad'

  return (
    <div className="flex flex-col items-center select-none">
      <svg width={size} height={size * 0.72} viewBox={`0 0 ${size} ${size}`} style={{ overflow: 'visible' }}>
        {/* Track */}
        <path d={arcPath(startAngle, startAngle + totalDeg)} fill="none" stroke="var(--gauge-track)" strokeWidth={12} strokeLinecap="round" />
        {/* Arc */}
        {clamped > 0 && (
          <path d={arcPath(startAngle, angle)} fill="none" stroke={color} strokeWidth={12} strokeLinecap="round" className={glowClass} />
        )}
        {/* Needle dot */}
        <circle
          cx={cx + r * Math.cos(toRad(angle))}
          cy={cy + r * Math.sin(toRad(angle))}
          r={7} fill={color} style={{ filter: `drop-shadow(0 0 6px ${color})` }}
        />
        {/* Value text */}
        <text x={cx} y={cy + 10} textAnchor="middle" fontFamily="var(--font-inter)" fontWeight="900" fontSize={size * 0.16} fill={color}>
          {clamped.toFixed(1)}%
        </text>
        <text x={cx} y={cy + 32} textAnchor="middle" fontFamily="var(--font-inter)" fontWeight="700" fontSize={size * 0.07} fill="var(--text4)">
          EFFICIENCY
        </text>
      </svg>
    </div>
  )
}
