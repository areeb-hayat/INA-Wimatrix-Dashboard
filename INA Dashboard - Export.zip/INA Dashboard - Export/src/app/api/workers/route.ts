// src/app/api/workers/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { connectDB } from '@/lib/db'
import { Prod6rModel, QcRework6rModel, WageByBundleModel } from '@/lib/models'
import { startOfDay, endOfDay, parseISO } from 'date-fns'

export const dynamic   = 'force-dynamic'
export const revalidate = 0

export async function GET(req: NextRequest) {
  try {
    await connectDB()
    const { searchParams } = new URL(req.url)
    const lineParam = searchParams.get('line') || 'all'
    const page      = Math.max(1, parseInt(searchParams.get('page')  || '1'))
    const limit     = Math.min(100, parseInt(searchParams.get('limit') || '25'))
    const preset    = searchParams.get('preset')
    const fromParam = searchParams.get('from')
    const toParam   = searchParams.get('to')

    let dayStart: Date | null = null
    let dayEnd:   Date | null = null

    if (preset !== 'all' && fromParam && toParam) {
      dayStart = startOfDay(parseISO(fromParam))
      dayEnd   = endOfDay(parseISO(toParam))
    } else if (preset !== 'all' && searchParams.get('date')) {
      dayStart = startOfDay(parseISO(searchParams.get('date')!))
      dayEnd   = endOfDay(parseISO(searchParams.get('date')!))
    }

    const selectedLine = lineParam !== 'all' ? parseInt(lineParam) : null
    const Prod6r     = Prod6rModel()
    const QcRework6r = QcRework6rModel()
    const WageModel  = WageByBundleModel()

    // String date filter
    const startStr = dayStart ? dayStart.toISOString() : null
    const endStr   = dayEnd   ? dayEnd.toISOString()   : null

    const prodFilter: Record<string, unknown> = {
      odpi_odpd_is_overtime: 0,
      odpi_quantity:         { $gt: 0 },
      ...(startStr && endStr ? { odpi_date: { $gte: startStr, $lte: endStr } } : {}),
    }
    if (selectedLine !== null) prodFilter.odpi_line_number = selectedLine

    const workerAgg = await Prod6r.aggregate([
      { $match: prodFilter },
      { $group: {
        _id:        '$odpi_em_key',
        name:       { $first: { $ifNull: ['$odpi_em_lcd_name', '$odpi_em_firstname'] } },
        line:       { $first: '$odpi_line_number' },
        qty:        { $sum: '$odpi_quantity' },
        earnedMins: { $sum: { $multiply: ['$odpi_quantity', { $divide: ['$odpi_oc_standard_time', 60] }] } },
        clockIn:    { $min: '$odpi_odp_actual_clock_in' },
        clockOut:   { $max: '$odpi_odp_actual_clock_out' },
        opCount:    { $addToSet: '$odpi_oc_key' },
      }},
      { $addFields: {
        efficiency: { $multiply: [{ $divide: ['$earnedMins', 480] }, 100] },
        opCount:    { $size: '$opCount' },
      }},
      { $sort: { efficiency: -1 } },
      { $skip: (page - 1) * limit },
      { $limit: limit },
    ])

    const totalCountAgg = await Prod6r.aggregate([
      { $match: prodFilter },
      { $group: { _id: '$odpi_em_key' } },
      { $count: 'total' },
    ])
    const total = (totalCountAgg[0]?.total as number) || 0

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const workerIds = (workerAgg as any[]).map((w) => w._id).filter(Boolean)

    const qcFilter: Record<string, unknown> = {
      QCRI_Defect_EM_Key: { $in: workerIds },
      ...(startStr && endStr ? { QCRI_QC_DateTime: { $gte: startStr, $lte: endStr } } : {}),
    }
    const defectAgg = workerIds.length ? await QcRework6r.aggregate([
      { $match: qcFilter },
      { $group: { _id: '$QCRI_Defect_EM_Key', defects: { $sum: '$QCRI_Defect_Quantity' } } },
    ]) : []
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const defectMap = new Map((defectAgg as any[]).map((d: any) => [d._id, d.defects as number]))

    const wageAgg = workerIds.length ? await WageModel.aggregate([
      { $match: {
        WorkerCode: { $in: workerIds },
        ...(dayStart && dayEnd ? { ScanDate: { $gte: dayStart, $lte: dayEnd } } : {}),
      }},
      { $group: { _id: '$WorkerCode', totalWage: { $sum: '$WageAmount' } } },
    ]).catch(() => []) : []
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const wageMap = new Map((wageAgg as any[]).map((w: any) => [w._id, w.totalWage as number]))

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const workers = (workerAgg as any[]).map((w: any) => {
      const defects = defectMap.get(w._id) || 0
      const qty     = Math.round(w.qty as number)
      return {
        id:         w._id as number,
        name:       (w.name as string) || `Worker ${w._id}`,
        line:       (w.line as number) || 0,
        qty,
        earnedMins: Math.round(w.earnedMins as number),
        efficiency: Math.round((w.efficiency as number) * 10) / 10,
        wage:       wageMap.get(w._id) || 0,
        defects,
        dhu:        qty > 0 ? Math.round((defects / qty) * 10000) / 100 : 0,
        opCount:    w.opCount as number,
        clockIn:    w.clockIn,
        clockOut:   w.clockOut,
      }
    })

    return NextResponse.json({
      workers,
      pagination: { total, page, pages: Math.ceil(total / limit), limit },
    })
  } catch (err) {
    console.error('Workers error:', err)
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}