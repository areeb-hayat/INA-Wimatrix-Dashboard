// src/app/api/trends/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { connectDB } from '@/lib/db'
import { Prod6rModel, QcRework6rModel } from '@/lib/models'
import { startOfDay, endOfDay, subDays, format } from 'date-fns'

export const dynamic   = 'force-dynamic'
export const revalidate = 0

export async function GET(req: NextRequest) {
  try {
    await connectDB()
    const { searchParams } = new URL(req.url)
    const lineParam    = searchParams.get('line') || 'all'
    const days         = Math.min(90, Math.max(7, parseInt(searchParams.get('days') || '14')))
    const selectedLine = lineParam !== 'all' ? parseInt(lineParam) : null

    const Prod6r     = Prod6rModel()
    const QcRework6r = QcRework6rModel()

    const rangeEnd   = endOfDay(new Date())
    const rangeStart = startOfDay(subDays(new Date(), days - 1))

    // All dates stored as ISO strings — use string comparison
    const startStr = rangeStart.toISOString()
    const endStr   = rangeEnd.toISOString()

    const prodFilter: Record<string, unknown> = {
      odpi_odpd_is_overtime: 0,
      odpi_quantity:         { $gt: 0 },
      odpi_date:             { $gte: startStr, $lte: endStr },
    }
    if (selectedLine !== null) prodFilter.odpi_line_number = selectedLine

    const qcFilter: Record<string, unknown> = {
      QCRI_QCSC_Is_Rework: 1,
      QCRI_QC_DateTime:    { $gte: startStr, $lte: endStr },
    }
    if (selectedLine !== null) qcFilter.QCRI_LineNumber = selectedLine

    const [prodAgg, qcAgg] = await Promise.all([
      Prod6r.aggregate([
        { $match: prodFilter },
        { $group: {
          // odpi_date is a string — extract date portion with $substr
          _id:        { $substr: ['$odpi_date', 0, 10] },
          output:     { $sum: { $cond: [{ $eq: ['$pc_key', 9999] }, '$odpi_quantity', 0] } },
          earnedMins: { $sum: { $multiply: ['$odpi_quantity', { $divide: ['$odpi_oc_standard_time', 60] }] } },
          workers:    { $addToSet: '$odpi_em_key' },
        }},
        { $sort: { _id: 1 } },
      ]),
      QcRework6r.aggregate([
        { $match: qcFilter },
        { $group: {
          _id:     { $substr: ['$QCRI_QC_DateTime', 0, 10] },
          defects: { $sum: '$QCRI_Defect_Quantity' },
        }},
      ]),
    ])

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const defectByDate = new Map((qcAgg as any[]).map((d: any) => [d._id as string, d.defects as number]))

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const trend = (prodAgg as any[]).map((d: any) => {
      const dateStr    = d._id as string
      const output     = (d.output     as number) || 0
      const earned     = (d.earnedMins as number) || 0
      const wCount     = ((d.workers   as unknown[]) || []).length
      const plan       = wCount * 480
      const efficiency = plan > 0 ? (earned / plan) * 100 : 0
      const defects    = defectByDate.get(dateStr) || 0
      const dhu        = output > 0 ? (defects / output) * 100 : 0
      return {
        date:       dateStr,
        label:      format(new Date(dateStr + 'T00:00:00'), 'dd MMM'),
        output,
        efficiency: Math.round(efficiency * 10) / 10,
        defects,
        dhu:        Math.round(dhu * 100) / 100,
      }
    })

    return NextResponse.json({ trend, days })
  } catch (err) {
    console.error('Trends error:', err)
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}