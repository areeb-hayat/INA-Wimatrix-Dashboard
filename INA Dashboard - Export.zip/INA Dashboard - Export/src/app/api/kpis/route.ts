// src/app/api/kpis/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { connectDB } from '@/lib/db'
import { Prod6rModel, QcRework6rModel } from '@/lib/models'
import { startOfDay, endOfDay, startOfMonth, format, parseISO } from 'date-fns'

export const dynamic   = 'force-dynamic'
export const revalidate = 0

export async function GET(req: NextRequest) {
  try {
    await connectDB()
    const { searchParams } = new URL(req.url)
    const lineParam = searchParams.get('line') || 'all'
    const preset    = searchParams.get('preset')
    const fromParam = searchParams.get('from')
    const toParam   = searchParams.get('to')

    let dayStart: Date | null = null
    let dayEnd:   Date | null = null

    if (preset !== 'all' && fromParam && toParam) {
      dayStart = startOfDay(parseISO(fromParam))
      dayEnd   = endOfDay(parseISO(toParam))
    } else if (preset !== 'all' && searchParams.get('date')) {
      const d  = parseISO(searchParams.get('date')!)
      dayStart = startOfDay(d)
      dayEnd   = endOfDay(d)
    }

    const data = await buildDashboard(dayStart, dayEnd, lineParam)
    return NextResponse.json(data)
  } catch (err) {
    console.error('KPI error:', err)
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}

// ─── IMPORTANT: All date fields in MongoDB are stored as ISO strings ───────────
// Oracle ORDS returns dates as strings like "2026-04-13T04:00:00Z" or "2026-05-25T16:45:59"
// The Python sync script stores them as-is (strings, NOT Date objects).
// ISO 8601 strings sort lexicographically correctly, so $gte/$lte string comparisons work.
// NEVER compare a JS Date object against these fields — it will always return 0 results.

function toIsoStr(d: Date): string {
  // Oracle stores without trailing Z on some endpoints, with Z on others.
  // Using the full ISO string with Z works for both because "2026-04-13T..." < "2026-04-14T..."
  return d.toISOString()
}

/** String-based date range filter — works for all Oracle string date fields */
function sf(field: string, start: Date | null, end: Date | null): Record<string, unknown> {
  if (!start || !end) return {}
  return { [field]: { $gte: toIsoStr(start), $lte: toIsoStr(end) } }
}

// ─── Available lines ───────────────────────────────────────────────────────────
async function getAvailableLines(start: Date | null, end: Date | null): Promise<number[]> {
  const Prod6r = Prod6rModel()
  const filter: Record<string, unknown> = {
    odpi_line_number: { $ne: null },
    ...sf('odpi_date', start, end),
  }
  const lines = await Prod6r.distinct('odpi_line_number', filter)
  return (lines as number[]).filter(n => typeof n === 'number' && n > 0).sort((a, b) => a - b)
}

// ─── Per-line KPI aggregation ──────────────────────────────────────────────────
async function buildLineKpis(start: Date | null, end: Date | null, lineNumber: number | null) {
  const Prod6r     = Prod6rModel()
  const QcRework6r = QcRework6rModel()

  // All date comparisons use string filter (sf)
  const prodBase: Record<string, unknown> = {
    odpi_odpd_is_overtime: 0,
    odpi_quantity:         { $gt: 0 },
    odpi_line_number:      { $ne: null },
    ...sf('odpi_date', start, end),
  }
  if (lineNumber !== null) prodBase.odpi_line_number = lineNumber

  const qcBase: Record<string, unknown> = {
    ...sf('QCRI_QC_DateTime', start, end),
  }
  if (lineNumber !== null) qcBase.QCRI_LineNumber = lineNumber

  const oneHourAgoStr = new Date(Date.now() - 3_600_000).toISOString()

  // MTD filter: from start of month to end of range
  const mtdBase: Record<string, unknown> = {
    odpi_odpd_is_overtime: 0,
    odpi_quantity:         { $gt: 0 },
    pc_key:                9999,
    ...(start ? sf('odpi_date', startOfMonth(start), end ?? new Date()) : {}),
  }
  if (lineNumber !== null) mtdBase.odpi_line_number = lineNumber

  const [outputAgg, minutesAgg, defectAgg, tatAgg, mtdAgg, loadAgg, planRec,
         totalRework, pendingRework, lastHourAgg] = await Promise.all([

    // Finished pieces: pc_key = 9999 (unloading / QC checkpoint = end of line)
    Prod6r.aggregate([
      { $match: { ...prodBase, pc_key: 9999 } },
      { $group: { _id: null, total: { $sum: '$odpi_quantity' } } },
    ]),

    // Efficiency numerator: earned minutes; denominator: distinct workers × 480
    Prod6r.aggregate([
      { $match: prodBase },
      { $group: {
        _id: null,
        earnedMins: { $sum: { $multiply: ['$odpi_quantity', { $divide: ['$odpi_oc_standard_time', 60] }] } },
        workers:    { $addToSet: '$odpi_em_key' },
      }},
    ]),

    // DHU defects
    QcRework6r.aggregate([
      { $match: { ...qcBase, QCRI_QCSC_Is_Rework: 1 } },
      { $group: { _id: null, total: { $sum: '$QCRI_Defect_Quantity' } } },
    ]),

    // Repair TAT — $toDate converts stored ISO string to Date for arithmetic
    QcRework6r.aggregate([
      { $match: { ...qcBase, QCRI_Repair_Quantity: { $gt: 0 }, QCRI_Repair_EM_Key: { $gt: 0 } } },
      { $addFields: {
        tatMins: { $divide: [
          { $subtract: [{ $toDate: '$QCRI_Repair_DateTime' }, { $toDate: '$QCRI_QC_DateTime' }] },
          60000,
        ]},
      }},
      { $match: { tatMins: { $gt: 0, $lt: 480 } } },
      { $group: { _id: null, avg: { $avg: '$tatMins' } } },
    ]),

    // MTD output
    Prod6r.aggregate([
      { $match: mtdBase },
      { $group: { _id: null, total: { $sum: '$odpi_quantity' } } },
    ]),

    // WIP = loaded - unloaded (stop_order=1 = first op = loading)
    Prod6r.aggregate([
      { $match: { ...prodBase, odpi_stop_order: 1 } },
      { $group: { _id: null, total: { $sum: '$odpi_quantity' } } },
    ]),

    // Planned qty for this line/date
    Prod6r.findOne(prodBase, { stpo_plannedquantity: 1 }).lean(),

    // Rework counts
    QcRework6r.countDocuments({ ...qcBase, QCRI_QCSC_Is_Rework: 1 }),
    QcRework6r.countDocuments({ ...qcBase, QCRI_Repair_Quantity: 0, QCRI_QCSC_Is_Rework: 1 }),

    // Last hour output
    Prod6r.aggregate([
      { $match: { ...prodBase, pc_key: 9999, odp_last_hanger_time: { $gte: oneHourAgoStr } } },
      { $group: { _id: null, total: { $sum: '$odpi_quantity' } } },
    ]),
  ])

  const output       = (outputAgg[0]?.total    as number) || 0
  const earnedMins   = Math.round((minutesAgg[0]?.earnedMins as number) || 0)
  const workerCount  = ((minutesAgg[0]?.workers as unknown[]) || []).length
  const planMins     = workerCount * 480
  const efficiency   = planMins > 0 ? (earnedMins / planMins) * 100 : 0
  const totalDefects = (defectAgg[0]?.total    as number) || 0
  const dhu          = output > 0 ? (totalDefects / output) * 100 : 0
  const avgTat       = Math.round((tatAgg[0]?.avg as number) || 0)
  const mtdOutput    = (mtdAgg[0]?.total        as number) || 0
  const loaded       = (loadAgg[0]?.total       as number) || output
  const wip          = Math.max(0, loaded - output)
  const lastHour     = (lastHourAgg[0]?.total   as number) || 0
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const plannedQty   = ((planRec as any)?.stpo_plannedquantity as number) || 0

  return {
    output, plannedQty,
    efficiency:    Math.round(efficiency * 10) / 10,
    earnedMinutes: earnedMins,
    planMinutes:   planMins,
    dhu:           Math.round(dhu * 100) / 100,
    totalDefects,
    rework:        totalRework,
    pendingRework,
    wip,
    lastHourOutput: lastHour,
    mtdOutput,
    avgRepairTat:  avgTat,
    workerCount,
    targetAchievedPct: plannedQty > 0 ? Math.round((output / plannedQty) * 100) : 0,
  }
}

// ─── Dashboard builder ─────────────────────────────────────────────────────────
async function buildDashboard(start: Date | null, end: Date | null, lineParam: string) {
  const Prod6r     = Prod6rModel()
  const QcRework6r = QcRework6rModel()
  const line = lineParam !== 'all' ? parseInt(lineParam) : null

  const [availableLines, summary] = await Promise.all([
    getAvailableLines(start, end),
    buildLineKpis(start, end, line),
  ])

  // Per-line breakdown (run concurrently)
  const allLineKpis = await Promise.all(
    availableLines.map(async (ln) => {
      const k = await buildLineKpis(start, end, ln)
      return { line: ln, lineName: `Line ${ln}`, ...k }
    })
  )

  // Chart filters
  const prodChartFilter: Record<string, unknown> = {
    odpi_odpd_is_overtime: 0,
    pc_key: 9999,
    ...sf('odpi_date', start, end),
  }
  if (line !== null) prodChartFilter.odpi_line_number = line

  const qcChartFilter: Record<string, unknown> = {
    QCRI_QCSC_Is_Rework: 1,
    ...sf('QCRI_QC_DateTime', start, end),
  }
  if (line !== null) qcChartFilter.QCRI_LineNumber = line

  const workerFilter: Record<string, unknown> = {
    odpi_odpd_is_overtime: 0,
    odpi_quantity:         { $gt: 0 },
    ...sf('odpi_date', start, end),
  }
  if (line !== null) workerFilter.odpi_line_number = line

  // Hourly trend: last 9h using string comparison
  const nineHAgoStr = new Date(Date.now() - 9 * 3_600_000).toISOString()

  const [defectBreakdown, hourlyAgg, topWorkers] = await Promise.all([
    QcRework6r.aggregate([
      { $match: qcChartFilter },
      { $group: { _id: '$QCRI_QCSC_Description', count: { $sum: '$QCRI_Defect_Quantity' } } },
      { $sort: { count: -1 } },
      { $limit: 10 },
    ]),
    Prod6r.aggregate([
      { $match: { ...prodChartFilter, odp_last_hanger_time: { $gte: nineHAgoStr } } },
      { $group: {
        _id: { $hour: { $toDate: '$odp_last_hanger_time' } },
        qty: { $sum: '$odpi_quantity' },
      }},
      { $sort: { _id: 1 } },
    ]),
    Prod6r.aggregate([
      { $match: workerFilter },
      { $group: {
        _id:        '$odpi_em_key',
        name:       { $first: { $ifNull: ['$odpi_em_lcd_name', '$odpi_em_firstname'] } },
        qty:        { $sum: '$odpi_quantity' },
        earnedMins: { $sum: { $multiply: ['$odpi_quantity', { $divide: ['$odpi_oc_standard_time', 60] }] } },
      }},
      { $addFields: {
        efficiency: { $multiply: [{ $divide: ['$earnedMins', 480] }, 100] },
      }},
      { $sort: { efficiency: -1 } },
      { $limit: 10 },
    ]),
  ])

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const topWorkerIds = (topWorkers as any[]).map((w) => w._id).filter(Boolean)
  const workerDefects = topWorkerIds.length ? await QcRework6r.aggregate([
    { $match: { QCRI_Defect_EM_Key: { $in: topWorkerIds }, ...sf('QCRI_QC_DateTime', start, end) } },
    { $group: { _id: '$QCRI_Defect_EM_Key', defects: { $sum: '$QCRI_Defect_Quantity' } } },
  ]) : []
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const defectMap = new Map((workerDefects as any[]).map((d: any) => [d._id, d.defects as number]))

  return {
    date:         start && end ? `${format(start, 'yyyy-MM-dd')} → ${format(end, 'yyyy-MM-dd')}` : 'All time',
    selectedLine: lineParam || 'all',
    summary: {
      line:     line ?? 0,
      lineName: line ? `Line ${line}` : 'All Lines',
      ...summary,
    },
    allLines: allLineKpis,
    charts: {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      defectBreakdown: (defectBreakdown as any[]).map((d: any) => ({
        name: (d._id as string) || 'Unknown', count: d.count as number,
      })),
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      hourlyTrend: (hourlyAgg as any[]).map((h: any) => ({
        hour:   `${(h._id as number).toString().padStart(2, '0')}:00`,
        qty:    h.qty as number,
        target: Math.round(summary.plannedQty / 9),
      })),
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      topWorkers: (topWorkers as any[]).map((w: any) => ({
        id:         w._id as number,
        name:       (w.name as string) || `Worker ${w._id}`,
        qty:        Math.round(w.qty as number),
        efficiency: Math.round((w.efficiency as number) * 10) / 10,
        dhu:        (w.qty as number) > 0
          ? Math.round(((defectMap.get(w._id) || 0) / (w.qty as number)) * 10000) / 100 : 0,
      })),
    },
    availableLines,
  }
}