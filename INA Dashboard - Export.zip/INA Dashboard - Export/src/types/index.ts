export interface LineKpis {
  line: number | string
  lineName: string
  output: number
  plannedQty: number
  efficiency: number
  earnedMinutes: number
  planMinutes: number
  dhu: number
  totalDefects: number
  rework: number
  pendingRework: number
  wip: number
  lastHourOutput: number
  mtdOutput: number
  avgRepairTat: number
  workerCount: number
  targetAchievedPct: number
}

export interface DashboardData {
  date: string
  selectedLine: string
  summary: LineKpis
  allLines: LineKpis[]
  charts: {
    defectBreakdown: { name: string; count: number }[]
    hourlyTrend:     { hour: string; qty: number; target: number }[]
    topWorkers:      { id: number; name: string; qty: number; efficiency: number; dhu: number }[]
  }
  availableLines: number[]
}

export interface WorkerRow {
  id: number
  name: string
  line: number
  qty: number
  earnedMins: number
  efficiency: number
  wage: number
  defects: number
  dhu: number
  opCount: number
  clockIn?: string
  clockOut?: string
}

export interface TrendDay {
  date: string
  label: string
  output: number
  efficiency: number
  defects: number
  dhu: number
}

export interface SyncSource {
  source: string
  lastSyncedAt?: string
  totalRecords?: number
  status?: string
}

// ── Time filter ───────────────────────────────────────────────────────────────
export type TimeFilterPreset =
  | 'all'
  | 'yesterday'
  | 'this_week'   | 'last_week'
  | 'this_month'  | 'last_month'
  | 'last_3_months' | 'last_6_months'
  | 'custom'

export interface TimeFilter {
  preset: TimeFilterPreset
  from:   Date | null
  to:     Date | null
  label:  string
}
