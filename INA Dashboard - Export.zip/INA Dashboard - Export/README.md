# MG Apparel — Production Dashboard

Real-time manufacturing KPI dashboard built with Next.js 14, MongoDB, and Oracle ORDS APIs.

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Configure environment (edit .env.local)
cp .env.local .env.local   # already exists, just edit it

# 3. Start development server
npm run dev
# → Open http://localhost:3000
```

## Environment Variables (.env.local)

```env
MONGODB_URI=mongodb://localhost:27017/mga_production
ORACLE_API_BASE=http://110.38.236.7:7003/ords/ws_apparel
SQL_SERVER=192.168.142.31,1433
SQL_DATABASE=SooperWizer
SQL_USER=MGIT
SQL_PASSWORD=P@$$w0rD_$$
```

## Data Sync

### Option A — TypeScript (Oracle only, no SQL Server)
```bash
npm run sync:full    # Full sync (first time)
npm run sync         # Incremental sync
```

### Option B — Python (Oracle + SQL Server)
```bash
pip install pyodbc pymongo requests python-dotenv

python scripts/sync.py --full             # Full sync now
python scripts/sync.py                    # Incremental sync
python scripts/sync.py --full --schedule  # Full now + daily at 01:00 PKT
python scripts/sync.py --schedule         # Daily at 01:00 PKT only
```

## Why production_info_6r was timing out

The 6r endpoint returns millions of records. The fix:
- **Page size reduced**: 1000 → 500 rows per request
- **Timeout increased**: 60s → 120s per page
- **Automatic retry**: 3 attempts with backoff on each page
- **Runs after light endpoints**: sequentially, not competing for bandwidth
- **Background index building**: indexes created after first batch, not blocking sync

## API Endpoints

| Route | Description |
|-------|-------------|
| `GET /api/kpis?date=YYYY-MM-DD&line=all` | KPI summary |
| `GET /api/kpis?from=YYYY-MM-DD&to=YYYY-MM-DD&line=1` | Date range KPIs |
| `GET /api/workers?date=YYYY-MM-DD&page=1&limit=25` | Paginated worker performance |
| `GET /api/trends?days=14&line=all` | Trend data |
| `GET /api/sync` | Sync metadata |

## Why APIs returned nothing in dev / weren't called in production

**Root causes fixed:**
1. **Import paths**: `@/app/context/ThemeContext` now resolves correctly
2. **`force-dynamic`**: Added to all API routes so Next.js never caches them
3. **DB connection caching**: Fixed global cache to survive hot reloads in dev
4. **Date params**: APIs now accept both `?date=` and `?from=&to=` for range queries
5. **Error surfacing**: Frontend now shows real error messages instead of silent failures

## Project Structure

```
src/
  app/
    api/kpis/route.ts        ← Main KPI aggregation
    api/workers/route.ts     ← Worker performance with pagination
    api/trends/route.ts      ← 14-day trend data
    api/sync/route.ts        ← Sync metadata
    context/ThemeContext.tsx  ← Dark/light theme
    layout.tsx
    page.tsx                 ← Main dashboard page
  components/
    dashboard/
      DashboardHeader.tsx    ← Header with time filter, line selector
      TimeFilterBar.tsx      ← Date range picker (Today/Week/Month/Custom)
      AllLinesTable.tsx      ← Per-line KPI table
      WorkerTable.tsx        ← Paginated worker table
      ChartsSection.tsx      ← Recharts charts
    ui/
      KpiCard.tsx
      ProgressBar.tsx
      EfficiencyGauge.tsx
      MtdRing.tsx
      TodaysTargetCard.tsx
      LoadingSkeleton.tsx
  lib/
    db.ts                    ← MongoDB connection (cached)
    models.ts                ← Mongoose models with indexes
  types/
    index.ts                 ← TypeScript types
scripts/
  sync_oracle.ts             ← TypeScript sync (Oracle only)
  sync.py                    ← Python sync (Oracle + SQL Server)
```
