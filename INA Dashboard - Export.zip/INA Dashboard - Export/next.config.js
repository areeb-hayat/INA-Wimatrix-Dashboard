/** @type {import('next').NextConfig} */
const nextConfig = {
  // Ensure API routes are always dynamic
  experimental: {},
}

module.exports = nextConfig
