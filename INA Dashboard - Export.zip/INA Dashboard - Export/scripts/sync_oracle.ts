#!/usr/bin/env tsx
/**
 * MGA Production Dashboard — Oracle Sync Script
 *
 * Fetches all 4 Oracle ORDS endpoints into MongoDB.
 * production_info_6r uses smaller chunks + retry to avoid timeouts on huge datasets.
 *
 * Usage:
 *   npm run sync          (incremental — builds on existing data)
 *   npm run sync:full     (force full re-sync)
 *   FULL_SYNC=true npx tsx scripts/sync_oracle.ts
 */

import 'dotenv/config'
import mongoose from 'mongoose'

const MONGODB_URI  = process.env.MONGODB_URI  || 'mongodb://localhost:27017/mga_production'
const ORACLE_BASE  = process.env.ORACLE_API_BASE || 'http://110.38.236.7:7003/ords/ws_apparel'
const IS_FULL_SYNC = process.env.FULL_SYNC === 'true'

// ─── Endpoints ────────────────────────────────────────────────────────────────
const ENDPOINTS = {
  production_info:     { url: `${ORACLE_BASE}/production_info/get`,                    id: 'ppd_key',  fmt: '7r' as const, pageSize: 1000, timeoutMs: 60000  },
  quality_rework_info: { url: `${ORACLE_BASE}/quality_rework_info/get`,                id: 'qtm_key',  fmt: '7r' as const, pageSize: 1000, timeoutMs: 60000  },
  // 6r is the huge one — use smaller pages and longer timeout per chunk
  production_info_6r:  { url: `${ORACLE_BASE}/production_info_6r/get`,                 id: 'odpi_key', fmt: '6r' as const, pageSize: 500,  timeoutMs: 120000 },
  qc_rework_info_6r:   { url: `${ORACLE_BASE}/quality_rework_info_6r/qc_rework_info`,  id: 'QCRI_Key', fmt: '6r' as const, pageSize: 500,  timeoutMs: 120000 },
}

// ─── Schemas ──────────────────────────────────────────────────────────────────
const { Schema } = mongoose

const SCHEMAS: Record<string, mongoose.Schema> = {
  production_info:     new Schema({ ppd_key:  { type: String, required: true, unique: true } }, { strict: false, collection: 'production_info' }),
  quality_rework_info: new Schema({ qtm_key:  { type: String, required: true, unique: true } }, { strict: false, collection: 'quality_rework_info' }),
  production_info_6r:  new Schema({ odpi_key: { type: String, required: true, unique: true } }, { strict: false, collection: 'production_info_6r' }),
  qc_rework_info_6r:   new Schema({ QCRI_Key: { type: String, required: true, unique: true } }, { strict: false, collection: 'qc_rework_info_6r' }),
  sync_meta:           new Schema({ source:   { type: String, required: true, unique: true } }, { strict: false, collection: 'sync_meta' }),
}

// Indexes to build (per collection)
const INDEXES: Record<string, Array<[Record<string, number>, Record<string, unknown>]>> = {
  production_info: [
    [{ ppd_date: 1, ppd_line_number: 1 }, {}],
    [{ ppd_hei_code: 1, ppd_date: 1 }, {}],
  ],
  quality_rework_info: [
    [{ date_back: 1, ppd_line_number: 1 }, {}],
    [{ workbill: 1 }, {}],
  ],
  production_info_6r: [
    [{ odpi_date: 1, odpi_line_number: 1 }, {}],
    [{ odpi_date: 1, odpi_line_number: 1, odpi_odpd_is_overtime: 1 }, {}],
    [{ odpi_date: 1, pc_key: 1 }, {}],
    [{ odpi_em_key: 1, odpi_date: 1 }, {}],
    [{ pc_key: 1 }, {}],
    [{ odp_last_hanger_time: 1 }, {}],
  ],
  qc_rework_info_6r: [
    [{ QCRI_QC_DateTime: 1, QCRI_LineNumber: 1 }, {}],
    [{ QCRI_QC_DateTime: 1, QCRI_QCSC_Is_Rework: 1 }, {}],
    [{ QCRI_Defect_EM_Key: 1 }, {}],
    [{ QCRI_QCSC_Is_Rework: 1 }, {}],
  ],
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function log(msg: string, src = 'SYNC') {
  const ts = new Date().toISOString().replace('T', ' ').substring(0, 19)
  console.log(`[${ts}] [${src}] ${msg}`)
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function getModel(name: string): any {
  if (mongoose.models[name]) return mongoose.models[name]
  const schema = SCHEMAS[name] || new Schema({}, { strict: false })
  return mongoose.model(name, schema)
}

async function buildIndexes(collection: string) {
  const Model   = getModel(collection)
  const indexes = INDEXES[collection] || []
  for (const [fields, opts] of indexes) {
    try {
      await Model.collection.createIndex(fields, { ...opts, background: true })
    } catch {
      // already exists
    }
  }
}

async function upsertBatch(modelName: string, items: Record<string, unknown>[], idField: string) {
  if (!items.length) return
  const Model = getModel(modelName)
  const ops = items.map((item) => ({
    updateOne: {
      filter: { [idField]: item[idField] },
      update: { $set: item },
      upsert: true,
    },
  }))
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  await (Model as any).bulkWrite(ops, { ordered: false })
}

// Fetch one page with retry on timeout
async function fetchPage(url: string, timeoutMs: number, retries = 3): Promise<unknown> {
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const res = await fetch(url, { signal: AbortSignal.timeout(timeoutMs) })
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      return await res.json()
    } catch (err) {
      if (attempt === retries) throw err
      const wait = attempt * 5000
      log(`  Attempt ${attempt} failed (${err}), retrying in ${wait / 1000}s…`)
      await new Promise((r) => setTimeout(r, wait))
    }
  }
  throw new Error('All retries failed')
}

// ─── Main sync function per endpoint ─────────────────────────────────────────

async function syncEndpoint(
  name: keyof typeof ENDPOINTS,
  collection: string,
) {
  const { url, id: idField, fmt, pageSize, timeoutMs } = ENDPOINTS[name]
  let offset = 0
  let total  = 0
  let indexDone = false

  log(`Starting (${IS_FULL_SYNC ? 'FULL' : 'INCREMENTAL'})`, collection)

  while (true) {
    const sep     = url.includes('?') ? '&' : '?'
    const pageUrl = `${url}${sep}offset=${offset}&limit=${pageSize}`

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    let page: any
    try {
      page = await fetchPage(pageUrl, timeoutMs)
    } catch (err) {
      log(`  Fatal error at offset ${offset}: ${err}`, collection)
      break
    }

    const rawItems: Record<string, unknown>[] = fmt === '6r'
      ? ((page.data || []) as Record<string, unknown>[]).filter((r) => r[idField])
      : (page.items || []) as Record<string, unknown>[]

    if (!rawItems.length) {
      log(`  No more data at offset ${offset}`, collection)
      break
    }

    await upsertBatch(collection, rawItems, idField)
    total += rawItems.length

    if (total % 5000 === 0 || rawItems.length < pageSize) {
      log(`  ${total.toLocaleString()} records upserted…`, collection)
    }

    // Build indexes once after first batch
    if (!indexDone) {
      indexDone = true
      await buildIndexes(collection)
    }

    const hasMore = fmt === '6r'
      ? offset + pageSize < (page.total || 0)
      : page.hasMore === true

    if (!hasMore) break
    offset += pageSize
  }

  log(`✓ Done — ${total.toLocaleString()} total records`, collection)
  return total
}

async function updateSyncMeta(source: string, total: number, status: 'ok' | 'error' = 'ok') {
  const SyncMeta = getModel('sync_meta')
  await SyncMeta.updateOne(
    { source },
    { $set: { lastSyncedAt: new Date(), totalRecords: total, status } },
    { upsert: true },
  )
}

// ─── Entry point ──────────────────────────────────────────────────────────────

async function main() {
  log('Connecting to MongoDB…')
  await mongoose.connect(MONGODB_URI, { bufferCommands: false, serverSelectionTimeoutMS: 15000 })
  log('Connected')

  const SOURCES: Array<{ key: keyof typeof ENDPOINTS; col: string }> = [
    { key: 'production_info',     col: 'production_info' },
    { key: 'quality_rework_info', col: 'quality_rework_info' },
    { key: 'production_info_6r',  col: 'production_info_6r' },  // heavy one — runs separately
    { key: 'qc_rework_info_6r',   col: 'qc_rework_info_6r' },
  ]

  for (const { key, col } of SOURCES) {
    try {
      const n = await syncEndpoint(key, col)
      await updateSyncMeta(col, n, 'ok')
    } catch (err) {
      log(`ERROR: ${err}`, col)
      await updateSyncMeta(col, 0, 'error').catch(() => {})
    }
  }

  log('All done')
  await mongoose.disconnect()
}

main().catch((err) => {
  console.error('Sync failed:', err)
  process.exit(1)
})
